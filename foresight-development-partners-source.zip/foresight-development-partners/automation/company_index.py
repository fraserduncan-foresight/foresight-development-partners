"""Local HubSpot company identity index. Parent connector supplies actual responses."""
import argparse
import datetime as dt
import json
from pathlib import Path
import re
import sqlite3
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parent/'company-index'
FIELDS=['name','domain','phone','website','hs_lastmodifieddate','hs_redirect_domain']

def now():return dt.datetime.now(dt.timezone.utc)
def domain(s):
    if not s:return ''
    return (urlsplit(s if '://' in s else 'https://'+s).hostname or '').lower().removeprefix('www.')
def name(s):return ' '.join(re.findall(r'\w+',s.casefold()))
def phone(s):
    digits=re.sub(r'\D','',s)
    if len(digits)==11 and digits.startswith('1'):digits=digits[1:]
    return digits if len(digits)>=10 else ''
def unpack(data):
    if data.get('isError'):raise ValueError('Connector returned an error')
    if 'content' in data:
        data=json.loads(next(x['text'] for x in data['content'] if x['type']=='text'))
    return data

def connect(root):
    root.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(root/'companies.sqlite3');c.row_factory=sqlite3.Row
    c.execute('pragma journal_mode=WAL')
    c.executescript('create table if not exists companies(id text primary key, record text not null); create table if not exists keys(kind text,key text,id text,unique(kind,key,id)); create index if not exists key_lookup on keys(kind,key); create table if not exists meta(key text primary key,value text not null);')
    return c

def get(c,key,default=None):
    r=c.execute('select value from meta where key=?',(key,)).fetchone()
    return json.loads(r[0]) if r else default

def put(c,key,value):c.execute('insert or replace into meta values(?,?)',(key,json.dumps(value)))

def upsert(c,rows,template):
    for row in rows:
        ident=str(row['id']);p=row.get('properties',{})
        if not p:raise ValueError('Expected actual company properties')
        existing=c.execute('select record from companies where id=?',(ident,)).fetchone()
        old=json.loads(existing[0]) if existing else {}
        aliases=set(old.get('aliases',[]))
        for n in [p.get('name',''),old.get('properties',{}).get('name','')]:
            if n:
                aliases.add(n)
                match=re.search(r'\((?:AKA|FKA)\s+(.+?)\)',n,re.I)
                if match:aliases.update([n[:match.start()].strip(),match[1]])
        record=dict(id=ident,properties=p,aliases=sorted(aliases),url=row.get('url') or template.replace('{id}',ident),indexed_at=now().isoformat())
        c.execute('insert or replace into companies values(?,?)',(ident,json.dumps(record)))
        c.execute('delete from keys where id=?',(ident,))
        tokens={('name',name(x)) for x in aliases}
        tokens|={('domain',domain(p.get(k,''))) for k in ('domain','website','hs_redirect_domain')}
        tokens.add(('phone',phone(p.get('phone',''))))
        c.executemany('insert or ignore into keys values(?,?,?)',[(kind,key,ident) for kind,key in tokens if key])

def status(c):return dict(companies=c.execute('select count(*) from companies').fetchone()[0],baseline=get(c,'baseline'),watermark=get(c,'watermark'),refresh=get(c,'refresh'))

def bootstrap(c,directory):
    manifest=json.loads((directory/'manifest.json').read_text())
    files=sorted(directory.glob('page-*.json'))
    if not manifest.get('complete') or len(files)!=manifest['pages']:raise ValueError('Incomplete bootstrap')
    seen=set()
    with c:
        c.execute('delete from keys');c.execute('delete from companies')
        for f in files:
            page=unpack(json.loads(f.read_text()))
            for r in page['results']:
                if str(r['id']) in seen:raise ValueError('Duplicate bootstrap ID')
                seen.add(str(r['id']))
            upsert(c,page['results'],page['urlTemplate'])
        if len(seen)!=manifest['count']:raise ValueError('Bootstrap count mismatch')
        put(c,'baseline',manifest);put(c,'watermark',manifest['watermark']);put(c,'refresh',None)
    return status(c)

def plan(c):
    if not get(c,'baseline'):raise ValueError('Build complete global baseline first')
    sync=get(c,'refresh')
    if not sync:
        upper=(now()-dt.timedelta(minutes=2)).isoformat()
        lower=(dt.datetime.fromisoformat(get(c,'watermark').replace('Z','+00:00'))-dt.timedelta(minutes=10)).isoformat()
        sync=dict(lower=lower,upper=upper,cursor=None,rows=0)
        with c:put(c,'refresh',sync)
    filters=[dict(propertyName='hs_lastmodifieddate',operator='GTE',value=sync['lower'],values=[],highValue=None),dict(propertyName='hs_lastmodifieddate',operator='LT',value=sync['upper'],values=[],highValue=None)]
    if sync['cursor']:filters.append(dict(propertyName='hs_object_id',operator='GT',value=sync['cursor'],values=[],highValue=None))
    return dict(objectType='COMPANY',filterGroups=[dict(associatedWith=[],filters=filters)],properties=FIELDS,limit=200,offset=0,query=None,sorts=[dict(propertyName='hs_object_id',direction='ASCENDING')])

def import_page(c,data):
    sync=get(c,'refresh')
    if not sync:raise ValueError('Prepare refresh-plan before importing actual page')
    page=unpack(data);rows=page['results'];prior=int(sync['cursor'] or 0)
    for r in rows:
        if int(r['id'])<=prior:raise ValueError('Page cursor did not advance; do not import repeated page')
        prior=int(r['id'])
        modified=r['properties'].get('hs_lastmodifieddate')
        if not modified or not(dt.datetime.fromisoformat(sync['lower'])<=dt.datetime.fromisoformat(modified.replace('Z','+00:00'))<dt.datetime.fromisoformat(sync['upper'])):raise ValueError('Response outside prepared modification window')
    with c:
        upsert(c,rows,page.get('urlTemplate',''))
        if rows:
            sync['cursor']=str(prior);sync['rows']+=len(rows);put(c,'refresh',sync)
        else:
            put(c,'watermark',sync['upper']);put(c,'last_refresh',sync|{'finished_at':now().isoformat()});put(c,'refresh',None)
    return dict(done=not rows,page_count=len(rows),status=status(c))

def lookup(c,candidate):
    tokens={('domain',domain(candidate.get(k,''))) for k in ('domain','website')}
    tokens|={('name',name(candidate.get('name',''))),('phone',phone(candidate.get('phone','')))}
    matches={}
    for kind,key in tokens:
        if key:
            for row in c.execute('select id from keys where kind=? and key=?',(kind,key)):
                matches.setdefault(row[0],set()).add(kind)
    records=[]
    for ident,reasons in matches.items():
        record=json.loads(c.execute('select record from companies where id=?',(ident,)).fetchone()[0])
        records.append(dict(id=ident,name=record['properties'].get('name',''),url=record['url'],matched_on=sorted(reasons)))
    strong=[x for x in records if 'name' in x['matched_on'] and ('domain' in x['matched_on'] or 'phone' in x['matched_on'])]
    return dict(candidate=candidate,status='existing' if len(strong)==1 and len(records)==1 else 'possible_match' if records else 'not_in_index',matches=records,note='Index is a shortlist, not proof of CRM absence. Confirm ambiguity minimally; live duplicate check required before create.')

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=ROOT);s=p.add_subparsers(dest='command',required=True)
    s.add_parser('status');s.add_parser('refresh-plan')
    q=s.add_parser('bootstrap');q.add_argument('--directory',type=Path,required=True)
    for command in ('import-page','lookup','upsert'):
        q=s.add_parser(command);q.add_argument('--file',type=Path,required=True)
    a=p.parse_args();c=connect(a.root)
    if a.command=='status':out=status(c)
    elif a.command=='bootstrap':out=bootstrap(c,a.directory)
    elif a.command=='refresh-plan':out=plan(c)
    elif a.command=='import-page':out=import_page(c,json.loads(a.file.read_text()))
    elif a.command=='lookup':
        d=json.loads(a.file.read_text());out=[lookup(c,x) for x in (d if isinstance(d,list) else [d])]
    else:
        d=unpack(json.loads(a.file.read_text()));rows=d.get('objects',d.get('results',[]))
        if not rows:raise ValueError('Actual create/readback records required')
        with c:upsert(c,rows,d.get('urlTemplate',''))
        out=dict(upserted=len(rows))
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
