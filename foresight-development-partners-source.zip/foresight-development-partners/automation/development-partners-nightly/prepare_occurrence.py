"""Materialize one authorized nightly window without starting research."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path('/Users/fraserduncan/Documents/Codex/foresight-skill-data/Automation')
PACIFIC = ZoneInfo('America/Los_Angeles')
UTC = dt.timezone.utc

def window(day):
    start = dt.datetime.combine(dt.date.fromisoformat(day), dt.time(22), PACIFIC)
    finish = start.astimezone(UTC) + dt.timedelta(hours=9)
    return start, finish.astimezone(PACIFIC)

def prepare(day, dry_run=False):
    start, finish = window(day)
    key = f'partners-{day}-intensive'
    config_path = ROOT / 'config.json'
    config = json.loads(config_path.read_text())
    ledger = json.loads((ROOT / 'usage-ledger.json').read_text())
    allocation = min(40, float(ledger.get('remaining_points', 0)))
    override = dict(authorized=True, authorized_on='2026-10-31', workflow='partners',
        minutes=540, research_minutes=510, write_minutes=535,
        run_allocation_points=allocation, exclusive=True,
        skip_workflows=['cities','admins','recontact','provider_review'],
        budget_basis='Existing cumulative shared weekly allowance only; preserve ledger and one-point margin. Refresh actual usage before begin.',
        reason='Standing user authorization: nine-hour Development Partners research every night, backlog first, persistent bounded alternatives.',
        start_local=start.isoformat(), finish_local=finish.isoformat(),
        journal_suffix='intensive', local_start_date=day, start_hour=22,
        delegated_source_selection=True, paid_enrichment=False, crm_writes=False)
    summary = dict(run_id=key, start=start.isoformat(), finish=finish.isoformat(),
        research_until=(finish.astimezone(UTC)-dt.timedelta(minutes=30)).isoformat(),
        elapsed_hours=(finish.astimezone(UTC)-start.astimezone(UTC)).total_seconds()/3600,
        run_allocation_points=allocation, active_run=ledger.get('active_run'),
        existing_journal=(ROOT/'runs'/f'{key}.json').exists(),
        heartbeat_segment_minutes=120)
    if not dry_run:
        if summary['existing_journal']:
            raise ValueError('Occurrence journal already exists; reconcile/resume it, never recreate.')
        config.setdefault('one_time_run_overrides', {})[key] = override
        config['development_partners_recurring'] = dict(enabled=True, authorized_on='2026-10-31',
            timezone='America/Los_Angeles', start_hour=22, elapsed_minutes=540,
            backlog_first=True, research_only=True, heartbeat_segment_minutes=120)
        tmp = config_path.with_suffix('.nightly.tmp')
        tmp.write_text(json.dumps(config, indent=2)+'\n')
        os.replace(tmp, config_path)
        out = ROOT/'runs'/key
        out.mkdir(parents=True, exist_ok=True)
        (out/'occurrence-plan.json').write_text(json.dumps(summary, indent=2)+'\n')
    return summary

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--date', default=dt.datetime.now(PACIFIC).date().isoformat())
    parser.add_argument('--dry-run', action='store_true')
    args=parser.parse_args()
    print(json.dumps(prepare(args.date,args.dry_run),indent=2))
