# Post-research handoff queue

`queue.py` is a Python standard-library SQLite queue. It **never calls an external API,
creates a CRM record, or sends email**. The connector worker owns those actions and must
reconcile Gmail, Instantly, HubSpot, inbox capacity, recipient timezone, and delivery policy.

## Research finish hook

Call `emit_event(run_journal, state_path, db_path=DEFAULT_DB)` from a finished research
journal, or use:

```
python3 queue.py emit-event --journal /absolute/partners-run.json --payload /absolute/state.json
python3 queue.py summary
python3 queue.py list --state crm_waiting
```

The journal must identify `workflow: partners`, a stable `id`, terminal `status`
(`complete`, `partial`, or `blocked`), and an aware `finished` timestamp. Only candidates
with `research_status: complete` are staged. A partial run can release saved completed
candidates while leaving provisional/inflight research untouched. Repeat events and
repeat observations update the same stable jobs; they never rearm an existing dispatch.

Payload accepts canonical `candidates` mapping/array or `outreach_candidates`. A candidate's
optional `outreach` mapping overlays connector facts. Required qualification is saved
`qualification: pass`, finite `calculated.total >= 70`, evidenced US practice, ownership,
decision authority, and an in-scope specialty/category. Commercial suitability delegates
to the installed `development-partners/scripts/commercial_fit.py`; the current approximate
six-provider screen can preserve uncertainty and the latest policy version must be applied.
Historical screen versions wait for refresh. Explicit `excluded`/`do_not_contact` blocks.

No record IDs, email, timezone, or connector receipts are guessed. Workers supply actual
`hubspot_company_id`, `hubspot_contact_id`, `email`, and IANA `timezone` through:

```
python3 queue.py update doctor:CANDIDATE_ID --facts /absolute/facts.json --draft /absolute/draft.json
```

Draft JSON requires `subject`, `body`, and `quality_review: passed`. States distinguish
qualification/CRM/email/timezone/draft waiting, `ready_to_schedule`, `anchor_waiting`,
`unknown_outcome`, `scheduled`, `sent`, and `suppressed`. No local ready state claims a
connector has accepted or sent anything.

## Separate operations sourcing

Each doctor gets an operations sourcing handoff immediately. The worker may source
multiple fitting titles; create a separate send job for each sourced person:

```
python3 queue.py add-operations doctor:CANDIDATE_ID --contact /absolute/contact.json
```

Contact facts need `stable_contact_id`, `title`, `role_fit_evidence`, and actual CRM/email
facts when available. The generated key is `operations:CANDIDATE_ID:STABLE_CONTACT_ID`.
Operations drafts may be prepared early, but sending waits for a confirmed doctor's
`actual_sent_at`, not a promised scheduled date. The target is the following Monday–Friday
at 11:30 in the operations recipient's timezone. If that date has passed, replan to the next
business day; never backdate. No holiday calendar is inferred.

## Connector dispatch and reconciliation

Before claiming a send, facts must include:

- `outreach_history_checked`: mapping with `gmail_receipt`, `instantly_receipt`, aware
  `checked_at`, and `already_contacted: false`.
- `delivery_requirements_satisfied: true`, set only after the current delivery requirements are satisfied. On October31 Fraser explicitly approved an overview link for new Instantly doctor emails; verify that link and both demos. Never silently change later requirements.

```
python3 queue.py claim doctor:CANDIDATE_ID
python3 queue.py receipt doctor:CANDIDATE_ID --file /absolute/connector-receipt.json
```

`claim` records a durable idempotency key and `unknown_outcome` **before** the external
call. The worker passes/preserves that key when supported. Claims are unique by job and
normalized recipient email across roles/candidates. After a timeout/restart, reconcile
the recipient and campaign in Instantly before any retry. This CLI deliberately has no
blind retry/reset command. Confirmed receipt JSON needs `outcome: scheduled|sent`, an
actual `connector_id`, and `actual_sent_at` for sent; attach the connector's full receipt.
Unknown outcomes retain their hold. History retains every recorded receipt and state change.

The worker remains responsible for initial and follow-up copy, attaching/enforcing the
approved PDF policy, two follow-ups, reply suppression, per-inbox allocation, overlap with
existing campaigns, and keeping the spreadsheet/CRM current. This queue is durable handoff
infrastructure, not an independently running delivery service.

Tests: `python3 -m unittest discover -s . -p test_queue.py -v`.
