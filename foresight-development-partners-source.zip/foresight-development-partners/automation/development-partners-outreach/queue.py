#!/usr/bin/env python3
"""Durable local handoffs. This program never sends mail or calls connectors."""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import math
import re
import sqlite3
from pathlib import Path
from zoneinfo import ZoneInfo

UTC = dt.timezone.utc
DEFAULT_DB = Path(__file__).with_name('queue.sqlite3')
COMMERCIAL_MODULE = Path('/Users/fraserduncan/.codex/skills/development-partners/scripts/commercial_fit.py')
TERMINAL = {'scheduled', 'sent', 'suppressed'}


def stamp():
    return dt.datetime.now(UTC).isoformat()


def aware(value):
    value = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if value.tzinfo is None:
        raise ValueError('A timestamp must include its timezone')
    return value


def next_business_send(anchor, timezone):
    """Next Monday-Friday at 11:30 in the recipient's IANA timezone."""
    local = aware(anchor).astimezone(ZoneInfo(timezone))
    day = local.date() + dt.timedelta(days=1)
    while day.weekday() >= 5:
        day += dt.timedelta(days=1)
    return dt.datetime.combine(day, dt.time(11, 30), ZoneInfo(timezone)).isoformat()


def connect(path=DEFAULT_DB):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(path), timeout=30)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA journal_mode=WAL')
    db.executescript('''
      CREATE TABLE IF NOT EXISTS events(
        run_id TEXT PRIMARY KEY, journal TEXT NOT NULL, ingested_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS jobs(
        key TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, role TEXT NOT NULL,
        parent_key TEXT, run_id TEXT NOT NULL, state TEXT NOT NULL,
        reason TEXT NOT NULL, payload TEXT NOT NULL, draft TEXT,
        planned_at TEXT, actual_sent_at TEXT, updated_at TEXT NOT NULL,
        FOREIGN KEY(parent_key) REFERENCES jobs(key));
      CREATE TABLE IF NOT EXISTS dispatches(
        key TEXT PRIMARY KEY REFERENCES jobs(key), idempotency_key TEXT UNIQUE NOT NULL,
        recipient TEXT UNIQUE NOT NULL, outcome TEXT NOT NULL, receipt TEXT, updated_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS history(
        id INTEGER PRIMARY KEY, job_key TEXT, at TEXT NOT NULL,
        action TEXT NOT NULL, details TEXT NOT NULL);
    ''')
    return db


def eligibility(c):
    if c.get('do_not_contact') or c.get('excluded'):
        return False, 'Explicit exclusion or do-not-contact'
    if c.get('research_status') != 'complete' or c.get('qualification') != 'pass':
        return False, 'Research incomplete or qualification did not pass'
    score = c.get('calculated', {}).get('total', c.get('score'))
    if not isinstance(score, (int, float)) or isinstance(score, bool) or not math.isfinite(score) or score < 70:
        return False, 'Final fit score must be at least 70'
    screen = c.get('screen') or {}
    # These checks must be supported by evidence; an old qualification label alone is insufficient.
    for name in ('us_practice', 'private_ownership', 'decision_authority'):
        check = screen.get(name) or {}
        if check.get('status') != 'pass' or not check.get('evidence'):
            return False, 'Needs current evidence for ' + name
    specialty = c.get('specialty_category') or c.get('specialty', '')
    supported = re.search(r'\b(neurology|cardiology|endocrinology|rheumatology|pulmonology|internal medicine|primary care|family medicine)\b', specialty.lower())
    if not supported:
        return False, 'Needs supported specialty classification from research'
    # Reuse the installed policy rather than maintaining a second commercial gate.
    if not COMMERCIAL_MODULE.exists():
        return False, 'Installed commercial policy unavailable'
    spec = importlib.util.spec_from_file_location('foresight_commercial_fit', COMMERCIAL_MODULE)
    commercial = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(commercial)
    if commercial.status(c) != 'pass':
        return False, commercial.reason(c)
    size = screen.get('practice_size') or {}
    estimated = size.get('status') != 'pass' or size.get('provider_count') is None
    return True, ('Eligible; approximate provider size, uncertainty preserved' if estimated else 'Eligible; current commercial screen passed')


def stage(c, draft=None):
    ok, reason = eligibility(c)
    if not ok:
        return ('suppressed' if c.get('do_not_contact') or c.get('excluded') else 'qualification_waiting'), reason
    if not c.get('hubspot_company_id') or not c.get('hubspot_contact_id'):
        return 'crm_waiting', reason
    if not c.get('email'):
        return 'email_waiting', reason
    if not c.get('timezone'):
        return 'timezone_waiting', reason
    ZoneInfo(c['timezone'])
    if not draft:
        return 'draft_waiting', reason
    return 'ready_to_schedule', reason


def audit(db, key, action, details):
    db.execute('INSERT INTO history(job_key,at,action,details) VALUES(?,?,?,?)',
               (key, stamp(), action, json.dumps(details, sort_keys=True)))


def upsert(db, key, c, role, run_id, parent=None):
    old = db.execute('SELECT * FROM jobs WHERE key=?', (key,)).fetchone()
    if old:
        previous = json.loads(old['payload'])
        c = dict(c)
        for field in ('hubspot_company_id', 'hubspot_contact_id', 'email', 'timezone',
                      'outreach_history_checked', 'delivery_requirements_satisfied',
                      'operations_sourcing'):
            if not c.get(field) and previous.get(field):
                c[field] = previous[field]
    draft = old['draft'] if old else None
    state, reason = stage(c, draft)
    if old and old['state'] in TERMINAL | {'dispatching', 'unknown_outcome'}:
        # Never overwrite dispatched facts or silently rearm a previous attempt.
        audit(db, key, 'repeat_observation', {'run_id': run_id, 'incoming_state': state})
        return
    if role == 'operations':
        # The practice-level sourcing task is distinct from each actual person's
        # send job. Preserve a completed source receipt across later run events.
        sourcing = c.get('operations_sourcing') or {}
        if key == 'operations:' + c['id'] and sourcing.get('status') == 'complete':
            state = 'sourcing_complete'
            reason = 'Source review saved; individual contacts have separate send jobs'
        doctor = db.execute('SELECT actual_sent_at FROM jobs WHERE key=?', (parent,)).fetchone()
        if state == 'ready_to_schedule' and not doctor['actual_sent_at']:
            state, reason = 'anchor_waiting', 'Doctor actual send not yet confirmed'
    db.execute('''INSERT INTO jobs(key,candidate_id,role,parent_key,run_id,state,reason,payload,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET
      run_id=excluded.run_id,state=excluded.state,reason=excluded.reason,
      payload=excluded.payload,updated_at=excluded.updated_at''',
      (key, c['id'], role, parent, run_id, state, reason, json.dumps(c, sort_keys=True), stamp()))
    audit(db, key, 'ingested', {'state': state, 'run_id': run_id})


def emit_event(run_journal, state_path, db_path=DEFAULT_DB):
    """Callable finish hook. A terminal partners journal releases only fully researched candidates.

    canonical state can contain `outreach_candidates` or `candidates`; each candidate may
    have an `outreach` overlay holding normalized connector facts. No CRM facts are inferred.
    """
    journal = json.loads(Path(run_journal).read_text())
    if journal.get('workflow') != 'partners' or journal.get('status') not in ('complete', 'partial', 'blocked') or not journal.get('finished'):
        raise ValueError('Only a finished terminal partners research journal can release outreach')
    aware(journal['finished'])
    run_id = journal['id']
    source = json.loads(Path(state_path).read_text())
    candidates = source.get('outreach_candidates', source.get('candidates', []))
    if isinstance(candidates, dict):
        candidates = [dict(c, id=c.get('id', key)) for key, c in candidates.items()]
    if not isinstance(candidates, list):
        raise ValueError('Candidate payload must be an array or mapping')
    db = connect(db_path)
    try:
        with db:
            db.execute('INSERT OR IGNORE INTO events VALUES(?,?,?)', (run_id, json.dumps(journal, sort_keys=True), stamp()))
            for raw in candidates:
                c = dict(raw)
                c.update(raw.get('outreach') or {})
                if not c.get('id'):
                    raise ValueError('Stable candidate ID required')
                if c.get('research_status') != 'complete':
                    continue  # No handoff for unsaved, queued, provisional, or inflight research.
                c['research_finished_at'] = journal['finished']
                key = 'doctor:' + str(c['id'])
                upsert(db, key, c, 'doctor', run_id)
                # The handoff exists immediately; operations sourcing can proceed before doctor sends.
                ops = dict(c)
                ops['hubspot_contact_id'] = None
                ops['email'] = None
                ops.pop('outreach_history_checked', None)
                ops.pop('delivery_requirements_satisfied', None)
                ops['operations_handoff'] = True
                ops['doctor_contact_id'] = c.get('hubspot_contact_id')
                old = db.execute('SELECT payload FROM jobs WHERE key=?', ('operations:' + str(c['id']),)).fetchone()
                if old:
                    prior = json.loads(old['payload'])
                    for field in ('hubspot_contact_id', 'email', 'timezone'):
                        if prior.get(field):
                            ops[field] = prior[field]
                upsert(db, 'operations:' + str(c['id']), ops, 'operations', run_id, key)
            audit(db, None, 'research_complete', {'run_id': run_id, 'candidate_count': len(candidates)})
        return summary(db)
    finally:
        db.close()


def summary(db):
    return {'states': [dict(r) for r in db.execute('SELECT role,state,count(*) AS count FROM jobs GROUP BY role,state')],
            'events': db.execute('SELECT count(*) FROM events').fetchone()[0]}


def update_job(db, key, facts=None, draft=None):
    row = db.execute('SELECT * FROM jobs WHERE key=?', (key,)).fetchone()
    if not row:
        raise ValueError('Unknown job')
    if row['state'] in TERMINAL | {'dispatching', 'unknown_outcome'}:
        raise ValueError('Dispatched or suppressed job requires reconciliation, not editing')
    c = json.loads(row['payload'])
    c.update(facts or {})
    if c['id'] != row['candidate_id']:
        raise ValueError('Stable candidate identity cannot change')
    draft = draft if draft is not None else row['draft']
    if isinstance(draft, dict):
        if not draft.get('subject') or not draft.get('body') or draft.get('quality_review') != 'passed':
            raise ValueError('Draft needs subject, body, and a passed quality review')
        draft = json.dumps(draft, sort_keys=True)
    state, reason = stage(c, draft)
    planned = None
    if state == 'ready_to_schedule':
        if row['role'] == 'operations':
            parent = db.execute('SELECT actual_sent_at FROM jobs WHERE key=?', (row['parent_key'],)).fetchone()
            anchor = parent['actual_sent_at']
            if not anchor:
                state, reason = 'anchor_waiting', 'Doctor actual send not yet confirmed'
        else:
            anchor = stamp()  # Approval/ready time; never backdate a delayed draft to research finish.
        if state == 'ready_to_schedule':
            planned = next_business_send(anchor, c['timezone'])
            if aware(planned) <= dt.datetime.now(UTC):
                planned = next_business_send(stamp(), c['timezone'])
    db.execute('UPDATE jobs SET payload=?,draft=?,state=?,reason=?,planned_at=?,updated_at=? WHERE key=?',
               (json.dumps(c, sort_keys=True), draft, state, reason, planned, stamp(), key))
    audit(db, key, 'updated', {'state': state, 'planned_at': planned})
    return dict(db.execute('SELECT * FROM jobs WHERE key=?', (key,)).fetchone())


def claim(db, key):
    row = db.execute('SELECT * FROM jobs WHERE key=?', (key,)).fetchone()
    if not row or row['state'] != 'ready_to_schedule' or not row['planned_at']:
        raise ValueError('Only a ready, dated draft may be claimed')
    if aware(row['planned_at']) <= dt.datetime.now(UTC):
        raise ValueError('Schedule is in the past; update the job to replan before claiming')
    c = json.loads(row['payload'])
    eligible, reason = eligibility(c)
    if not eligible:
        raise ValueError('Qualification changed before dispatch: ' + reason)
    review = json.loads(row['draft']) if row['draft'] else {}
    if review.get('quality_review') != 'passed' or not review.get('subject') or not review.get('body'):
        raise ValueError('Draft quality review has not passed')
    history = c.get('outreach_history_checked') or {}
    if not isinstance(history, dict) or not history.get('gmail_receipt') or not history.get('instantly_receipt') or not history.get('checked_at'):
        raise ValueError('Explicit Gmail and Instantly outreach-history receipts required')
    aware(history['checked_at'])
    if history.get('already_contacted') is not False:
        raise ValueError('Outreach history must confirm no prior contact; reconcile existing outreach instead')
    if c.get('delivery_requirements_satisfied') is not True:
        raise ValueError('Delivery requirements unresolved, including physician PDF; no silent link fallback')
    # Starts a durable intent BEFORE external API invocation by the worker. Any restart
    # must reconcile this exact recipient/campaign before deciding whether it is safe to retry.
    token = hashlib.sha256(('foresight-outreach-v1:' + key).encode()).hexdigest()
    recipient = c['email'].strip().lower()
    if db.execute('SELECT 1 FROM dispatches WHERE recipient=? OR key=?', (recipient, key)).fetchone():
        raise ValueError('Recipient already has a dispatch intent; reconcile instead of retrying')
    db.execute('INSERT INTO dispatches VALUES(?,?,?,?,?,?)', (key, token, recipient, 'unknown_outcome', None, stamp()))
    db.execute("UPDATE jobs SET state='unknown_outcome',updated_at=? WHERE key=?", (stamp(), key))
    audit(db, key, 'dispatch_claimed', {'idempotency_key': token})
    return {'job_key': key, 'idempotency_key': token, 'planned_at': row['planned_at'],
            'instruction': 'Worker must preserve connector receipts; reconcile before any retry.'}


def receipt(db, key, value):
    existing = db.execute('SELECT * FROM dispatches WHERE key=?', (key,)).fetchone()
    if not existing:
        raise ValueError('Claim dispatch before recording a connector receipt')
    outcome = value.get('outcome')
    if outcome not in ('scheduled', 'sent', 'unknown_outcome'):
        raise ValueError('Receipt outcome must be scheduled, sent, or unknown_outcome')
    if existing['outcome'] == 'sent' and outcome != 'sent':
        raise ValueError('A confirmed send cannot be downgraded')
    if outcome in ('scheduled', 'sent') and not value.get('connector_id'):
        raise ValueError('Confirmed connector identifier required')
    sent = value.get('actual_sent_at')
    if outcome == 'sent':
        if not sent:
            raise ValueError('Actual send timestamp required')
        aware(sent)
    db.execute('UPDATE dispatches SET outcome=?,receipt=?,updated_at=? WHERE key=?',
               (outcome, json.dumps(value, sort_keys=True), stamp(), key))
    db.execute('UPDATE jobs SET state=?,actual_sent_at=COALESCE(?,actual_sent_at),updated_at=? WHERE key=?',
               (outcome, sent, stamp(), key))
    audit(db, key, 'connector_receipt', value)
    # Actual sent event, not a promised schedule, releases the operations sending anchor.
    if outcome == 'sent':
        children = db.execute("SELECT key FROM jobs WHERE parent_key=? AND state='anchor_waiting'", (key,)).fetchall()
        for child in children:
            update_job(db, child['key'])


def add_operations(db, doctor_key, contact):
    """Materialize each sourced person separately; a practice may have several fitting titles."""
    doctor = db.execute("SELECT * FROM jobs WHERE key=? AND role='doctor'", (doctor_key,)).fetchone()
    if not doctor or not contact.get('stable_contact_id'):
        raise ValueError('Existing doctor and stable sourced-contact identity required')
    for field in ('title', 'role_fit_evidence'):
        if not contact.get(field):
            raise ValueError('Operations contact requires ' + field)
    c = json.loads(doctor['payload'])
    c.pop('email', None)
    c.pop('hubspot_contact_id', None)
    c.pop('outreach_history_checked', None)
    c.pop('delivery_requirements_satisfied', None)
    c.update(contact)
    c['id'] = doctor['candidate_id']
    key = 'operations:' + c['id'] + ':' + str(contact['stable_contact_id'])
    upsert(db, key, c, 'operations', doctor['run_id'], doctor_key)
    return {'job_key': key}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', default=str(DEFAULT_DB))
    sub = parser.add_subparsers(dest='action', required=True)
    emit = sub.add_parser('emit-event')
    emit.add_argument('--journal', required=True)
    emit.add_argument('--payload', required=True)
    sub.add_parser('summary')
    listing = sub.add_parser('list')
    listing.add_argument('--state')
    ops = sub.add_parser('add-operations')
    ops.add_argument('doctor_key')
    ops.add_argument('--contact', required=True)
    for name in ('update', 'claim', 'receipt'):
        p = sub.add_parser(name)
        p.add_argument('key')
        if name == 'update':
            p.add_argument('--facts')
            p.add_argument('--draft')
        elif name == 'receipt':
            p.add_argument('--file', required=True)
    args = parser.parse_args()
    if args.action == 'emit-event':
        print(json.dumps(emit_event(args.journal, args.payload, args.db), indent=2))
        return
    db = connect(args.db)
    try:
        with db:
            if args.action == 'summary':
                result = summary(db)
            elif args.action == 'list':
                result = [dict(r) for r in db.execute('SELECT * FROM jobs' + (' WHERE state=?' if args.state else ''), (args.state,) if args.state else ())]
            elif args.action == 'update':
                result = update_job(db, args.key, json.loads(Path(args.facts).read_text()) if args.facts else None,
                                    json.loads(Path(args.draft).read_text()) if args.draft else None)
            elif args.action == 'claim':
                result = claim(db, args.key)
            elif args.action == 'add-operations':
                result = add_operations(db, args.doctor_key, json.loads(Path(args.contact).read_text()))
            else:
                receipt(db, args.key, json.loads(Path(args.file).read_text()))
                result = {'recorded': args.key}
        print(json.dumps(result, indent=2))
    finally:
        db.close()


if __name__ == '__main__':
    main()
