import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('outreach_queue', Path(__file__).with_name('queue.py'))
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)


def candidate():
    checks = {key: {'status': 'pass', 'evidence': [{'url': 'https://example.org/team', 'fact': 'Verified'}]}
              for key in ('us_practice', 'private_ownership', 'decision_authority')}
    checks['commercial_policy_version'] = '2026-10-31.approx-six-minimum'
    checks['practice_size'] = {'status': 'pass', 'provider_count': 6, 'evidence': [{'url': 'https://example.org/team'}]}
    return {'id': 'c_test', 'research_status': 'complete', 'qualification': 'pass',
            'calculated': {'total': 70}, 'screen': checks, 'specialty': 'Cardiology', 'hubspot_company_id': '11',
            'hubspot_contact_id': '22', 'delivery_requirements_satisfied': True,
            'outreach_history_checked': {'gmail_receipt': 'gmail-search-id', 'instantly_receipt': 'instantly-search-id',
                                         'checked_at': q.stamp(), 'already_contacted': False}, 'email': 'doctor@example.org', 'timezone': 'America/Los_Angeles'}


class QueueTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.dbpath = self.root / 'queue.sqlite3'
        self.journal = self.root / 'journal.json'
        self.payload = self.root / 'payload.json'
        self.journal.write_text(json.dumps({'id': 'partners-test', 'workflow': 'partners',
                                          'status': 'complete', 'finished': '2026-10-31T18:00:00-07:00'}))
        self.payload.write_text(json.dumps({'candidates': {'c_test': candidate()}}))

    def tearDown(self):
        self.tmp.cleanup()

    def ingest(self):
        return q.emit_event(self.journal, self.payload, self.dbpath)

    def test_weekend_and_dst(self):
        self.assertEqual(q.next_business_send('2026-10-30T18:00:00-07:00', 'America/Los_Angeles'),
                         '2026-11-02T11:30:00-08:00')
        self.assertEqual(q.next_business_send('2026-11-06T18:00:00-05:00', 'America/New_York'),
                         '2026-11-09T11:30:00-05:00')
        self.assertEqual(q.next_business_send('2026-11-02T23:00:00-08:00', 'America/New_York'),
                         '2026-11-04T11:30:00-05:00')

    def test_journal_gate_and_idempotence(self):
        self.ingest()
        self.ingest()
        db = q.connect(self.dbpath)
        self.assertEqual(db.execute('SELECT count(*) FROM jobs').fetchone()[0], 2)
        self.assertEqual(db.execute('SELECT count(*) FROM events').fetchone()[0], 1)
        db.close()
        journal = json.loads(self.journal.read_text())
        journal['status'] = 'running'
        self.journal.write_text(json.dumps(journal))
        with self.assertRaises(ValueError):
            self.ingest()
        journal['status'] = 'partial'
        self.journal.write_text(json.dumps(journal))
        self.ingest()

    def test_threshold_and_approximate_six(self):
        c = candidate()
        c['calculated']['total'] = 69.99
        self.assertFalse(q.eligibility(c)[0])
        c['calculated']['total'] = 70
        c['screen']['practice_size']['provider_count'] = 3
        self.assertFalse(q.eligibility(c)[0])
        size = c['screen']['practice_size']
        size.update(provider_count=None, status='uncertain')
        self.assertTrue(q.eligibility(c)[0])
        c['do_not_contact'] = True
        self.assertEqual(q.stage(c)[0], 'suppressed')

    def test_completed_operations_source_does_not_rearm_or_release_people(self):
        self.ingest()
        db = q.connect(self.dbpath)
        c = candidate()
        c['operations_sourcing'] = {'status': 'complete', 'contact_ids': ['33']}
        with db:
            q.upsert(db, 'operations:c_test', c, 'operations', 'partners-test', 'doctor:c_test')
            person = q.add_operations(db, 'doctor:c_test', {
                'stable_contact_id': '33', 'title': 'Practice Manager',
                'role_fit_evidence': 'Current title and employer verified',
                'hubspot_contact_id': '33', 'email': 'manager@example.org'})
            q.update_job(db, person['job_key'], draft={
                'subject': 'Practice partnership', 'body': 'Reviewed body', 'quality_review': 'passed'})
        self.ingest()  # Older research event must not recreate unfinished sourcing.
        self.assertEqual(db.execute("SELECT state FROM jobs WHERE key='operations:c_test'").fetchone()[0],
                         'sourcing_complete')
        self.assertEqual(db.execute('SELECT state FROM jobs WHERE key=?', (person['job_key'],)).fetchone()[0],
                         'anchor_waiting')
        self.assertEqual(db.execute('SELECT count(*) FROM dispatches').fetchone()[0], 0)
        db.close()

    def test_missing_connector_facts_and_draft_review(self):
        c = candidate()
        c.pop('hubspot_company_id')
        self.assertEqual(q.stage(c)[0], 'crm_waiting')
        self.ingest()
        db = q.connect(self.dbpath)
        with db, self.assertRaises(ValueError):
            q.update_job(db, 'doctor:c_test', draft={'subject': 'hello', 'body': 'draft'})
        db.close()

    def test_unknown_outcome_never_retries_and_receipts_preserved(self):
        self.ingest()
        db = q.connect(self.dbpath)
        with db:
            q.update_job(db, 'doctor:c_test', draft={'subject': 'hello', 'body': 'Approved text', 'quality_review': 'passed'})
            claim = q.claim(db, 'doctor:c_test')
        self.assertTrue(claim['idempotency_key'])
        self.ingest()
        with self.assertRaises(ValueError):
            q.claim(db, 'doctor:c_test')
        with self.assertRaises(ValueError):
            q.update_job(db, 'doctor:c_test', facts={'email': 'other@example.org'})
        with db:
            q.receipt(db, 'doctor:c_test', {'outcome': 'scheduled', 'connector_id': 'campaign-123', 'raw': {'accepted': True}})
        saved = json.loads(db.execute('SELECT receipt FROM dispatches').fetchone()[0])
        self.assertEqual(saved['raw'], {'accepted': True})
        db.close()

    def test_claim_requires_cross_channel_history_and_delivery(self):
        self.ingest()
        db = q.connect(self.dbpath)
        with db:
            q.update_job(db, 'doctor:c_test', facts={'delivery_requirements_satisfied': False},
                         draft={'subject': 'hello', 'body': 'Approved text', 'quality_review': 'passed'})
        with self.assertRaises(ValueError):
            q.claim(db, 'doctor:c_test')
        with db:
            q.update_job(db, 'doctor:c_test', facts={'delivery_requirements_satisfied': True, 'outreach_history_checked': {}})
        with self.assertRaises(ValueError):
            q.claim(db, 'doctor:c_test')
        db.close()

    def test_operations_waits_for_actual_send_multiple_contacts(self):
        self.ingest()
        db = q.connect(self.dbpath)
        with db:
            op = q.add_operations(db, 'doctor:c_test', {'stable_contact_id': 'om1', 'title': 'Office Manager',
                'role_fit_evidence': 'Official team page', 'email': 'om@example.org', 'hubspot_contact_id': '33'})
            op2 = q.add_operations(db, 'doctor:c_test', {'stable_contact_id': 'om2', 'title': 'Director',
                'role_fit_evidence': 'Official team page', 'email': 'director@example.org', 'hubspot_contact_id': '44'})
            draft = {'subject': 'hello', 'body': 'Approved text', 'quality_review': 'passed'}
            self.assertEqual(q.update_job(db, op['job_key'], draft=draft)['state'], 'anchor_waiting')
            q.update_job(db, 'doctor:c_test', draft=draft)
            q.claim(db, 'doctor:c_test')
            q.receipt(db, 'doctor:c_test', {'outcome': 'scheduled', 'connector_id': 'campaign-123'})
        self.assertEqual(db.execute('SELECT state FROM jobs WHERE key=?', (op['job_key'],)).fetchone()[0], 'anchor_waiting')
        with db:
            q.receipt(db, 'doctor:c_test', {'outcome': 'sent', 'connector_id': 'campaign-123',
                                         'actual_sent_at': '2099-11-06T11:30:00-05:00'})
        row = db.execute('SELECT state,planned_at FROM jobs WHERE key=?', (op['job_key'],)).fetchone()
        self.assertEqual(row['state'], 'ready_to_schedule')
        self.assertEqual(row['planned_at'], q.next_business_send('2099-11-06T11:30:00-05:00', 'America/Los_Angeles'))
        self.assertNotEqual(op['job_key'], op2['job_key'])
        db.close()


if __name__ == '__main__':
    unittest.main()
