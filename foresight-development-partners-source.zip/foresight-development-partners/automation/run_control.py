#!/usr/bin/env python3
"""Local deadline/usage journal. Connectors remain in the parent chat."""
import argparse
import contextlib
import datetime as dt
import fcntl
import json
import os
from pathlib import Path
import uuid
import importlib.util
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
UTC = dt.timezone.utc
PACIFIC = ZoneInfo('America/Los_Angeles')

def stamp(value):
    return value.isoformat(timespec='seconds')

def parse(value):
    result = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('Timestamps require a timezone')
    return result

def read(path, default):
    return json.loads(path.read_text()) if path.exists() else default

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix('.' + uuid.uuid4().hex + '.tmp')
    pending.write_text(json.dumps(value, indent=2) + '\n')
    os.replace(pending, path)

def emit_postrun_handoff(run_path):
    """Emit durable work after research ends. Never invoke an external connector."""
    run = read(run_path, {})
    policy = read(ROOT / 'development-partners-outreach-policy.json', {})
    if run.get('workflow') != 'partners' or not policy.get('enabled'):
        return {'status': 'not_applicable'}
    try:
        config_path = ROOT.parent / 'Development Partners' / 'config.json'
        config = read(config_path, {})
        state_dir = Path(config['state_directory'])
        if not state_dir.is_absolute():
            state_dir = config_path.parent / state_dir
        queue_path = ROOT / 'development-partners-outreach' / 'queue.py'
        spec = importlib.util.spec_from_file_location('foresight_outreach_queue', queue_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        result = module.emit_event(run_path, state_dir / 'state.json',
                                   ROOT / 'development-partners-outreach' / 'queue.sqlite3')
        handoff = {'status': 'queued', 'summary': result,
                   'runbook': str(ROOT / 'development-partners-nightly' / 'POSTRUN.md')}
    except Exception as exc:
        # Research has already finished durably. Preserve a retryable handoff failure.
        handoff = {'status': 'needs_reconciliation', 'error': str(exc),
                   'runbook': str(ROOT / 'development-partners-nightly' / 'POSTRUN.md')}
    run['postrun_handoff'] = handoff
    write(run_path, run)
    return handoff

@contextlib.contextmanager
def locked():
    ROOT.mkdir(parents=True, exist_ok=True)
    with (ROOT / 'control.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        yield

def observe(ledger, used, reset, at):
    if used is None or reset is None or not 0 <= used <= 100:
        raise ValueError('Supply a current weekly usedPercent and resetsAt from get_usage_limits; fail closed when unavailable')
    key = str(reset)
    # Adjacent future timestamps are provider sampling jitter, not a real reset.
    previous = ledger.get('window_reset')
    if previous and key != previous and abs(int(key)-int(previous)) <= 60 and min(int(key),int(previous)) > at.timestamp():
        ledger.setdefault('reset_timestamp_reconciliations', []).append({'at':stamp(at),'reported':key,'retained':previous})
        key = previous
    if ledger.get('window_reset') != key:
        if ledger.get('window_reset'):
            ledger.setdefault('history', []).append({k: ledger[k] for k in ('window_reset', 'charged_points')})
        ledger.update(window_reset=key, charged_points=0.0, last_used=used)
    elif ledger.get('active_run'):
        # Conservative account-wide delta, including unrelated activity during a run.
        ledger['charged_points'] += max(0, used - ledger.get('last_used', used))
    ledger['last_used'] = used
    ledger['checked_at'] = stamp(at)
    allocation = float(read(ROOT / 'config.json', {}).get('budget_policy', {}).get('weekly_allocation_points', 40))
    if not 0 < allocation <= 100:
        raise ValueError('Invalid configured weekly allocation')
    ledger['allocation_points'] = allocation
    ledger['remaining_points'] = max(0, allocation - ledger['charged_points'])
    return ledger

def status(run, ledger, at, phase='research', seconds=0):
    seconds = max(0, seconds)
    cutoff = parse(run['research_until'] if phase == 'research' else run['write_until'] if phase == 'write' else run['finish_until'])
    time_ok = (cutoff - at).total_seconds() >= seconds + 2
    checked = parse(ledger['checked_at']) if ledger.get('checked_at') else at - dt.timedelta(days=1)
    usage_fresh = (at - checked).total_seconds() <= 300
    remaining = ledger.get('remaining_points', 0)
    run_used = None
    if run.get('run_allocation_points') is not None:
        # One explicitly authorized occurrence may exceed the ordinary shared allocation.
        # Keep charging the cumulative ledger; do not reset or enlarge later runs.
        same_window = ledger.get('window_reset') == run.get('usage_window_reset')
        run_used = max(0, ledger.get('charged_points', 0) - run['charged_points_at_start'])
        remaining = min(float(run['run_allocation_points']) - run_used, 100 - ledger.get('last_used', 100)) if same_window else 0
    budget_ok = remaining > 1 # one point safety margin
    # Saving/reconciliation must remain possible after a time or allowance limit.
    return {'run_id': run['id'], 'phase': phase, 'allowed': run['status'] == 'running' and (phase == 'save' or (time_ok and usage_fresh and budget_ok)),
            'seconds_left': max(0, int((cutoff-at).total_seconds())), 'usage_fresh': usage_fresh,
            'weekly_automation_points': round(ledger.get('charged_points', 0), 3),
            'remaining_points': round(max(0, remaining), 3), 'run_consumed_points': run_used,
            'research_until': run['research_until'], 'write_until': run['write_until'], 'finish_until': run['finish_until']}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['begin', 'check', 'observe', 'finish'])
    p.add_argument('--workflow', choices=['partners', 'cities', 'recontact', 'admins'])
    p.add_argument('--run-id')
    p.add_argument('--used', type=float)
    p.add_argument('--reset', type=int)
    p.add_argument('--phase', choices=['research', 'write', 'save'], default='research')
    p.add_argument('--seconds', type=float, default=0)
    p.add_argument('--outcome', choices=['complete', 'partial', 'blocked'], default='partial')
    args = p.parse_args()
    at = dt.datetime.now(UTC)
    with locked():
        ledger_path = ROOT / 'usage-ledger.json'
        ledger = read(ledger_path, {})
        if args.action in ('begin', 'observe', 'finish'):
            observe(ledger, args.used, args.reset, at)
        if args.action == 'begin':
            if not args.workflow:
                p.error('begin needs --workflow')
            if ledger.get('active_run'):
                raise ValueError('Unfinished run '+ledger['active_run']+'; reconcile it before starting another, even after its deadline')
            minutes = 45 if args.workflow == 'recontact' else 60 if args.workflow == 'admins' else 120
            key = args.workflow + '-' + at.astimezone(PACIFIC).strftime('%Y-%m-%d')
            if args.run_id:
                if Path(args.run_id).name != args.run_id or not args.run_id.startswith(key + '-screen-retest-'):
                    raise ValueError('Explicit begin ID must identify an authorized same-date screen retest')
                key = args.run_id
            overrides = read(ROOT / 'config.json', {}).get('one_time_run_overrides', {})
            intensive_key = key + '-intensive'
            intensive = overrides.get(intensive_key, {})
            if intensive and at >= parse(intensive['start_local']) and at < parse(intensive['finish_local']):
                key = intensive_key
            override = overrides.get(key, {})
            if override and (override.get('authorized') is not True or override.get('workflow') != args.workflow):
                raise ValueError('Invalid one-time authorization')
            available = min(float(override['run_allocation_points']), 100 - args.used) if override else ledger['remaining_points']
            if available <= 1:
                raise ValueError('Authorized allowance reached; no new run')
            if override:
                minutes = int(override['minutes'])
            path = ROOT / 'runs' / (key + '.json')
            if path.exists():
                raise ValueError('This workflow/date already has a journal; do not repeat it automatically')
            end = min(at + dt.timedelta(minutes=minutes), parse(override['finish_local'])) if override.get('finish_local') else at + dt.timedelta(minutes=minutes)
            reserve = 20 if args.workflow in ('partners', 'admins') else 15
            run = {'id': key, 'workflow': args.workflow, 'started': stamp(at), 'status': 'running',
                   'research_until': stamp(end-dt.timedelta(minutes=reserve)),
                   'write_until': stamp(end-dt.timedelta(minutes=5)), 'finish_until': stamp(end),
                   'usage_at_start': args.used, 'outputs': [], 'slack_status': ('ready_bot_webhook' if (ROOT / 'slack-webhook-secret.json').exists() else 'held_sender_not_configured')}
            if override:
                research_minutes, write_minutes = int(override['research_minutes']), int(override['write_minutes'])
                if not 0 < research_minutes < write_minutes < minutes <= 540 or not 0 < float(override['run_allocation_points']) <= 40:
                    raise ValueError('Invalid one-time limits')
                run.update(research_until=stamp(end-dt.timedelta(minutes=minutes-research_minutes)), write_until=stamp(end-dt.timedelta(minutes=minutes-write_minutes)),
                           run_allocation_points=override['run_allocation_points'], charged_points_at_start=ledger.get('charged_points',0),
                           usage_window_reset=ledger['window_reset'], one_time_override=override)
            write(path, run)
            ledger['active_run'] = key
            write(ledger_path, ledger)
            print(json.dumps(run))
            return
        ident = args.run_id or ledger.get('active_run')
        if not ident or Path(ident).name != ident:
            raise ValueError('A valid existing run ID is required')
        run_path = ROOT / 'runs' / (ident + '.json')
        run = read(run_path, {})
        if not run or ledger.get('active_run') != ident:
            raise ValueError('Run is not the active journal')
        if args.action == 'finish':
            run.update(status=args.outcome, finished=stamp(at), usage_at_finish=args.used)
            ledger['active_run'] = None
            write(run_path, run)
        write(ledger_path, ledger)
        result = status(run, ledger, at, args.phase, args.seconds)
        if args.action == 'finish':
            result['postrun_handoff'] = emit_postrun_handoff(run_path)
        print(json.dumps(result))
        if args.action != 'finish' and not result['allowed']:
            raise SystemExit(2)

if __name__ == '__main__':
    main()
