"""Parent wall-clock stage receipts; worker durations must remain separate."""
import argparse,datetime as dt,json,uuid
from pathlib import Path
from run_control import ROOT,locked,read,write
STAGES=('discovery','runner','clay','crm','checkpoint','export','report')
def record(run_id,stage,event,span_id=None):
 if Path(run_id).name!=run_id or stage not in STAGES or event not in ('begin','end'):raise ValueError('Invalid stage event')
 journal=ROOT/'runs'/(run_id+'.json')
 if not journal.exists():raise ValueError('Begin workflow journal first')
 path=ROOT/'runs'/run_id/'parent-timing.json'
 with locked():
  d=read(path,{'run_id':run_id,'spans':[]})
  if event=='begin':
   span={'id':str(uuid.uuid4()),'stage':stage,'started_at':dt.datetime.now(dt.timezone.utc).isoformat()};d['spans'].append(span)
  else:
   found=[s for s in d['spans'] if s['id']==span_id and s['stage']==stage]
   if len(found)!=1:raise ValueError('Use actual matching span ID')
   span=found[0]
   if span.get('finished_at'):return span
   end=dt.datetime.now(dt.timezone.utc);span.update(finished_at=end.isoformat(),wall_seconds=round((end-dt.datetime.fromisoformat(span['started_at'])).total_seconds(),3))
  write(path,d);return span
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('event',choices=['begin','end']);p.add_argument('--run-id',required=True);p.add_argument('--stage',choices=STAGES,required=True);p.add_argument('--span-id');a=p.parse_args();print(json.dumps(record(a.run_id,a.stage,a.event,a.span_id)))
