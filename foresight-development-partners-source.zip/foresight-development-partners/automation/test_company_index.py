import json,tempfile,unittest,datetime as dt
from pathlib import Path
import company_index as i

def row(id='1',name='Test Clinic',domain='test.example',phone='4805551212'):
 return dict(id=id,properties=dict(name=name,domain=domain,phone=phone))

class IndexTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.c=i.connect(Path(self.tmp.name))
 def tearDown(self):self.c.close();self.tmp.cleanup()
 def test_exact_identity_and_shared_domain_ambiguity(self):
  i.upsert(self.c,[row()], 'https://example.com/{id}?utm_source=test')
  self.assertEqual(i.lookup(self.c,dict(name='Test Clinic',website='https://www.test.example/team'))['status'],'existing')
  i.upsert(self.c,[row('2','Different Clinic')],'https://example.com/{id}')
  self.assertEqual(i.lookup(self.c,dict(domain='test.example'))['status'],'possible_match')
  self.assertEqual(i.lookup(self.c,dict(name='Test Clinic',domain='test.example'))['status'],'possible_match')
 def test_changed_fields_remove_obsolete_domain_but_keep_name_history(self):
  i.upsert(self.c,[row()],'https://example.com/{id}')
  i.upsert(self.c,[row(name='New Brand',domain='new.example')],'https://example.com/{id}')
  self.assertEqual(i.lookup(self.c,dict(domain='test.example'))['status'],'not_in_index')
  self.assertEqual(i.lookup(self.c,dict(name='Test Clinic'))['matches'][0]['id'],'1')
 def test_name_alone_does_not_drop_same_name_clinic(self):
  i.upsert(self.c,[row()],'https://example.com/{id}')
  self.assertEqual(i.lookup(self.c,dict(name='Test Clinic'))['status'],'possible_match')
 def test_refresh_only_advances_watermark_after_terminal_page(self):
  old=(i.now()-dt.timedelta(days=1)).isoformat();i.put(self.c,'baseline',dict(complete=True));i.put(self.c,'watermark',old)
  q=i.plan(self.c);sync=i.get(self.c,'refresh');r=row();r['properties']['hs_lastmodifieddate']=sync['lower']
  out=i.import_page(self.c,dict(results=[r],urlTemplate='https://example.com/{id}'))
  self.assertFalse(out['done']);self.assertEqual(i.get(self.c,'watermark'),old)
  with self.assertRaises(ValueError):i.import_page(self.c,dict(results=[r]))
  out=i.import_page(self.c,dict(results=[]));self.assertTrue(out['done']);self.assertEqual(i.get(self.c,'watermark'),sync['upper'])
 def test_live_readback_upsert_is_immediately_searchable_and_preserves_id(self):
  r=row('225283199971');i.upsert(self.c,[r],'https://example.com/{id}')
  self.assertEqual(i.lookup(self.c,dict(name='Test Clinic',domain='test.example'))['matches'][0]['id'],'225283199971')

if __name__=='__main__':unittest.main()
