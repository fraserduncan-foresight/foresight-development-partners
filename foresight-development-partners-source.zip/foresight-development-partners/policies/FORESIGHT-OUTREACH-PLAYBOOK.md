# Foresight development partnership outreach

## Opening bridge preference — latest October 31 feedback

The second sentence of the opening must connect to the first sentence's sourced idea and transition smoothly into the Foresight partnership paragraph. Do not force a complicated connection, invent a workflow problem, or add generic praise to manufacture that bridge. When a more specific connection is unclear or cumbersome, Fraser explicitly approves these simple alternatives:

- “I’d be interested to hear where else you think AI could help your team.”
- “When you mentioned AI helping establish those processes, I wanted to ask which one you would choose to improve first in your own practice.”
- “I’d be interested to hear where you see the most potential for AI at [company].”

Choose the line that follows naturally from the actual source. “Where else” requires an existing AI use in the opening, and the processes example requires that the source actually mentioned AI helping establish processes. Replace [company] with the verified practice name. These are approved fallbacks, not mandatory repeated wording. Prefer a simple, natural bridge over a strained attempt to be highly personalized. Review the sourced first sentence, bridge, and Foresight paragraph together before scheduling.

Standing user preferences, updated October 30, 2026.

- Every initial email's middle partnership paragraph must explicitly include prior authorizations and referrals, alongside practice-specific workflow ideas.
- Use the exact linked label "Check out this Infusion workflow demo" for https://www.loom.com/share/3a111521d9334d6eb4d90ca831f842b9.
- Use the exact linked label "Check out this HCM workflow demo" for https://www.loom.com/share/a162868f7e2e4ab8b1483a9aaceba2aa.
- Avoid colons and semicolons within email paragraphs. Use a normal hyphen instead of an em dash.
- Prefer enjoyed when it fits a sourced opening. Connect the two opening sentences naturally and avoid repeating the middle paragraph's workflow pitch.
- Make the connection between the sourced opening and the partnership offer explicit. Explain the relevant next step in patient care, the work around an existing tool, or the physician-led building approach we share. Generic praise for AI followed by an unrelated list of workflows is insufficient. Keep proposed opportunities clearly separate from verified practice problems, and respect DPC practices that do not bill insurance.
- Keep blank lines between paragraphs and clean signature spacing.
- Format the two demo hyperlinks as separate native filled-circle bullet points, matching Debra Graetz's draft. Keep the full label clickable and use the same bullet style for both links.
- Preserve each doctor's researched personalization and acknowledge their existing software. Proposed workflow ideas are not claims of verified practice problems or existing Foresight integrations.
- Subject format is [Practice] × Foresight - AI development partnership.
- When approved for sending, the Emi one-pager must be an actual PDF attachment. Do not turn it into a hyperlink.
- Operations-contact outreach exception, approved October 31, 2026: use a linked Emi one-pager beneath both demos instead of a PDF attachment. Label it "Read the Emi one-page overview" and use https://drive.google.com/file/d/1CeXAF60b4hcTHNgp9VbYJufK2ZDMjt-2/view . Physician outreach retains its attachment preference.
- Operations-contact scheduling, approved October 31, 2026: use Instantly, on the next business day after the linked physician's verified sent/scheduled email date, beginning at 9:30 a.m. recipient local time. Catch up already-past physician dates on the next available business day. Current campaigns use 09:30–09:59 local windows with one-minute spacing and two same-thread follow-ups seven calendar days apart, stopping on replies and auto-replies. Hold missing work emails or unverified physician dates. Preserve role-specific openings for multiple contacts at the same practice.
- Sending volume preference, approved October 31, 2026: keep total outreach at or below 30 emails per day per inbox, including initial emails and follow-ups across Gmail and Instantly. Rebalance not-yet-sent outreach onto Fraser’s newly purchased team-workspace inbox after verifying the account. Preserve the original sender for threads already started.
- Operations follow-up copy preference, approved October 31, 2026: email two should be short and generic, and email three should be short with clinic-specialty workflow examples. Keep both as replies in the original thread, seven calendar days apart, stopping on replies.
- Omit the sentence "I’ve attached a one-page overview of Emi, our AI health assistant." from draft email bodies.
- Omit the sentence "These two short demos show what we’re already building:" from draft email bodies. Keep the two demo hyperlinks themselves.
- Scheduling uses a split between 12:15 p.m. and 4:30 p.m. in each recipient's local time, with two follow-ups five business days apart in the same thread. Draft preparation alone does not authorize sending or scheduling.
- Laura Lile / Lile Wellness Partners is Do not contact by Fraser's explicit October 30, 2026 instruction due to potential competitive overlap. Do not send the initial email, follow-ups, demos or Emi PDF unless Fraser explicitly reverses that instruction.

Existing shared draft document https://docs.google.com/document/d/1VloeuFJyIlmnGIbAbdt0PC-uRkWs8d9botMRV1nhIJA.

## Quality at scale — October 31, 2026

Fraser wants to scale toward 400 unique clinics with at least one usable contact email and 10 clinic meetings over the next 30 days. Keep clinic-level deduplication across doctors and operations contacts. The working funnel remains 50% of clinics reading and 5% of those clinics replying to arrange a meeting. These are planning assumptions, not observed conversion rates. Requests to trust the agent's drafting do not authorize unapproved sending or scheduling. LinkedIn outreach remains paused except the separately authorized Monday November 2, 9:30 a.m. Pacific blank-connection-request task.

Drafting must include a separate critique and revision pass before a draft is considered ready:

- Verify the identity, current practice, role and exact source behind the personalized opening. Do not infer a practice problem from specialty alone.
- The opening's second sentence must develop the first sentence's specific idea. Reject a generic compliment followed by an unrelated operational pitch.
- The transition into the Foresight paragraph must follow naturally from that same idea, without repeating the opening or forcing a sales bridge.
- Use simple, concrete language about getting work done and automating processes. Remove generic flattery, awkward praise, jargon and unsupported promises.
- Include prior authorizations and referrals in the partnership paragraph, with appropriate outside-care qualifications for DPC. Include clinic-specific examples as starting points, preserving the broader scope of what the team can choose to build.
- Compare against Fraser-approved edits and preserve the existing source-supported personalization, demo labels/order/bullets, paragraph spacing, signature and attachment/link rules.
- Check multiple recipients at one clinic together for role differentiation and repetitive openings. Count the clinic once for growth and meeting reporting.
- Route genuine identity, fact or eligibility conflicts as exceptions. Do not make Fraser rewrite every routine draft. Report quality issues and revise before requesting review.

Changing a prospect score threshold is separate from completing outreach drafts. On October 31 Fraser asked for the 60–75 inventory; this is not yet an instruction to enrich, import or send to every record in that band. Preserve specialty and eligibility gates and existing exclusions regardless of numeric score.

## Automatic post-research pipeline — latest October 31 authorization

Fraser subsequently set the automatic pipeline threshold to **70 or higher**, not 60. New target practices should have a quick credible indication of approximately six clinical providers. Lean toward inclusion for genuinely ambiguous or partial counts, retaining estimates/unknowns honestly; do not describe a clearly complete roster below six as meeting the requirement. Other specialty, ownership, US practice, authority, maximum-size and do-not-contact gates remain.

The END of the Development Partners research run triggers enrichment, CRM preparation/registration, individualized doctor drafts and an operations-contact agent handoff. Do not spend the nine-hour scraping/scoring window on emails. Allocate an additional initial two-hour postrun block, as a maximum for the entire enrichment, CRM, sourcing, drafting, review and scheduling workflow. Draft promptly from saved research, typically around30seconds for straightforward cases, and review accuracy, sentence/paragraph flow and formatting in batches. Do not impose a6–10minute per-doctor budget or an artificial email-count cap. Spend extra time only on real gaps or difficult cases, and carry unfinished work forward rather than producing weak copy.

All new pipeline emails use Instantly. Once the HubSpot doctor contact exists and a source-backed email is identified, schedule the quality-checked doctor initial for 11:30 a.m. recipient local time on the next business day. The associated operations email goes one business day AFTER the linked doctor's initial email, also 11:30 local. Anchor operations dispatch to verified doctor send status so delayed/failed doctor sends cannot be overtaken. All follow-ups count toward 30 emails per inbox per day; keep the same sender and thread, and stop on replies. Overflow waits for capacity; multiple inboxes do not eliminate the per-inbox cap. No teammate inbox use without authorization.

The operations agent may identify multiple current fitting-title contacts per clinic, with title/specialty-specific copy. Use official sites, current profiles and supported Clay enrichment, preserving actual task IDs. It need not prove that each individual owns a particular operational process. Parent coordinator serializes canonical and CRM writes, following actual connector approval requirements. A new-contact/new-company handoff must contain verified IDs, email/source status, practice/specialty/location/timezone, doctor source personalization and outreach history. Missing email, incomplete quality review, unresolved identity, unavailable sending inbox or unknown prior write outcome remains an explicit queue state.

This explicitly authorizes future doctor and operations email scheduling once all conditions and connector requirements are satisfied; it supersedes prior manual-send approval for that new pipeline. It does not authorize immediate Saturday outreach, automatic migration of previously scheduled emails, LinkedIn sends outside the Monday exception, or silently replacing physicians' required actual PDF with a hyperlink. Instantly campaign attachment capability and correct team-workspace connector access must be verified before affected doctor schedules are declared live.

### Final setup decisions — October 31

Fraser explicitly approved "Use an overview link instead" for the NEW Instantly doctor pipeline. New doctor and operations emails therefore both use the linked label "Read the Emi one-page overview" under the demo bullets, pointing to https://drive.google.com/file/d/1CeXAF60b4hcTHNgp9VbYJufK2ZDMjt-2/view . This supersedes the real-PDF requirement for new Instantly pipeline emails only; existing scheduled doctor messages are not migrated or edited by this decision.

Fraser also explicitly approved skipping routine HubSpot field and association confirmations in this chat for verified 70+ development partners and fitting operations contacts. The scoped authorization is saved in Automation/development-partners-outreach-authorization.json. Use CONFIRMATION_WAIVED_FOR_SESSION only within this chat/scheduled-followup scope; continue to hold identity/employer conflicts, prior exclusions and unsupported facts.


- Exact operations email-two wording approved October 31, 2026: "Hey! Just wanted to follow up on the above here. Thank you!" Use without an added greeting or signature. Email three retains the short specialty-specific workflow paragraph and 20-minute conversation invitation.


### Sender restriction — latest October31 instruction

For all NEW postrun pipeline emails, use ONLY fraser.duncan@meetforesighthealth.org in the team Foresight Instantly workspace until Fraser changes this instruction. Fill available capacity up to30total emails/day including followups, without lowering readiness/quality checks. No fallback to the original inbox or teammate inboxes. Fraser will reconnect the plugin; browser fallback may use only this account. Leave existing scheduled batches in place unless separately instructed to migrate them.
