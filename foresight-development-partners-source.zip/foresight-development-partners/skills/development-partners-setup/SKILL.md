---
name: development-partners-setup
description: Set up Foresight Development Partners on a colleague's computer, verify the shared master and required account connections, and show how to submit a physician or hot zone.
---

# Development Partners setup

Locate the sibling `development-partners` skill folder. Read its `references/shared-master.md` and follow its setup and checkout protocol. This is Foresight's internal workflow, not a request to publish it publicly or run prospect research.

1. Check available Supabase, Clay and HubSpot tools. Use plugin-management search/suggestions for missing plugins and let the user authenticate using the normal connection flow. Never request passwords, API tokens or another colleague's session files in chat.
2. Through Supabase, verify authorized access to project `svdtzmjpqvdvntlicpvt` and read only `development_partners.master`/`run_lock` metadata. Do not inspect unrelated validator data. Do not create another project/master or invite users automatically. Organization access must be arranged by their administrator; this free-plan setup does not isolate organization administrators from the existing validator project.
3. Verify Clay workspace `723119` and available company enrichment function. Verify HubSpot portal `342239911`, current CONTACT/NOTE permissions, `hs_role` Development Partner option and `development_partner_fit_score`. Reuse existing setup; never recreate fields or run enrichment/CRM writes as a setup test. Missing permissions are reported by stage. Read the installed HubSpot skill before its tools.
4. Load this computer's workspace dependency paths. Choose a writable `Development Partners` data folder in the current project/workspace, outside installed plugin caches. Reuse any existing matching config. Otherwise run sibling `scripts/configure_shared.py` with the actual local Python, Node and node_modules paths. All future runner commands pass this config explicitly. Do not use packaged placeholder runtime paths.
5. Checkout the shared master under this user's label. Busy means another colleague is working; report it and stop the setup test without stealing their lease. After successful restore, run `doctor` and `sync`, confirm saved candidate count, and save/release through Supabase. No research, enrichment or registration is part of this test.
6. Report actual ready/blocked connections and the saved config path. Explain: everyone shares the same Supabase master; local spreadsheets are exports; input goes through chat; overlapping runs wait; existing research/enrichment is reused unless a fresh rerun is explicitly requested. Show two examples: `$development-partners Dr. [name], [practice]` and `$development-partners [hot-zone URL]`. A city/state starts from existing HubSpot clinic companies.

Do not claim installation or connections are complete without verification. Keep this onboarding brief, and resume pending setup only after the user completes any required account connection. CRM confirmation waivers are session-specific and do not transfer from Fraser's chat.
