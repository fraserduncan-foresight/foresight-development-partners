# Clay enrichment after score-based or manual authorization

Use the existing parent-chat Clay MCP connection. The Python runner prepares/persists work; it does not independently authenticate to Clay or call the desktop plugin. Screening/scoring workers remain unchanged. The subsequent HubSpot step is described in `handoff.md`; outreach remains outside scope.

## Start and selection

After a research run, return the ranked shortlist and wait for user handpicks. Do not automatically enrich scores above 75. When the user explicitly asks to proceed with selected physicians, save their enrichment choice Yes, call `handoff-plan`, and continue only those candidates. Requests for more detail stay read-only. Qualification and assessment-completeness gates remain unchanged. Preserve and reuse prior task/results; do not charge for the same completed lookup again.

Run `clay-plan`. Verify the connected workspace through Clay `get_current_workspace` matches config workspace **723119 / Foresight Health**. If it differs, stop Clay dispatch and report the mismatch. Call `list_subroutines` before using a saved function ID; verify **Enrich Company** still has ID `t_0tl35mnXjAVng3WfedR` and input `Company Identifier`. A changed function requires updating the verified configuration, never guessing inputs. These are read-only connection checks; no contact search is necessary for setup.

Default output: separately sourced first/last names, person LinkedIn, current role, work email with returned validation status, practice LinkedIn/address and employee count when available. Reuse known sourced names; do not request them again or guess name parts. Preserve unknowns. Employee count is a provider estimate, not a verified provider/clinic count. No personal mobile lookup by default. Do not run news, traffic, technology or custom scoring enrichments unless needed/requested. A website technology detector does not prove internal clinical AI deployment.

## Prepare, dispatch, save and resume

All commands use `scripts/partner_pipeline.py` and its configured bundled Python. Commands import saved Excel selections before applying the gate.

1. Run `clay-reuse --candidate ID ...` to reuse completed practice fields for the same verified domain and practice. This does not call Clay. Read `clay-plan` again.
2. For selected people lacking a saved Clay contact, run `clay-prepare --kind lookup --candidate ID ...`. It saves a reserved request and returns its ID, exact MCP `tool` and `arguments`. Call that tool once using those arguments. Batch the approved names together. Existing task contacts use their saved IDs rather than a new search.
3. Immediately record the returned real task ID with `clay-task --request REQUEST_ID --task-id TASK_ID`, before further calls. If a call has an unknown outcome, leave the reservation in place and recover the original task from the tool response/history. Do not resubmit blindly. A reserved request is not evidence that the remote call succeeded.
4. Fetch `get_task_context` for the task, including every page (`hasMore`) or requested entity. Poll while in progress; use short waits with useful updates. After roughly two minutes without completion, leave the task submitted and save/report pending work, then resume by polling on the next invocation. This is a polling checkpoint, not cancellation or a candidate/batch limit. Do not interpret `isComplete` as all entities succeeding: check each enrichment's error/status. For search tasks inspect all requested entities and their individual states.
5. Verify the person by name AND matching practice/domain/professional context. For company results verify the organization/domain before sharing its fields. No/ambiguous match populates no fields. Keep source/provider validation status as returned; do not describe an unverified email as verified.
6. Save the normalized results JSON below with the unmodified task context response(s) in `raw_context`, then call `clay-results --request REQUEST_ID --file ABSOLUTE_JSON`. It validates task/workspace/candidate identity, records field provenance and updates the master. This importer does not itself establish factual accuracy: compare every normalized field with the raw Clay response before importing. Preserve sources returned by Clay. If no provider URL is returned, label its source `Clay: FUNCTION_OR_DATA_POINT, task TASK_ID` rather than inventing a citation.
7. For matched contacts missing work email, inspect the existing task context first to check whether Email was already enriched. If not, run `clay-prepare --kind email --candidate ID ...` for contacts sharing one saved task. Execute its returned `add_contact_data_points` arguments once, record the task ID (it can be the same search task), poll and import as above. Do not rerun an Email enrichment already present/in progress/errored in task context. Import available results or report the provider error.
8. For practices with missing company fields and no cached result, run `clay-prepare --kind company --candidate ID ...`. It deduplicates the same practice domain into one function input. Execute the returned `run_subroutine_direct` call, record task, poll and import. Map outputs back using returned input/domain/entity information, never assume result order. Resolve different practices on one shared domain before sharing results. The API's 1000-input call limit is a transport page size, not a workflow candidate cap: continue additional calls if necessary.

The bridge blocks repeat requests of the same kind for previously requested candidates, including errors/no-match, so they are not silently charged again. Resume submitted tasks by polling. For a deliberate retry after resolving an identity/provider failure, inspect the saved request and use `clay-retry --request ID` with the user's retry authorization. It archives only completed requests and preserves successful fields and task IDs. An archived request can be retried. Never archive a reserved/submitted request to work around an unknown remote outcome.

Normalized import format (all IDs and values below are schema placeholders, not real research):

```json
{
  "workspace_id": 723119,
  "task_id": "RETURNED_TASK_ID",
  "task_complete": true,
  "raw_context": [{"unmodified": "actual get_task_context response(s)"}],
  "results": [{
    "candidate_id": "SAVED_CANDIDATE_ID",
    "entity_id": "RETURNED_ENTITY_ID",
    "match": "confirmed",
    "identity_evidence": "Explain the actual matching name, employer/domain and location where available",
    "fields": {
      "linkedin": {"value": "RETURNED_LINKEDIN_URL", "source": "RETURNED_SOURCE_OR_CLAY_TASK_LABEL", "status": "RETURNED_PROVIDER_STATUS"},
      "job_title": {"value": "RETURNED_TITLE", "source": "RETURNED_SOURCE_OR_CLAY_TASK_LABEL", "status": "RETURNED_PROVIDER_STATUS"}
    },
    "note": "Missing fields, provider errors or match context",
    "review_note": "Material contradiction affecting qualification/score, if any"
  }]
}
```

Use one result per requested candidate. `match` is confirmed/no_match/ambiguous/error. Unconfirmed results have empty fields. Lookup/email allowed fields: first_name, last_name, linkedin, job_title, work_email, email_status. Company allowed fields: company_linkedin, practice_address, employee_count (numeric or null). Do not invent missing values or statuses. Partial data remains Partial. Existing nonempty fields are preserved; conflicting new values go in review_note instead of silently replacing them. Jobs and raw contexts remain in durable state for resumption/provenance. New material ownership/clinic AI coverage evidence prompts a targeted review; do not rerun full research or apply an AI deduction from a website stack.

Current practice-first policy (2026-10-21): Current independently controlled practice: maximum 10 clinic locations AND 60 clinical providers (physicians and NP/PA, not employees). Exactly 10/60 is allowed. Start with the official Locations and Providers/Team pages. Count unique locations and MD/DO/DPM/NP/PA clinicians as applicable to this physician practice, never duplicate staff cards. A clearly complete official roster or a source-supported upper bound within both limits suffices; label a bound explicitly in explanation rather than describing it as an exact count. Do not perform an exhaustive registry census or hunt for an exact number once a reliable within-limit bound is established. A short featured list is not a complete roster. More than either limit fails; genuinely incomplete coverage stays uncertain with the missing page/check identified. Existing AI adoption may be retained as incidental evidence. Existing AI adoption carries no deduction or screening/handoff exclusion; no dedicated AI deployment check is needed. No AI absence check in initial screening. New scores must use current practice and scoring policy before handoff; no automatic revival of historical scores.

EMAIL-FIRST CLAY SCOPE — OCTOBER22 USER UPDATE
User needs name and work email; phone is optional. Reuse names from research. Paid company enrichment (LinkedIn/address/headcount/firmographics) is disabled on this Mac. No paid phone/mobile waterfall by default. Phone may be saved only when source-backed and correctly labelled. Missing job title, LinkedIn, company address/headcount or phone never makes an otherwise name+email-complete enrichment incomplete. Preserve provider email status without inventing deliverability validation. Returned incidental base metadata is not a separately requested enrichment and must not be claimed as charged. Credit consumption is unknown unless actual usage receipts/billing supply it.
Prioritize an existing usable work email and existing Clay task/context. A name/domain lookup miss is not proof no email exists. Use the strongest verified identifiers already available (practice domain/company LinkedIn, physician profile, supported published name aliases) for one materially different bounded fallback when supported. Before a direct Work Email function fallback, verify current function inputs and preserve actual receipts; do not run broad Enrich Person/Company or Mobile functions as substitutes. Stop after success, definitive provider error or bounded no-result; no unchanged retries. Credit errors are function-specific unless actual workspace-wide block is returned. Qualified physicians lacking email remain marked missing email rather than enriched success. No additional paid dispatch occurred during this audit.
