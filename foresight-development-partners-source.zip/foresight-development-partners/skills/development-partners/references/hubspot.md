# HubSpot mapping and contact registration

Portal **342239911** setup was completed through the HubSpot browser UI on **2026-10-17**: Employment Role includes Development Partner (`development_partner`), numeric Fit Score (`development_partner_fit_score`) exists with no minimum/maximum, and saved conditional logic shows Fit Score when Employment Role equals Development Partner (optional entry). Property definitions were independently verified through the connector. CONTACT read/write is available; NOTE read/write still requires reauthorization. No physician, company or note records were changed. `hubspot-schema.json` stores the verified definitions; refresh permissions before live registration.

## Data model

- Physician → CONTACT. Source-backed First Name / Last Name, Email, Job Title, LinkedIn URL and Practice Specialty. Preserve the original full name locally. Names may be corrected explicitly in HubSpot Contacts. Do not split an ambiguous full name using its last token. A clinic inbox shared by several physicians is an identity conflict, not a safe contact deduplication key.
- Practice → COMPANY. Company name, bare domain, website, company city/state, LinkedIn, employee count and Specialty. Record IDs use separate contact/company/note columns and remain text. Employee count is not physician/provider count. This portal's `of_group_practice_members` label is not sufficient to treat it as an employee-count target. Formatted full addresses remain in Full address for review until verified street, country and postal components are supplied.
- Physician → practice relationship → explicit CONTACT–COMPANY association. CONTACT.company is only Company Name text; it does not establish the association. Match company IDs carefully for shared domains, and do not auto-merge different practices using the same domain. An explicit user instruction to proceed with selected candidates authorizes contact registration; match exact records and satisfy connector confirmation requirements before mutations.
- Summary-first full assessment → one dated NOTE associated with the physician, using `hs_note_body` and `hs_timestamp`. Start with total fit score and one or two sentences on strongest fit signals; clearly flag unresolved eligibility. Include the full category breakdown, evidence and sources below that summary in the same note. Keep the complete detail in the master workbook too. This uses the standard Note activity and preserves existing contact/company Description context. Keep the note ID and content fingerprint to avoid blindly inserting duplicate notes later. Spreadsheet/import tools cannot update an existing note through re-import; use a reviewed API update if needed.
- Overall fit → numeric CONTACT property, `development_partner_fit_score`, display label **Fit Score**, created and verified on 2026-10-17. It is not a HubSpot predictive lead score or a probability. It may exceed 100 or be negative. Category ratings and bonus components remain in Excel/the note rather than creating a property for every category.

Actual specialty targets differ: CONTACT.type is Practice Specialty; COMPANY.specialty is Specialty. COMPANY.type is a company classification and must not receive a clinical specialty. The contact enum currently spells Pulmonology as `Pulomonology`; preserve its actual internal value. Unmatched/multiple specialties are flagged rather than invented as enum options. Contact city/state are residential fields, so practice location maps only to the company.

## Requested Employment Role and conditional Fit Score setup

Active CONTACT segment **Development Partners**, segment ID **339**, was created on 2026-10-17. Membership is `hs_role = development_partner`, so future registered partners join automatically. Its common column view is Name, Fit Score, Company Name, Email, Employment Role. Open the ranked view at https://app-na3.hubspot.com/contacts/342239911/objectLists/339/filters?sortKey=development_partner_fit_score&sortOrder=DESC (highest score first). Reuse this segment; do not create another segment per research run.

The following setup is live and verified as of 2026-10-17:

1. CONTACT **Employment Role** (`hs_role`) includes **Development Partner**, internal value `development_partner`. All five previous options were preserved.
2. Numeric CONTACT **Fit Score** exists with no minimum/maximum or default value.
3. Saved conditional property logic shows Fit Score when Employment Role equals Development Partner. Fit Score is optional, not required. This controls conditional property entry/display, not a record sidebar customization or Excel color formatting.

Only the user-selected handoff assigns the Development Partner role. Preserve other nonempty CRM properties. The current workbook's fit scores are research assessments, not evidence that an agreement has been signed. Setup approval did not modify physician records or waive future connector confirmations. Pandey and Alfieri remain excluded from CRM writes under their saved instructions.

## Future registration procedure

Read the HubSpot skill and establish permissions with `get_user_details` before live writes. At setup, CONTACT writes and NOTE access required reauthorization, while COMPANY read/write and CONTACT read were available. The connector also flagged onboarding incomplete; address that only if needed and requested. These are setup observations, not permanent permission assumptions.

For each authorized score-policy candidate after Clay, first match existing contacts (exact email or verified record ID) and companies (verified domain/practice and record ID), review existing values and prepare a concrete change set. Obtain the connector-required approval for property schemas and record/association changes. Do not guess record IDs, owners or lifecycle stages. Contact/company owners identify internal CRM assignees, not clinic owners. Preserve existing values unless an update is approved, and keep outputs back in the master by stable candidate/company keys.

These master tabs have planning rows and multiple sheets. They are not a file to upload wholesale. For a file import, generate dedicated files with a single header row and only the selected object/association columns. Use contact Email/Record ID and company Domain/Record ID as appropriate; the names alone are not safe matching identifiers. For API registration, use the verified internal property names shown in HubSpot Mapping. Do not map LOCAL tracking columns or proposed fields/options before they exist.

References: [HubSpot import format](https://knowledge.hubspot.com/import-and-export/set-up-your-import-file), [Notes API](https://developers.hubspot.com/docs/api-reference/crm-notes-v3/guide), [conditional property logic](https://knowledge.hubspot.com/properties/set-up-conditional-logic-for-enumeration-properties).

## User-selected handoff authorization

After the ranked shortlist, wait for the user to explicitly choose physicians to proceed with. That choice authorizes Clay enrichment then physician CONTACT creation/update, subject to existing eligibility gates. Scores above 75 alone do not authorize dispatch. See `handoff.md`. Do not use names alone as a deduplication key. Create only the physician contact; match an existing practice COMPANY and confirm its association under connector rules. Do not create new companies or overwrite nonempty existing CRM values automatically. Save the total score in the proposed Fit Score field once configured, with a summary-first full assessment in one NOTE; retain category detail in the master workbook. Populate the requested Employment Role and Fit Score for authorized qualifying contacts once their live definitions are verified.
