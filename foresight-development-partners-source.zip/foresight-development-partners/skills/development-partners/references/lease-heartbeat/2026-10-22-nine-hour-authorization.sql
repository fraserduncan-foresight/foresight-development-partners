create or replace function development_partners.enable_heartbeat(p_owner uuid,p_generation bigint,p_hash text,p_until timestamptz)
returns boolean language plpgsql security invoker set search_path='' as $$
begin
 if p_until <= clock_timestamp() or p_hash !~ '^[a-f0-9]{64}$'
    or (p_until > clock_timestamp()+interval '130 minutes'
        and not (clock_timestamp() >= timestamptz '2026-10-22 07:00:00+00'
                 and clock_timestamp() < timestamptz '2026-10-23 14:00:00+00'
                 and p_until <= timestamptz '2026-10-23 14:00:00+00'
                 and p_until <= clock_timestamp()+interval '540 minutes'))
 then raise exception 'Invalid heartbeat bounds'; end if;
 perform 1 from development_partners.run_lock where id='foresight' and owner=p_owner and generation=p_generation and expires_at>clock_timestamp() for update;
 if not found then raise exception 'Lease not active'; end if;
 insert into development_partners.lease_heartbeat values(p_owner,p_generation,p_hash,p_until)
 on conflict(owner) do update set generation=excluded.generation,token_hash=excluded.token_hash,until_at=excluded.until_at;
 return true;
end $$;
revoke all on function development_partners.enable_heartbeat(uuid,bigint,text,timestamptz) from public,anon,authenticated,service_role;