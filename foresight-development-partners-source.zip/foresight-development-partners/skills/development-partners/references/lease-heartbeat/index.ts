Deno.serve(async (req: Request) => {
  if (req.method !== 'POST') return new Response('', {status:405});
  const token = (req.headers.get('Authorization') || '').replace(/^Bearer /, '');
  if (!/^[a-f0-9]{64}$/.test(token)) return Response.json({ok:false}, {status:401});
  try {
    const b = await req.json();
    if (!/^[a-f0-9-]{36}$/.test(b.owner || '') || !Number.isSafeInteger(b.generation)) return Response.json({ok:false}, {status:400});
    const response = await fetch(Deno.env.get('SUPABASE_URL') + '/rest/v1/rpc/foresight_renew_lease', {
      method:'POST', headers:{'Content-Type':'application/json','apikey':Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, 'Authorization':'Bearer '+Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!},
      body:JSON.stringify({p_owner:b.owner,p_generation:b.generation,p_token:token}),signal:AbortSignal.timeout(15000)
    });
    if (!response.ok) return Response.json({ok:false}, {status:503});
    const data = await response.json();
    return Response.json(data, {status:data.ok ? 200 : 409,headers:{'Cache-Control':'no-store'}});
  } catch { return Response.json({ok:false}, {status:503}); }
});
