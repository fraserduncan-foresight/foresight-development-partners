create table development_partners.lease_heartbeat (
 owner uuid primary key, generation bigint not null, token_hash text not null,
 until_at timestamptz not null
);
alter table development_partners.lease_heartbeat enable row level security;
revoke all on development_partners.lease_heartbeat from public,anon,authenticated,service_role;
create function development_partners.enable_heartbeat(p_owner uuid,p_generation bigint,p_hash text,p_until timestamptz)
returns boolean language plpgsql security invoker set search_path='' as $$
begin
 if p_until <= clock_timestamp() or p_until > clock_timestamp()+interval '130 minutes' or p_hash !~ '^[a-f0-9]{64}$' then raise exception 'Invalid heartbeat bounds'; end if;
 perform 1 from development_partners.run_lock where id='foresight' and owner=p_owner and generation=p_generation and expires_at>clock_timestamp() for update;
 if not found then raise exception 'Lease not active'; end if;
 insert into development_partners.lease_heartbeat values(p_owner,p_generation,p_hash,p_until)
 on conflict(owner) do update set generation=excluded.generation,token_hash=excluded.token_hash,until_at=excluded.until_at;
 return true;
end $$;
revoke all on function development_partners.enable_heartbeat(uuid,bigint,text,timestamptz) from public,anon,authenticated,service_role;
create function public.foresight_renew_lease(p_owner uuid,p_generation bigint,p_token text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare expiry timestamptz; deadline timestamptz;
begin
 if length(p_token)<>64 then return jsonb_build_object('ok',false);end if;
 -- Same row lock as release: renewal cannot race a release or ownership change.
 perform 1 from development_partners.run_lock where id='foresight' and owner=p_owner and generation=p_generation and expires_at>clock_timestamp() for update;
 if not found then return jsonb_build_object('ok',false);end if;
 select until_at into deadline from development_partners.lease_heartbeat where owner=p_owner and generation=p_generation and token_hash=encode(sha256(convert_to(p_token,'UTF8')),'hex') and until_at>clock_timestamp();
 if deadline is null then return jsonb_build_object('ok',false);end if;
 update development_partners.run_lock set expires_at=least(clock_timestamp()+interval '10 minutes',deadline) where id='foresight' returning expires_at into expiry;
 return jsonb_build_object('ok',true,'owner',p_owner,'generation',p_generation,'expires_at',expiry);
end $$;
revoke all on function public.foresight_renew_lease(uuid,bigint,text) from public,anon,authenticated;
grant execute on function public.foresight_renew_lease(uuid,bigint,text) to service_role;
