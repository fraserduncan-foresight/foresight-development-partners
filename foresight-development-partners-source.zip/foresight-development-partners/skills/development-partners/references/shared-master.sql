-- Private, connector-only shared master. No Data API or anonymous grants.
create schema development_partners;
revoke all on schema development_partners from public, anon, authenticated;
create table development_partners.master (
  id text primary key check (id = 'foresight'),
  revision bigint not null default 0,
  document jsonb not null check (jsonb_typeof(document) = 'object'),
  updated_at timestamptz not null default now()
);
create table development_partners.run_lock (
  id text primary key references development_partners.master(id),
  owner uuid,
  holder text,
  generation bigint not null default 0,
  expires_at timestamptz
);
create table development_partners.events (
  id bigint generated always as identity primary key,
  occurred_at timestamptz not null default now(),
  owner uuid,
  action text not null,
  revision bigint
);
alter table development_partners.master enable row level security;
alter table development_partners.run_lock enable row level security;
alter table development_partners.events enable row level security;
revoke all on all tables in schema development_partners from public, anon, authenticated;
revoke all on all sequences in schema development_partners from public, anon, authenticated;

create function development_partners.checkout(p_owner uuid, p_holder text)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare l development_partners.run_lock; m development_partners.master;
begin
  if p_owner is null or p_holder is null or length(trim(p_holder)) = 0 then raise exception 'Owner and holder required'; end if;
  select * into m from development_partners.master where id = 'foresight' for update;
  if not found then raise exception 'Shared master not initialized'; end if;
  select * into l from development_partners.run_lock where id = 'foresight' for update;
  if l.owner = p_owner and l.expires_at > clock_timestamp() then
    return jsonb_build_object('ok', true, 'owner', l.owner, 'generation', l.generation,
      'expires_at', l.expires_at, 'revision', m.revision, 'document', m.document);
  end if;
  if l.owner is not null and l.expires_at > clock_timestamp() then
    return jsonb_build_object('ok', false, 'reason', 'busy', 'holder', l.holder, 'expires_at', l.expires_at);
  end if;
  update development_partners.run_lock set owner = p_owner, holder = p_holder,
    generation = generation + 1, expires_at = clock_timestamp() + interval '10 minutes'
    where id = 'foresight' returning * into l;
  insert into development_partners.events(owner, action, revision) values(p_owner, 'checkout', m.revision);
  return jsonb_build_object('ok', true, 'owner', l.owner, 'generation', l.generation,
    'expires_at', l.expires_at, 'revision', m.revision, 'document', m.document);
end $$;

create table development_partners.requests (
  id uuid primary key,
  owner uuid not null,
  input_hash text not null,
  result jsonb not null,
  created_at timestamptz not null default now()
);
alter table development_partners.requests enable row level security;
revoke all on development_partners.requests from public, anon, authenticated;

create function development_partners.save_checkpoint(p_request uuid, p_owner uuid,
  p_generation bigint, p_revision bigint, p_document jsonb, p_release boolean)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare cached development_partners.requests; outcome jsonb; signature text;
begin
  if p_request is null then raise exception 'Request id required'; end if;
  signature := md5(jsonb_build_array(p_owner, p_generation, p_revision, p_document, p_release)::text);
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_request::text, 0));
  select * into cached from development_partners.requests where id = p_request;
  if found then
    if cached.owner <> p_owner or cached.input_hash <> signature then raise exception 'Request id reused with different input'; end if;
    return cached.result;
  end if;
  outcome := development_partners.checkpoint(p_owner, p_generation, p_revision, p_document, p_release);
  insert into development_partners.requests(id, owner, input_hash, result)
    values(p_request, p_owner, signature, outcome);
  return outcome;
end $$;

create function development_partners.checkpoint(p_owner uuid, p_generation bigint,
  p_revision bigint, p_document jsonb, p_release boolean default false)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare l development_partners.run_lock; m development_partners.master;
begin
  select * into m from development_partners.master where id = 'foresight' for update;
  select * into l from development_partners.run_lock where id = 'foresight' for update;
  if l.owner is distinct from p_owner or l.generation <> p_generation or l.expires_at <= clock_timestamp()
    then raise exception 'Shared lease lost; do not submit work or overwrite master'; end if;
  if m.revision <> p_revision then raise exception 'Stale revision; reconcile before writing'; end if;
  if jsonb_typeof(p_document->'candidates') is distinct from 'object'
    or jsonb_typeof(p_document->'sources') is distinct from 'object'
    or jsonb_typeof(p_document->'people') is distinct from 'object'
    or jsonb_typeof(p_document->'runs') is distinct from 'array'
    then raise exception 'Invalid workflow document'; end if;
  update development_partners.master set document = p_document, revision = revision + 1,
    updated_at = clock_timestamp() where id = 'foresight' returning * into m;
  update development_partners.run_lock set owner = case when p_release then null else p_owner end,
    holder = case when p_release then null else holder end,
    expires_at = case when p_release then null else clock_timestamp() + interval '10 minutes' end
    where id = 'foresight' returning * into l;
  insert into development_partners.events(owner, action, revision)
    values(p_owner, case when p_release then 'release' else 'checkpoint' end, m.revision);
  return jsonb_build_object('ok', true, 'owner', p_owner, 'generation', l.generation,
    'expires_at', l.expires_at, 'revision', m.revision, 'released', p_release);
end $$;

create view development_partners.candidates with (security_invoker = true) as
select c.key as candidate_id, c.value->>'name' as name, c.value->>'practice' as practice,
  c.value->>'qualification' as qualification, c.value->>'research_status' as research_status,
  (c.value #>> '{calculated,total}')::numeric as fit_score,
  c.value #>> '{enrichment,choice}' as enrich,
  c.value #>> '{hubspot,contact_id}' as hubspot_contact_id,
  c.value #>> '{hubspot,registration_excluded}' as crm_excluded,
  c.value->>'notes' as notes, c.value as full_assessment
from development_partners.master m cross join lateral jsonb_each(m.document->'candidates') c;
revoke all on all functions in schema development_partners from public, anon, authenticated;
revoke all on all tables in schema development_partners from public, anon, authenticated;
