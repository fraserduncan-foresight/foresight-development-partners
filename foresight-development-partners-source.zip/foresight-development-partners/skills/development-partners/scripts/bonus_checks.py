"""Evidence-based bonus review and pinned semantic regression cases; no CRM access."""
import copy
import hashlib
import json
from pathlib import Path
import time
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
PINNED = {'alfieri_ai_and_teaching_time': 10, 'gaylis_telemedicine_without_ai': 0}


def obj(properties):
    return {'type': 'object', 'properties': properties, 'required': list(properties), 'additionalProperties': False}


TEXT = {'type': 'string'}
FACTS = {'type': 'array', 'items': obj({'fact': TEXT, 'url': TEXT})}
SIGNAL = obj({'status': {'type': 'string', 'enum': ['supported', 'not_found', 'uncertain']}, 'evidence': FACTS})
SCHEMA = obj({'candidate_id': TEXT, 'personal_ai': SIGNAL, 'practice_frustration': SIGNAL,
              'own_practice_ai_solution': SIGNAL, 'rationale': TEXT, 'partial': {'type': 'boolean'}})


def enabled(p):
    return p.cfg.get('bonus_checks', {}).get('enabled', False)


def cases():
    rows = json.loads((ROOT / 'references/bonus-reference-cases.json').read_text())['cases']
    if {r['id']: r['expected_bonus'] for r in rows} != PINNED or len(rows) != len(PINNED):
        raise ValueError('Pinned bonus expectations changed; restore Alfieri +10 and Gaylis 0 unless the user explicitly changes them')
    return rows


def fingerprint(p):
    material = {'rubric': p.rubric, 'prompts': {k: p.prompts[k] for k in ('shared', 'score', 'bonus_review')},
                'cases': cases(), 'implementation': Path(__file__).read_text()}
    return hashlib.sha256(json.dumps(material, sort_keys=True).encode()).hexdigest()


def tier(review):
    if review['partial'] or any(review[k]['status'] == 'uncertain' for k in ('personal_ai', 'practice_frustration', 'own_practice_ai_solution')):
        raise ValueError('Bonus evidence unresolved; no publishable score')
    if not review['rationale'].strip():
        raise ValueError('Bonus review needs an evidence explanation')
    for key in ('personal_ai', 'practice_frustration', 'own_practice_ai_solution'):
        signal = review[key]
        if signal['status'] == 'supported' and not signal['evidence']:
            raise ValueError('Supported bonus signal needs evidence')
        for fact in signal['evidence']:
            parsed = urlsplit(fact['url'])
            if not fact['fact'].strip() or parsed.scheme not in ('http', 'https') or not parsed.netloc:
                raise ValueError('Bonus evidence needs a fact and source URL')
    ai = review['personal_ai']['status'] == 'supported'
    solution = review['own_practice_ai_solution']['status'] == 'supported'
    if solution and not ai:
        raise ValueError('AI solution contradicts absent personal AI evidence')
    return 20 if ai and solution else 10 if ai and review['practice_frustration']['status'] == 'supported' else 0


def _run(p, payload, seconds, directory):
    if hasattr(p, 'budget') and not p.budget.allows(seconds):
        return {'response': None, 'reason': 'window_limit', 'elapsed': 0, 'usage': None, 'web_actions': 0, 'stage': 'bonus_review'}
    # No proposed bonus, expected outcome, prior ratings or calibration feedback is shown.
    prompt = p.prompts['shared'] + '\n' + p.prompts['bonus_review'] + '\nINPUT DATA:\n' + json.dumps(payload)
    if p.worker is None:
        p.worker = p.worker_factory()
    return p.worker.run('bonus_review', prompt, SCHEMA, seconds, directory)


def _policy(p):
    return {'bonuses': p.rubric['bonuses'], 'bonus_rule': p.rubric['bonus_rule']}


def ensure_ready(p, timestamp, force=False, run=None):
    digest = fingerprint(p)
    path = p.root / 'bonus-checks.json'
    cached = json.loads(path.read_text()) if path.exists() else {}
    if not force and cached.get('fingerprint') == digest and cached.get('passed') is True and {r['case_id']: r.get('observed_bonus') for r in cached.get('results', [])} == PINNED:
        return cached
    if hasattr(p, 'budget') and not p.budget.allows(2 * p.cfg.get('bonus_checks', {}).get('review_seconds', 45)):
        if run is not None:
            run['stop_reason'] = 'window_limit'
        raise ValueError('Research window ended before bonus reference checks; resume next window')
    attempt = str(time.time_ns())
    report = {'fingerprint': digest, 'checked_at': timestamp, 'passed': False, 'results': []}
    # At most one reference worker at a time; this happens before candidate scoring.
    for case in cases():
        payload = {'candidate_id': case['id'], 'name': case['name'], 'evidence': case['evidence'],
                   'policy': _policy(p), 'fixture_only': True}
        result = _run(p, payload, p.cfg.get('bonus_checks', {}).get('review_seconds', 45),
                      p.root / 'bonus-check-workers' / attempt / case['id'])
        row = {'case_id': case['id'], 'expected_bonus': case['expected_bonus'], 'raw_result': result}
        try:
            if result.get('reason') or not result.get('response'):
                raise ValueError(result.get('reason') or 'No bonus reference response')
            review = result['response']
            p.validate_schema(review, SCHEMA)
            if review['candidate_id'] != case['id']:
                raise ValueError('Reference returned wrong identity')
            row['observed_bonus'] = tier(review)
            row['passed'] = row['observed_bonus'] == case['expected_bonus']
        except (ValueError, KeyError, TypeError) as exc:
            row.update(passed=False, error=str(exc))
        report['results'].append(row)
        if run is not None:
            p.record_call(run, result | {'stage': 'bonus_reference'})
    report['passed'] = all(r['passed'] for r in report['results'])
    p.atomic_json(path, report)
    if not report['passed']:
        raise ValueError('Scoring blocked: current rubric/prompts failed pinned bonus cases; see ' + str(path))
    return report


def attach_review(p, payload, result, run, remaining_seconds):
    data = result.get('response')
    if result.get('reason') or not data or data.get('eligibility_concern'):
        return result
    p.validate_schema(data, p.score_schema)
    draft = copy.deepcopy(data)
    result['unreviewed_response'] = draft
    identity = {k: payload['candidate'][k] for k in ('id', 'name', 'practice', 'website') if k in payload['candidate']}
    evidence = []
    for section in list(data['ratings'].values()) + [data['bonus']]:
        for fact in section['evidence']:
            if fact not in evidence:
                evidence.append(fact)
    if remaining_seconds < 1:
        result['bonus_review_error'] = 'Scoring time exhausted before independent bonus review'
        return result
    review_result = _run(p, {'candidate_id': data['candidate_id'], 'identity': identity, 'evidence': evidence,
                             'policy': _policy(p), 'fixture_only': False},
                         min(remaining_seconds, p.cfg.get('bonus_checks', {}).get('review_seconds', 45)),
                         p.root / 'workers' / run['id'] / (data['candidate_id'] + '-bonus-review'))
    result['bonus_review_call'] = review_result
    try:
        if review_result.get('reason') or not review_result.get('response'):
            raise ValueError(review_result.get('reason') or 'No independent bonus response')
        review = review_result['response']
        p.validate_schema(review, SCHEMA)
        if review['candidate_id'] != data['candidate_id']:
            raise ValueError('Bonus review returned wrong identity')
        chosen = tier(review)
        facts = []
        for key in ('personal_ai', 'practice_frustration', 'own_practice_ai_solution'):
            for fact in review[key]['evidence']:
                if fact not in facts:
                    facts.append(fact)
        data['bonus'] = {'tier': chosen, 'rationale': review['rationale'], 'evidence': facts}
        result['bonus_check'] = {'fingerprint': fingerprint(p), 'review': review,
                                 'proposed_bonus': draft['bonus']['tier'], 'verified_bonus': chosen,
                                 'corrected': draft['bonus']['tier'] != chosen}
    except (ValueError, KeyError, TypeError) as exc:
        result['bonus_review_error'] = str(exc)
    return result


def require_verified(p, data, result):
    check = result.get('bonus_check', {})
    digest = fingerprint(p)
    cached_path = p.root / 'bonus-checks.json'
    cached = json.loads(cached_path.read_text()) if cached_path.exists() else {}
    if result.get('bonus_review_error') or check.get('fingerprint') != digest or cached.get('fingerprint') != digest or not cached.get('passed'):
        raise ValueError(result.get('bonus_review_error') or 'Bonus review/reference checks missing or outdated')
    review = check['review']
    p.validate_schema(review, SCHEMA)
    if review['candidate_id'] != data['candidate_id'] or tier(review) != data['bonus']['tier']:
        raise ValueError('Bonus does not match independent evidence review')
    return copy.deepcopy(check)
