"""Approval-gated bridge between the master workbook and the parent's Clay MCP tools.

This module never calls an external service. It prepares exact tool arguments,
persists task references, and imports the parent's checked Clay results.
"""
import offline_research
import copy
import json
import re
import urllib.parse
import uuid
import workflow_handoff as handoff

FIELDS = ('first_name', 'last_name', 'linkedin', 'job_title', 'work_email', 'email_status', 'company_linkedin',
          'practice_address', 'employee_count')
PERSON_FIELDS = ('first_name', 'last_name', 'linkedin', 'job_title', 'work_email', 'email_status')
COMPANY_FIELDS = ('company_linkedin', 'practice_address', 'employee_count')


def required_fields(p):
    return tuple(p.cfg.get('clay', {}).get('required_fields', FIELDS))


def eligible(c):
    return handoff.enrichment_eligible(c)


def domain(c):
    return (urllib.parse.urlsplit(c.get('website', '')).hostname or '').lower().removeprefix('www.')


def company_key(c):
    return (domain(c), re.sub(r'[^a-z0-9]', '', c.get('practice', '').lower()))


def saved_value(c, key):
    return (c.get(key) if key in ('first_name', 'last_name') else None) or c.get('enrichment', {}).get('fields', {}).get(key, {}).get('value')


def view(p):
    rows = []
    for c in sorted(p.state['candidates'].values(), key=lambda c: -(c.get('calculated') or {}).get('total', -1)):
        if not eligible(c) and not c.get('enrichment'):
            continue
        e = c.get('enrichment', {})
        fields = e.get('fields', {})
        rows.append({'candidate_id': c['id'], 'name': c['name'], 'practice': c.get('practice', ''),
                     'score': c.get('calculated', {}).get('total'), 'eligible': eligible(c),
                     'choice': e.get('choice', 'Pending'), 'status': e.get('status', 'Awaiting selection'),
                     'website': c.get('website', ''), 'fields': fields,
                     'missing': [k for k in required_fields(p) if saved_value(c, k) in ('', None)],
                     'contact_task_id': e.get('contact_task_id'), 'contact_entity_id': e.get('contact_entity_id'),
                     'review_note': e.get('review_note', '')})
    return rows


def select(p, ids, choice, timestamp):
    candidates = [p.state['candidates'][i] for i in ids]
    if choice == 'Yes' and any(not eligible(c) for c in candidates):
        raise ValueError('Enrichment requires a completed assessment and authorized screening/provisional eligibility')
    updates = {}
    for c in candidates:
        e = c.setdefault('enrichment', {})
        e['choice'] = choice
        e['selected_at'] = timestamp
        updates[c['id']] = {'enrichment': copy.deepcopy(e)}
    p.save()
    p.export(updates={'candidates': updates})


def approved(p, ids):
    if not ids or len(ids) != len(set(ids)):
        raise ValueError('Supply distinct candidate IDs')
    candidates = [p.state['candidates'][i] for i in ids]
    if any(not eligible(c) or c.get('enrichment', {}).get('choice') != 'Yes' for c in candidates):
        raise ValueError('Clay gate: every candidate must be fully scored and explicitly selected Yes')
    return candidates


def prepare(p, kind, ids, timestamp):
    offline_research.external_write_guard(p)
    cfg = p.cfg['clay']
    candidates = approved(p, ids)
    jobs = p.state.setdefault('clay_requests', {})
    for job in jobs.values():
        if job['status'] != 'archived' and job['kind'] == kind and set(job['candidate_ids']) & set(ids):
            raise ValueError('Existing Clay request ' + job['id'] + ': ' + job['status'] + '. Resume or review it; do not duplicate it.')
    if kind == 'lookup':
        if any(not domain(c) for c in candidates):
            raise ValueError('A verified practice website is needed before person lookup')
        if any(c.get('enrichment', {}).get('contact_entity_id') for c in candidates):
            raise ValueError('Existing matched contacts must reuse their saved Clay task')
        tool = 'mcp__codex_apps__clay_search_contacts_by_name'
        arguments = {'contactIdentifiers': [{'contactName': (' '.join((c['first_name'], c['last_name'])) if c.get('first_name') and c.get('last_name') else re.sub(r'^Dr\.?\s+', '', c['name'], flags=re.IGNORECASE)), 'companyIdentifier': domain(c)} for c in candidates]}
    elif kind == 'email':
        records = [c.get('enrichment', {}) for c in candidates]
        tasks = {e.get('contact_task_id') for e in records}
        if len(tasks) != 1 or not all(e.get('contact_task_id') and e.get('contact_entity_id') for e in records):
            raise ValueError('Email requests must share an existing matched contact task')
        if any(e.get('fields', {}).get('work_email', {}).get('value') for e in records):
            raise ValueError('Work email already present. Request only missing fields.')
        tool = 'mcp__codex_apps__clay_add_contact_data_points'
        arguments = {'taskId': next(iter(tasks)), 'entityIds': sorted({e['contact_entity_id'] for e in records}), 'dataPoints': [{'type': 'Email'}]}
    elif kind == 'company':
        if p.cfg['clay'].get('allow_company_enrichment') is False:
            raise ValueError('Company enrichment disabled: current objective is name and work email only')
        inputs = {}
        for c in candidates:
            if not domain(c):
                raise ValueError('A verified practice website is needed for company enrichment')
            key = company_key(c)
            # Reuse a completed result for colleagues at the same practice.
            prior = p.state.get('clay_companies', {}).get('|'.join(key))
            if prior:
                raise ValueError('Saved practice enrichment exists. Run clay-reuse before requesting more data.')
            if all(c.get('enrichment', {}).get('fields', {}).get(f, {}).get('value') not in ('', None) for f in COMPANY_FIELDS):
                raise ValueError('Practice fields already present')
            if any(company_key(other)[0] == key[0] and company_key(other)[1] != key[1] for other in candidates):
                raise ValueError('Different practice names share this domain. Resolve the organization before enriching together.')
            inputs[key[0]] = {'Company Identifier': key[0]}
        if len(inputs) > 1000:
            raise ValueError('Clay accepts 1000 input sets per call. Split the transport request and continue all selected candidates.')
        tool = 'mcp__codex_apps__clay_run_subroutine_direct'
        arguments = {'subroutine_id': cfg['company_function_id'], 'inputs': list(inputs.values())}
    else:
        raise ValueError('Unknown Clay request kind')
    job_id = 'ce_' + uuid.uuid4().hex[:12]
    job = {'id': job_id, 'kind': kind, 'candidate_ids': ids, 'workspace_id': cfg['workspace_id'],
           'tool': tool, 'arguments': arguments, 'status': 'reserved', 'created': timestamp,
           'identity': {c['id']: {'name': c['name'], 'practice': c.get('practice', ''), 'domain': domain(c)} for c in candidates}}
    jobs[job_id] = job
    for c in candidates:
        c.setdefault('enrichment', {})['status'] = 'Clay request reserved'
    p.save()
    p.export()
    return job


def attach(p, request_id, task_id, timestamp):
    job = p.state['clay_requests'][request_id]
    approved(p, job['candidate_ids'])
    if job['status'] not in ('reserved', 'submitted'):
        raise ValueError('A finished Clay request cannot be reopened by attaching a task')
    if job.get('task_id') and job['task_id'] != task_id:
        raise ValueError('Request already has a different task ID')
    if not task_id.startswith(('mcp-task-', 'mcp-task_', 'cgas-')):
        raise ValueError('Use the real task ID returned by Clay')
    job.update(task_id=task_id, status='submitted', submitted=timestamp)
    for ident in job['candidate_ids']:
        e = p.state['candidates'][ident]['enrichment']
        e['status'] = 'Clay in progress'
        if task_id not in e.setdefault('task_ids', []):
            e['task_ids'].append(task_id)
    p.save()
    p.export()


def ingest_results(p, request_id, data, timestamp):
    job = p.state['clay_requests'][request_id]
    if job.get('status') == 'completed':
        raise ValueError('This Clay response was already imported')
    if job.get('task_id') != data.get('task_id') or not job.get('task_id'):
        raise ValueError('Results must belong to the saved Clay task')
    if data.get('workspace_id') != p.cfg['clay']['workspace_id']:
        raise ValueError('Clay workspace mismatch')
    if data.get('task_complete') is not True or not data.get('raw_context'):
        raise ValueError('Poll Clay until this task completes and preserve its raw context before importing')
    approved(p, job['candidate_ids'])
    rows = data.get('results', [])
    if {r['candidate_id'] for r in rows} != set(job['candidate_ids']) or len(rows) != len(job['candidate_ids']):
        raise ValueError('Return one result for every candidate in this request')
    allowed = COMPANY_FIELDS if job['kind'] == 'company' else PERSON_FIELDS
    # Validate the whole response before changing any candidate.
    for row in rows:
        if row.get('match') not in ('confirmed', 'no_match', 'ambiguous', 'error'):
            raise ValueError('Unknown identity match status')
        fields = row.get('fields', {})
        if set(fields) - set(allowed):
            raise ValueError('Unexpected enrichment field')
        if row['match'] != 'confirmed' and fields:
            raise ValueError('Unresolved identities cannot populate fields')
        if row['match'] == 'confirmed' and (not row.get('entity_id') or not row.get('identity_evidence')):
            raise ValueError('A confirmed Clay entity and match explanation are required')
        for key, item in fields.items():
            value = item.get('value')
            if not item.get('source') or not item.get('status'):
                raise ValueError('Every field needs its returned source and provider status')
            if key in ('linkedin', 'company_linkedin') and value and not re.match(r'^https://(?:[a-z]+\.)?linkedin\.com/', str(value)):
                raise ValueError('Invalid LinkedIn URL')
            if key == 'work_email' and value and not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', str(value)):
                raise ValueError('Invalid work email')
            if key == 'employee_count' and value is not None and (isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0):
                raise ValueError('Employee count must be numeric or null')
    for row in rows:
        c = p.state['candidates'][row['candidate_id']]
        e = c.setdefault('enrichment', {})
        fields = e.setdefault('fields', {})
        if row['match'] == 'confirmed':
            for key, item in row.get('fields', {}).items():
                if item.get('value') not in ('', None) and fields.get(key, {}).get('value') in ('', None):
                    fields[key] = item | {'retrieved': timestamp, 'task_id': job['task_id']}
            if job['kind'] == 'lookup':
                e.update(contact_task_id=job['task_id'], contact_entity_id=row['entity_id'])
            if job['kind'] == 'company':
                p.state.setdefault('clay_companies', {})['|'.join(company_key(c))] = {
                    'fields': {k: copy.deepcopy(v) for k, v in fields.items() if k in COMPANY_FIELDS},
                    'task_id': job['task_id'], 'entity_id': row['entity_id']}
        e.setdefault('task_ids', [])
        if job['task_id'] not in e['task_ids']:
            e['task_ids'].append(job['task_id'])
        e['status'] = 'Complete' if all(saved_value(c, k) not in ('', None) for k in required_fields(p)) else ('Partial' if row['match'] == 'confirmed' else row['match'].replace('_', ' ').capitalize())
        e['updated'] = timestamp
        e.setdefault('notes', []).append({'kind': job['kind'], 'match': row['match'], 'note': row.get('note', ''), 'task_id': job['task_id']})
        if row.get('review_note'):
            e['review_note'] = row['review_note']
        c['updated'] = timestamp
    job.update(status='completed', finished=timestamp, results=copy.deepcopy(data))
    p.save()
    p.export()


def reuse(p, ids, timestamp):
    for c in approved(p, ids):
        cached = p.state.get('clay_companies', {}).get('|'.join(company_key(c)))
        if not cached:
            continue
        e = c.setdefault('enrichment', {})
        fields = e.setdefault('fields', {})
        for key, item in cached['fields'].items():
            if fields.get(key, {}).get('value') in ('', None):
                fields[key] = copy.deepcopy(item)
        e['updated'] = timestamp
        e['status'] = 'Complete' if all(saved_value(c, k) not in ('', None) for k in required_fields(p)) else 'Partial'
        e.setdefault('task_ids', [])
        if cached['task_id'] not in e['task_ids']:
            e['task_ids'].append(cached['task_id'])
    p.save()
    p.export()


def retry(p, request_id, timestamp):
    offline_research.external_write_guard(p)
    job = p.state['clay_requests'][request_id]
    if job['status'] != 'completed':
        raise ValueError('Only a completed, reviewed request can be archived for an explicit retry')
    job.update(status='archived', archived=timestamp)
    p.save()
