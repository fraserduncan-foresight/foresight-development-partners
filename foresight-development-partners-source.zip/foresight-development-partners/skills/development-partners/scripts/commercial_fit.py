"""Current practice suitability, separate from historical fit scores."""

POLICY = {'version': '2026-11-02.five-minimum', 'minimum_providers': 5, 'maximum_clinics': 10, 'maximum_providers': 60}
SCORING_POLICY_VERSION = '2026-10-23.no-ai-penalty'
CHECKS = ('practice_size',)
SCREEN_CHECKS = ('us_practice', 'private_ownership', 'decision_authority') + CHECKS


def size_status(size):
    counts = (size.get('clinic_count'), size.get('provider_count'))
    if size.get('status') == 'fail' or any(type(n) is int and n > cap for n, cap in zip(counts, (POLICY['maximum_clinics'], POLICY['maximum_providers']))):
        return 'fail'
    # Only a resolved, source-supported count can establish an undersized practice.
    # Partial/featured rosters keep size uncertain and never become an exact census.
    providers = size.get('provider_count')
    if size.get('status') == 'pass' and type(providers) is int and providers < POLICY['minimum_providers']:
        return 'fail'
    # Unknown counts remain unknown; lean toward inclusion rather than inventing counts.
    return 'pass'


def status(candidate):
    screen = candidate.get('screen', {})
    if size_status(screen.get('practice_size', {})) == 'fail':
        return 'fail'
    if screen.get('commercial_policy_version') != POLICY['version']:
        return 'uncertain'
    return 'pass'


def reason(candidate):
    value = status(candidate)
    return {'pass': 'No confirmed exclusion under minimum-five-provider policy',
            'fail': 'Outside practice size limits',
            'uncertain': 'Current screening policy not verified'}[value]
