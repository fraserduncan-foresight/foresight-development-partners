"""Create a machine-local runtime config without copying the team database or credentials."""
import argparse
import json
from pathlib import Path
import sys

PACKAGE = Path(__file__).resolve().parents[1]


def configure(directory, node, node_modules, python=sys.executable):
    directory = Path(directory).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    for path in (Path(node), Path(python), Path(node_modules) / '@oai/artifact-tool'):
        if not path.exists():
            raise ValueError(f'Required runtime not found: {path}')
    config = directory / 'config.json'
    if config.exists():
        raise ValueError('Config already exists; reuse it or review before changing the data directory')
    cfg = json.loads((PACKAGE / 'config.json').read_text())
    cfg.pop('setup_required', None)
    cfg.update(master_workbook='Development Partner Master.xlsx', state_directory='state',
               node=str(Path(node).resolve()), python=str(Path(python).resolve()),
               node_modules=str(Path(node_modules).resolve()))
    cfg['shared_master'] = {'enabled': True, 'project_id': 'svdtzmjpqvdvntlicpvt',
                            'schema': 'development_partners', 'workspace': 'foresight',
                            'mode': 'connector_checkout', 'workbook_role': 'local_read_only_export'}
    config.write_text(json.dumps(cfg, indent=2) + '\n')
    return str(config)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory', required=True)
    p.add_argument('--node', required=True)
    p.add_argument('--node-modules', required=True)
    p.add_argument('--python', default=sys.executable)
    args = p.parse_args()
    print(configure(args.directory, args.node, args.node_modules, args.python))
