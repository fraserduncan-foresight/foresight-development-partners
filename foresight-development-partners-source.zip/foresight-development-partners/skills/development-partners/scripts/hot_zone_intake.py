"""Save source suggestions before presentation; research requires user selection."""
from __future__ import annotations
import argparse
import copy
import json
import re
import urllib.parse
import uuid
import source_policy
import source_ecosystem


def url_key(value):
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Zone URLs must be public HTTP(S) URLs')
    host = parsed.hostname.lower().removeprefix('www.')
    port = parsed.port
    if port and port not in (80, 443):
        host += ':' + str(port)
    query = sorted((k, v) for k, v in urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
                   if not k.lower().startswith('utm_') and k.lower() not in ('fbclid', 'gclid'))
    return urllib.parse.urlunsplit(('https', host, parsed.path.rstrip('/'), urllib.parse.urlencode(query), ''))


def family(source):
    saved = source.get('hot_zone', {}).get('family_key')
    if saved:
        return saved
    # Backfill known legacy collections into the same no-repeat history.
    key = url_key(source['url'])
    return {'https://rppa.co/speakerpage': 'rppa:speakers',
            'https://heidihealth.com/en-us/blog/heidi-launches-us-cab': 'heidi:customer-advisory-board'}.get(key, '')


def find_source(state, url):
    key = url_key(url)
    return next((s for s in state['sources'].values() if s.get('kind') != 'hubspot_clinic'
                 and key in {url_key(u) for u in [s['url']] + s.get('hot_zone', {}).get('aliases', [])}), None)


def history(state):
    return [{'id': s['id'], 'name': s['name'], 'url': s['url'], 'family_key': family(s),
             'decision': s.get('zone_selection', {}).get('status', 'legacy source'),
             'research_status': s.get('status'), 'batch_id': s.get('zone_selection', {}).get('batch_id'),
             'number': s.get('zone_selection', {}).get('number'),
             'first_presented_at': s.get('hot_zone', {}).get('first_presented_at')}
            for s in state['sources'].values() if s.get('kind') != 'hubspot_clinic']


def propose(p, document, timestamp):
    rows = document['zones']
    if not rows:
        raise ValueError('Provide at least one verified new source collection')
    expected = document.get('requested_count', len(rows))
    if type(expected) is not int or expected < 1 or len(rows) != expected:
        raise ValueError('Save exactly the requested number of new zones')
    known_urls = {url_key(u) for s in p.state['sources'].values() if s.get('kind') != 'hubspot_clinic'
                  for u in [s['url']] + s.get('hot_zone', {}).get('aliases', [])}
    known_families = {family(s) for s in p.state['sources'].values() if s.get('kind') != 'hubspot_clinic'}
    known_names = {re.sub(r'\W+', '', s['name'].casefold()) for s in p.state['sources'].values() if s.get('kind') != 'hubspot_clinic'}
    # Stage publisher anchors with the collection; validate everything before committing.
    from types import SimpleNamespace
    staged = SimpleNamespace(state={'sources': p.state['sources'], 'source_ecosystem': copy.deepcopy(source_ecosystem.get(p.state))}, save=lambda: None)
    source_ecosystem.seed(staged, {'organizations': document.get('organizations', [])}, timestamp)
    prepared = []
    for row in rows:
        source_policy.validate(row)
        if not row.get('target_specialties'):
            raise ValueError('Verify and specify target_specialties for each new collection')
        if row.get('organization_id') not in source_ecosystem.get(staged.state)['organizations']:
            raise ValueError('Supply a known organization_id or include its verified publisher in organizations')
        organization = source_ecosystem.get(staged.state)['organizations'][row['organization_id']]
        if not source_policy.specialty_allowed(organization.get('specialty')):
            raise ValueError('Publisher specialty is outside Foresight target scope')
        for key in ('name', 'url', 'family_key', 'publisher', 'scope', 'rationale', 'risk', 'evidence'):
            if not row.get(key):
                raise ValueError('Missing zone field: ' + key)
        if not re.fullmatch(r'[a-z0-9-]+:[a-z0-9-]+', row['family_key']):
            raise ValueError('Use a stable publisher:collection family key without year or pagination')
        aliases = [row['url']] + row.get('aliases', [])
        urls = {url_key(u) for u in aliases}
        name = re.sub(r'\W+', '', row['name'].casefold())
        if urls & known_urls or row['family_key'] in known_families or name in known_names:
            raise ValueError('Already introduced source collection: ' + row['name'])
        for fact in row['evidence']:
            if not fact.get('fact', '').strip():
                raise ValueError('Source evidence needs a specific fact')
            url_key(fact['url'])
        known_urls.update(urls)
        known_families.add(row['family_key'])
        known_names.add(name)
        prepared.append(copy.deepcopy(row))
    # Validate the complete batch before mutating anything.
    from partner_pipeline import stable_id
    batch_id = 'hz_' + uuid.uuid4().hex[:12]
    ids = []
    p.state['source_ecosystem'] = staged.state['source_ecosystem']
    for number, row in enumerate(prepared, 1):
        ident = stable_id('z_', url_key(row['url']))
        row['first_presented_at'] = timestamp
        row['checked_at'] = timestamp
        row['source_policy_version'] = source_policy.VERSION
        p.state['sources'][ident] = {
            'id': ident, 'name': row['name'], 'url': row['url'], 'priority': number,
            'enabled': False, 'instructions': row['scope'], 'notes': row['rationale'] + ' Review: ' + row['risk'],
            'status': 'awaiting selection', 'cursor': '', 'exhausted': False, 'hot_zone': row,
            'zone_selection': {'status': 'pending', 'batch_id': batch_id, 'number': number,
                               'history': [{'status': 'pending', 'at': timestamp}]}}
        ids.append(ident)
        graph = p.state['source_ecosystem']
        graph['relationships'].append({'organization_id':row['organization_id'], 'source_id':ident,
            'relation':'hosts' if row['source_family']=='conference' else ('maintains' if row['source_family'] in ('private_practice_association_leadership','independent_practice_directory') else 'publishes'),
            'evidence':copy.deepcopy(row['evidence'])})
    p.state.setdefault('hot_zone_batches', {})[batch_id] = {
        'id': batch_id, 'created_at': timestamp, 'requested_count': document.get('requested_count', len(rows)),
        'source_ids': ids, 'selection_status': 'awaiting user selection'}
    p.save()
    return batch(p.state, batch_id)


def batch(state, batch_id):
    saved = state['hot_zone_batches'][batch_id]
    return copy.deepcopy(saved) | {'zones': [copy.deepcopy(state['sources'][i]) for i in saved['source_ids']]}


def select(p, batch_id, numbers, decision, timestamp):
    saved = p.state['hot_zone_batches'][batch_id]
    if not numbers or len(numbers) != len(set(numbers)):
        raise ValueError('Supply distinct zone numbers')
    if any(n < 1 or n > len(saved['source_ids']) for n in numbers):
        raise ValueError('Unknown number in this batch')
    if decision not in ('selected', 'rejected', 'deferred'):
        raise ValueError('Invalid selection decision')
    # Validate the entire selection before changing any source.
    if decision == 'selected':
        for number in numbers:
            source = p.state['sources'][saved['source_ids'][number - 1]]
            why = source_policy.problem(source)
            if why:
                raise ValueError(source['name'] + ': ' + why)
    for number in numbers:
        s = p.state['sources'][saved['source_ids'][number - 1]]
        s['zone_selection'].update(status=decision, decided_at=timestamp)
        s['zone_selection']['history'].append({'status': decision, 'at': timestamp})
        s['enabled'] = decision == 'selected'
        if not s.get('discovery_started_at') and s.get('status') in ('awaiting selection', 'deferred', 'rejected', 'queued'):
            s['status'] = 'queued' if decision == 'selected' else decision
    saved['selection_status'] = 'selection recorded'
    p.save()
    return batch(p.state, batch_id)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config')
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('history')
    inventory = sub.add_parser('plan')
    inventory.add_argument('--run-id')
    discovery = sub.add_parser('discovery-plan')
    discovery.add_argument('--limit', type=int, default=10)
    discovery.add_argument('--run-id')
    for command in ('seed-ecosystem', 'record-discovery', 'record-replenishment'):
        item = sub.add_parser(command)
        item.add_argument('--file', required=True)
    proposed = sub.add_parser('propose')
    proposed.add_argument('--file', required=True)
    selected = sub.add_parser('select')
    selected.add_argument('--batch', required=True)
    selected.add_argument('--number', type=int, action='append', required=True)
    selected.add_argument('--decision', choices=['selected', 'rejected', 'deferred'], default='selected')
    shown = sub.add_parser('batch')
    shown.add_argument('--batch', required=True)
    args = parser.parse_args()
    from pathlib import Path
    from partner_pipeline import Pipeline, now
    p = Pipeline(args.config)
    with p.locked():
        p.ingest()
        if args.command == 'history':
            output = history(p.state)
        elif args.command == 'plan':
            output = source_policy.plan(p.state, args.run_id)
        elif args.command == 'discovery-plan':
            output = source_ecosystem.discovery_plan(p.state, args.limit, args.run_id)
        elif args.command == 'seed-ecosystem':
            output = source_ecosystem.seed(p, json.loads(Path(args.file).read_text()), now())
        elif args.command == 'record-replenishment':
            output = source_ecosystem.record_replenishment(p, json.loads(Path(args.file).read_text()), now())
        elif args.command == 'record-discovery':
            output = source_ecosystem.record(p, json.loads(Path(args.file).read_text()), now())
        elif args.command == 'propose':
            output = propose(p, json.loads(Path(args.file).read_text()), now())
        elif args.command == 'select':
            output = select(p, args.batch, args.number, args.decision, now())
        else:
            output = batch(p.state, args.batch)
        print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
