"""Prepare contact/company/note data for future HubSpot registration. No CRM writes."""
import hashlib
import json
import re
import urllib.parse
import workflow_handoff as handoff
import commercial_fit
from pathlib import Path

SCHEMA_PATH = Path(__file__).resolve().parents[1] / 'references/hubspot-schema.json'


def domain(website):
    return (urllib.parse.urlsplit(website or '').hostname or '').lower().removeprefix('www.')


def company_key(c):
    identity = domain(c.get('website')) + '|' + re.sub(r'[^a-z0-9]', '', c.get('practice', '').lower())
    if identity == '|':
        identity += c['id']
    return 'co_' + hashlib.sha256(identity.encode()).hexdigest()[:12]


def field(c, key):
    return c.get('enrichment', {}).get('fields', {}).get(key, {}).get('value')


def name_part(c, key):
    # A sourced split or explicit user edit takes precedence. Never split a full name mechanically.
    return c.get(key) or field(c, key) or ''


def property_options(schema, object_type, property_name):
    group = schema['contacts'] + schema['contact_extra'] if object_type == 'CONTACT' else schema['companies'] + schema['company_extra']
    return next((p.get('options', []) for p in group if p['name'] == property_name), [])


def specialty_value(schema, c, object_type):
    source = c.get('specialty', '').strip()
    options = property_options(schema, object_type, 'type' if object_type == 'CONTACT' else 'specialty')
    for option in options:
        if source.casefold() in (option['label'].casefold(), option['value'].casefold()):
            return option['value']
    # The existing contact enum is misspelled in this portal. Preserve its real internal value.
    if source.casefold() == 'pulmonology' and object_type == 'CONTACT':
        return next((o['value'] for o in options if o['value'] == 'Pulomonology'), '')
    return ''


def assessment(c, state, weights):
    if not c.get('score') or not c.get('calculated'):
        return ''
    s, points = c['score'], c['calculated']
    lines = (["PROVISIONAL: ownership/decision-making authority is unverified."] if c.get('qualification') != 'pass' else []) + [f"Foresight development partner assessment — {c['name']}",
             f"Candidate ID: {c['id']}", f"Assessed: {c.get('scored_at') or c.get('updated', '')}",
             f"Qualification: {c.get('qualification')}; research: {c.get('research_status')}",
             f"Fit score: {points['total']} = regular {points['regular']} / 100 + bonus {points['bonus']} + AI adjustment {points.get('ai_adjustment', 0)}."]
    for key, weight in weights.items():
        item = s['ratings'][key]
        lines.append(f"{key.title()}: {points['points'][key]} / {weight}; rating {item['rating']}/4. {item['rationale']}" + (' Unknown.' if item.get('unknown') else ''))
        lines.extend(f"  {f['fact']} — {f['url']}" for f in item.get('evidence', []))
    for key, label in [('bonus', 'Alignment bonus'), ('ai_coverage', 'Existing AI coverage')]:
        item = s.get(key, {})
        if item.get('rationale'):
            lines.append(label + ': ' + item['rationale'])
            lines.extend(f"  {f['fact']} — {f['url']}" for f in item.get('evidence', []))
    for key in commercial_fit.SCREEN_CHECKS:
        item = c.get('screen', {}).get(key, {})
        lines.append(f"{key}: {item.get('status', 'unknown')}. {item.get('explanation', '')}")
        lines.extend(f"  {f['fact']} — {f['url']}" for f in item.get('evidence', []))
    lines.append('Strongest signal: ' + s.get('strongest_signal', ''))
    lines.append('Unknowns: ' + s.get('unknowns', ''))
    urls = [state['sources'][i]['url'] for i in c.get('sources', []) if i in state['sources']]
    if urls:
        lines.append('Discovery sources: ' + ', '.join(urls))
    crm_urls = [state['sources'][i]['hubspot']['url'] for i in c.get('sources', [])
                if i in state['sources'] and state['sources'][i].get('hubspot', {}).get('url')]
    if crm_urls:
        lines.append('Originating HubSpot clinics: ' + ', '.join(crm_urls))
    if c.get('notes'):
        lines.append('Research notes: ' + c['notes'])
    if c.get('enrichment', {}).get('review_note'):
        lines.append('Review needed: ' + c['enrichment']['review_note'])
    return '\n'.join(lines)


def crm_note(c, state, weights):
    if not c.get('score') or not c.get('calculated'):
        return ''
    lines=[f"SUMMARY — Fit score: {c['calculated']['total']}."]
    if c.get('qualification') != 'pass':
        lines.append('PROVISIONAL: current ownership and partnership approval authority remain unverified.')
    lines.append(c['score'].get('strongest_signal', '').strip())
    lines.append('\nFULL ASSESSMENT\n'+assessment(c, state, weights))
    return '\n'.join(line for line in lines if line)


def build(state, weights):
    schema = json.loads(SCHEMA_PATH.read_text())
    candidates = sorted(state['candidates'].values(), key=lambda c: (-(c.get('calculated') or {}).get('total', -1), c['name']))
    companies, contacts = {}, []
    for c in candidates:
        key = company_key(c)
        record = companies.setdefault(key, {'key': key, 'candidates': [], 'properties': {}, 'review': []})
        record['candidates'].append(c)
    domains = {}
    for record in companies.values():
        rows = record['candidates']
        saved = state.get('hubspot_companies', {}).get(record['key'], {})
        record['record_id'] = saved.get('record_id') or saved.get('source_record_id', '')
        if saved.get('record_id') and saved.get('source_record_id') and saved['record_id'] != saved['source_record_id']:
            record['review'].append('Manual company ID conflicts with the originating HubSpot clinic ID')
        p = record['properties']
        for target, get in [('name', lambda c: c.get('practice')), ('domain', lambda c: domain(c.get('website'))),
                            ('website', lambda c: c.get('website')), ('city', lambda c: c.get('city')),
                            ('state', lambda c: c.get('state')), ('linkedin_company_page', lambda c: field(c, 'company_linkedin')),
                            ('numberofemployees', lambda c: field(c, 'employee_count')),
                            ('specialty', lambda c: specialty_value(schema, c, 'COMPANY'))]:
            values = list(dict.fromkeys(get(c) for c in rows if get(c) not in ('', None)))
            if len(values) == 1:
                p[target] = values[0]
            elif len(values) > 1:
                record['review'].append(f"Conflicting {target}: verify the company value")
        if p.get('domain'):
            domains.setdefault(p['domain'], []).append(record)
        if any(c.get('specialty') and not specialty_value(schema, c, 'COMPANY') for c in rows):
            record['review'].append('Specialty needs an existing HubSpot option')
        addresses = list(dict.fromkeys(field(c, 'practice_address') for c in rows if field(c, 'practice_address')))
        record['unparsed_address'] = '\n'.join(addresses)
        # A formatted address is not a street-address component. Preserve it for review.
        for key in ('address', 'city', 'state', 'zip', 'country'):
            if saved.get(key):
                p[key] = saved[key]
        record['status'] = 'Existing ID supplied; verify match' if record['record_id'] else 'CRM match pending'
        if not p.get('domain'):
            record['review'].append('Missing company domain')
        record['source'] = '\n'.join(dict.fromkeys(v.get('source', '') for c in rows for k, v in c.get('enrichment', {}).get('fields', {}).items() if k in ('company_linkedin', 'practice_address', 'employee_count')))
    for shared in domains.values():
        if len(shared) > 1:
            for record in shared:
                record['review'].append('Shared domain across distinct practices: match exact company ID')
    for c in candidates:
        key, saved = company_key(c), c.get('hubspot', {})
        p = {'firstname': name_part(c, 'first_name'), 'lastname': name_part(c, 'last_name'),
             'email': field(c, 'work_email') or '', 'company': c.get('practice', ''),
             'jobtitle': field(c, 'job_title') or '', 'hs_linkedin_url': field(c, 'linkedin') or '',
             'type': specialty_value(schema, c, 'CONTACT')}
        missing = []
        if not handoff.enrichment_eligible(c):
            missing.append('Complete qualification/scoring first')
        if not p['firstname'] or not p['lastname']:
            missing.append('Verify first/last name')
        if c.get('specialty') and not p['type']:
            missing.append('Practice Specialty needs an existing option')
        missing.extend(companies[key]['review'])
        if c.get('enrichment', {}).get('review_note'):
            missing.append(c['enrichment']['review_note'])
        if saved.get('review_note'):
            missing.append(saved['review_note'])
        note = crm_note(c, state, weights)
        contacts.append({'candidate_id': c['id'], 'full_name': c['name'], 'properties': p,
                         'company_key': key, 'company_domain': domain(c.get('website')),
                         'contact_id': saved.get('contact_id', ''), 'company_id': companies[key]['record_id'],
                         'note_id': saved.get('note_id', ''), 'fit_score': c.get('calculated', {}).get('total'),
                         'note_body': note, 'note_timestamp': c.get('scored_at') or c.get('updated', ''),
                         'note_fingerprint': hashlib.sha256(note.encode()).hexdigest() if note else '',
                         'status': 'Needs review' if missing else 'Prepared; CRM match pending',
                         'review': '; '.join(missing), 'qualification_flag': c.get('handoff', {}).get('qualification_flag', ''), 'email_status': field(c, 'email_status') or ''})
    # Shared clinic inboxes must not collapse distinct physicians into one CRM contact.
    by_email = {}
    for row in contacts:
        email = row['properties']['email'].lower()
        if email:
            by_email.setdefault(email, []).append(row)
    for rows in by_email.values():
        if len({r['candidate_id'] for r in rows}) > 1:
            for r in rows:
                r['review'] += ('; ' if r['review'] else '') + 'Email shared by multiple candidate records: verify identity'
                r['status'] = 'Needs review'
    company_rows = [{k: v for k, v in r.items() if k != 'candidates'} for r in companies.values()]
    return {'account_id': schema['account_id'], 'schema_checked': schema['checked_at'],
            'contacts': contacts, 'companies': company_rows, 'score_property': schema['proposed_score'], 'future_role': schema['future_role'],
            'mapping': mappings(schema)}


def mappings(schema):
    rows = []
    for sheet, obj, fields in [
        ('HubSpot Contacts', 'CONTACT', [('Record ID - Contacts', 'hs_object_id'), ('First Name', 'firstname'), ('Last Name', 'lastname'), ('Email', 'email'), ('Company Name', 'company'), ('Job Title', 'jobtitle'), ('LinkedIn URL', 'hs_linkedin_url'), ('Practice Specialty', 'type')]),
        ('HubSpot Companies', 'COMPANY', [('Record ID - Companies', 'hs_object_id'), ('Company name', 'name'), ('Company Domain Name', 'domain'), ('Website URL', 'website'), ('City', 'city'), ('State/Region', 'state'), ('Country/Region', 'country'), ('Street Address', 'address'), ('Postal Code', 'zip'), ('LinkedIn Company Page', 'linkedin_company_page'), ('Number of Employees', 'numberofemployees'), ('Specialty', 'specialty')])]:
        properties = schema['contacts'] + schema['contact_extra'] if obj == 'CONTACT' else schema['companies'] + schema['company_extra']
        for column, name in fields:
            prop = next(p for p in properties if p['name'] == name)
            rule = 'Existing record matching key only; not a writable property. Never invent an ID' if name == 'hs_object_id' else 'Use verified source data; preserve existing CRM values unless an update is approved'
            if obj == 'CONTACT' and name == 'company':
                rule = 'Company name text only. Create/confirm the company association separately using company ID'
            if prop['type'] == 'enumeration':
                rule = 'Allowed values: ' + ', '.join(o['value'] for o in prop.get('options', []))
            rows.append([sheet, column, obj, name, prop['type'], 'Verified in portal', rule])
    rows.extend([
        ['HubSpot Contacts', 'Fit Score', 'CONTACT', 'development_partner_fit_score', 'number', 'Verified in portal' if schema['proposed_score'].get('exists') else 'Proposed; not created', 'Regular + bonus + AI adjustment. May exceed 100 or be negative. Reuse the existing property after verifying its definition'],
        ['HubSpot setup', 'Employment Role', 'CONTACT', 'hs_role', 'enumeration', 'Development Partner option verified' if schema['future_role'].get('exists') else 'New option planned', 'Use verified internal value development_partner; preserve all other role options and unrelated contact information'],
        ['HubSpot setup', 'Conditional Fit Score display', 'CONTACT UI', 'hs_role → development_partner_fit_score', 'display logic', 'Saved rule verified' if schema['future_role'].get('conditional_display_verified') else 'Requested; not configured', 'When Employment Role = Development Partner, show optional Fit Score during conditional property editing'],
        ['HubSpot Contacts', 'Assessment note', 'NOTE', 'hs_note_body', 'string', 'Standard activity; permissions pending', 'One dated note per assessment, associated with the physician. Sources and category detail included'],
        ['HubSpot Contacts', 'Assessment date (UTC)', 'NOTE', 'hs_timestamp', 'datetime', 'Standard activity; permissions pending', 'Assessment timestamp, not enrichment time'],
        ['HubSpot Contacts', 'Record ID - Companies', 'ASSOCIATION', 'Contact to Company', 'relationship', 'Association required', 'Match/create the practice company, then explicitly associate its ID with the physician contact'],
        ['All tabs', 'Candidate ID, Company key, status, missing fields, validation, sources, note fingerprint', 'LOCAL', '', 'tracking', 'Keep in master', 'Not CRM properties. Do not map these or raw rating columns into HubSpot'],
    ])
    return rows
