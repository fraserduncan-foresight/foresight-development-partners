"""Resumable read-only HubSpot geography intake through the parent's MCP connection."""
import copy
import datetime as dt
import hashlib
import json
import urllib.parse

ACCOUNT_ID = 342239911
STATES = dict(line.split('|') for line in '''AL|Alabama
AK|Alaska
AZ|Arizona
AR|Arkansas
CA|California
CO|Colorado
CT|Connecticut
DE|Delaware
FL|Florida
GA|Georgia
HI|Hawaii
ID|Idaho
IL|Illinois
IN|Indiana
IA|Iowa
KS|Kansas
KY|Kentucky
LA|Louisiana
ME|Maine
MD|Maryland
MA|Massachusetts
MI|Michigan
MN|Minnesota
MS|Mississippi
MO|Missouri
MT|Montana
NE|Nebraska
NV|Nevada
NH|New Hampshire
NJ|New Jersey
NM|New Mexico
NY|New York
NC|North Carolina
ND|North Dakota
OH|Ohio
OK|Oklahoma
OR|Oregon
PA|Pennsylvania
RI|Rhode Island
SC|South Carolina
SD|South Dakota
TN|Tennessee
TX|Texas
UT|Utah
VT|Vermont
VA|Virginia
WA|Washington
WV|West Virginia
WI|Wisconsin
WY|Wyoming
DC|District of Columbia'''.splitlines())


def state_code(value):
    value = str(value or '').strip()
    for code, name in STATES.items():
        if value.casefold() in (code.casefold(), name.casefold()):
            return code
    raise ValueError('Use a US state name or abbreviation; resolve ambiguous cities before querying')


def region_id(city, code):
    return 'area_' + hashlib.sha256((city.strip().casefold() + '|' + code).encode()).hexdigest()[:12]


def add_region(p, city, region_state, priority, notes, timestamp):
    code, city = state_code(region_state), str(city or '').strip()
    ident = region_id(city, code)
    old = p.state.setdefault('regions', {}).get(ident, {})
    area = old | {'id': ident, 'city': city, 'state': code, 'state_name': STATES[code],
                  'name': f'{city}, {code}' if city else STATES[code], 'priority': priority,
                  'enabled': True, 'notes': notes or old.get('notes', ''), 'account_id': ACCOUNT_ID}
    if not old or old.get('status') == 'complete':
        # A new invocation after completion refreshes CRM coverage without repeating finished research.
        area.update(status='queued', last_id='', fetched_ids=[], query_complete=False,
                    pages=[], queried_at=timestamp, reported_total=None)
    p.state['regions'][ident] = area
    p.save()
    p.export(updates={'regions': {ident: copy.deepcopy(area)}})
    return area


def query_arguments(area):
    if area.get('query_complete'):
        return None
    groups = []
    for state_value in (area['state'], area['state_name']):
        filters = [{'propertyName': 'state', 'operator': 'EQ', 'value': state_value, 'values': [], 'highValue': None}]
        if area['city']:
            filters.append({'propertyName': 'city', 'operator': 'EQ', 'value': area['city'], 'values': [], 'highValue': None})
        if area.get('last_id'):
            filters.append({'propertyName': 'hs_object_id', 'operator': 'GT', 'value': area['last_id'], 'values': [], 'highValue': None})
        groups.append({'associatedWith': [], 'filters': filters})
    return {'objectType': 'COMPANY', 'filterGroups': groups,
            'properties': ['hs_object_id', 'name', 'domain', 'website', 'city', 'state', 'country', 'specialty', 'organization_type__cloned_'],
            'sorts': [{'propertyName': 'hs_object_id', 'direction': 'ASCENDING'}],
            'limit': 100, 'offset': 0, 'query': None}


def unwrap(response):
    if response.get('isError'):
        raise ValueError('HubSpot returned an error; do not advance this area')
    if 'structuredContent' in response:
        return response['structuredContent']
    if 'content' in response:
        return json.loads(next(x['text'] for x in response['content'] if x['type'] == 'text'))
    return response


def public_url(props):
    for value in (props.get('website'), props.get('domain')):
        value = str(value or '').strip()
        if not value:
            continue
        if '://' not in value:
            value = 'https://' + value
        parsed = urllib.parse.urlsplit(value)
        if parsed.scheme in ('http', 'https') and parsed.hostname and not parsed.username:
            return value
    return ''


def ingest_page(p, ident, data, timestamp):
    area = p.state['regions'][ident]
    expected = query_arguments(area)
    if expected is None:
        raise ValueError('Region lookup is already complete')
    if data.get('account_id') != ACCOUNT_ID or data.get('arguments') != expected:
        raise ValueError('HubSpot page must match the saved portal and exact next geographic query')
    result = unwrap(data['response'])
    rows, total = result.get('results'), result.get('total')
    if not isinstance(rows, list) or not isinstance(total, int) or total < len(rows):
        raise ValueError('HubSpot results and total are required')
    ids = []
    for row in rows:
        props = row.get('properties', {})
        company_id = str(props.get('hs_object_id') or row.get('id') or '')
        if not company_id.isdigit() or int(company_id) <= int(area.get('last_id') or 0):
            raise ValueError('Invalid/repeated HubSpot company ID')
        if state_code(props.get('state')) != area['state'] or (area['city'] and str(props.get('city') or '').strip().casefold() != area['city'].casefold()):
            raise ValueError('Out-of-area result: verify the actual company geography before importing')
        ids.append(company_id)
    if len(ids) != len(set(ids)) or ids != sorted(ids, key=int):
        raise ValueError('Company IDs must be distinct and sorted ascending for safe resumption')
    if not ids and total:
        raise ValueError('HubSpot reported remaining records but returned an empty page')
    # Validate first, then persist all clinic sources with their CRM provenance.
    for row, company_id in zip(rows, ids):
        props = row['properties']
        source_id = 'hsclinic_' + company_id
        url = public_url(props)
        record_url = f'https://app.hubspot.com/contacts/{ACCOUNT_ID}/record/0-2/{company_id}?utm_source=codex&utm_medium=ai_agent&utm_campaign=development_partners'
        old = p.state['sources'].get(source_id, {})
        context = {'company_id': company_id, 'account_id': ACCOUNT_ID, 'name': props.get('name', ''),
                   'city': props.get('city', ''), 'state': props.get('state', ''), 'country': props.get('country', ''),
                   'specialty': props.get('specialty', ''), 'organization_type': props.get('organization_type__cloned_', ''),
                   'url': record_url, 'checked_at': timestamp}
        p.state['sources'][source_id] = old | {'id': source_id, 'kind': 'hubspot_clinic',
            'name': props.get('name') or f'HubSpot company {company_id}', 'url': url,
            'priority': area['priority'], 'enabled': old.get('enabled', True), 'notes': old.get('notes', ''),
            'status': old.get('status', 'queued'), 'cursor': old.get('cursor', ''), 'exhausted': old.get('exhausted', False),
            'region_ids': sorted(set(old.get('region_ids', []) + [ident])), 'hubspot': context,
            'instructions': 'Research only this HubSpot practice organization. Resolve its official site from name and location if the URL is missing or mismatched. Find named physician owners, founders, partners or physician decision makers from public practice/leadership pages. Do not extract every employed provider by default. Include plausible physician decision makers even when other scoring signals are not yet known. CRM ownership labels and associations are unverified hints. Confirm all eligibility later through the separate screen. Do not treat HubSpot owner/assignee as the clinic owner. Return promptly if the practice has no identifiable physician candidate; save a precise continuation only when useful public pages remain.'}
    area['fetched_ids'] = list(dict.fromkeys(area.get('fetched_ids', []) + ids))
    area['pages'].append({'fetched_at': timestamp, 'arguments': expected, 'reported_total': total, 'ids': ids})
    if area.get('reported_total') is None:
        area['reported_total'] = total
    if ids:
        area['last_id'] = ids[-1]
    area.update(query_complete=total <= len(rows), last_fetched=timestamp)
    area['status'] = 'ready' if area['query_complete'] else 'fetching'
    p.save()
    p.export()
    return summary(p, area)


def summary(p, area):
    sources = [p.state['sources'].get('hsclinic_' + i, {}) for i in area.get('fetched_ids', [])]
    return {k: v for k, v in area.items() if k not in ('pages', 'fetched_ids')} | {
        'fetched_clinics': len(sources), 'completed_clinics': sum(s.get('status') == 'complete' for s in sources),
        'clinics_needing_review': sum(s.get('status') in ('paused', 'discovery needs review') for s in sources),
        'next_tool': 'mcp__codex_apps__hubspot_search_crm_objects' if not area.get('query_complete') else None,
        'next_arguments': query_arguments(area)}
