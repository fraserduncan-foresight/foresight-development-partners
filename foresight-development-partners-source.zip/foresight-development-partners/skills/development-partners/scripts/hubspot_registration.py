"""Journaled parent-connector bridge. Prepares calls; never authenticates or calls HubSpot."""
import offline_research
import copy
import hashlib
import html
import json
import uuid
from pathlib import Path
import hubspot_mapping as mapping
import workflow_handoff as handoff


def unpack(response):
    if 'results' in response:
        return response
    if response.get('structuredContent'):
        return response['structuredContent']
    return json.loads(next(x['text'] for x in response.get('content', []) if x.get('type') == 'text'))


def setup_plan(p):
    schema=json.loads(mapping.SCHEMA_PATH.read_text())
    return {'account_id':schema['account_id'], 'setup_status':p.cfg['post_scoring'].get('setup_status'), 'score_property_exists':schema['proposed_score'].get('exists',False), 'development_partner_role_exists':schema['future_role'].get('exists',False), 'conditional_display_verified':schema['future_role'].get('conditional_display_verified',False), 'score_property':{
        'objectTypeFqn':'CONTACT','customPropertySchemas':[{'internalName':'development_partner_fit_score','label':'Fit score','type':'number','fieldType':'number','groupName':'contact_information','description':'Foresight development-partner fit assessment. May exceed 100; not a signing probability.','reasonForRecommendation':'User-requested score-driven development-partner workflow.','options':[]}]},
        'employment_role':{'property':'hs_role','action':'Reuse verified option' if schema['future_role'].get('exists') else 'Append option while preserving all existing options','label':'Development Partner','value':'development_partner','existing_options':schema['future_role']['current_options']},
        'conditional_display':{'when':'hs_role = development_partner','show':'development_partner_fit_score','surface':'HubSpot contact property editing/display; verify account capabilities in HubSpot UI'},
        'confirmation':'Show exact property/option changes and obtain connector-required approval before mutation. Existing enum option edits and conditional display need supported HubSpot UI/API; create-property tool alone cannot configure them.'}


def import_match(p, cid, data, timestamp):
    c=p.state['candidates'][cid]
    queries=data.get('queries', [])
    if not queries or data.get('identity_confirmed') is not True:
        raise ValueError('Require actual completed CRM query responses and confirmed person/practice identity')
    rows=[]
    for query in queries:
        if query.get('arguments',{}).get('objectType') != 'CONTACT':
            raise ValueError('Contact matching requires actual CONTACT search arguments')
        raw=unpack(query['response'])
        if raw.get('total',len(raw.get('results',[]))) > len(raw.get('results',[])):
            raise ValueError('CRM matching response is paginated; collect all relevant results first')
        rows.extend(raw.get('results',[]))
    selected=str(data.get('contact_id') or '')
    if selected:
        matches=[r for r in rows if str(r.get('id'))==selected]
        if not matches:raise ValueError('Selected contact ID must appear in actual CRM responses')
        existing=matches[0].get('properties',{})
    else:
        if rows or data.get('duplicate_check_complete') is not True:
            raise ValueError('New contact requires a complete duplicate check with no unresolved matching records')
        if len(queries)<2:
            raise ValueError('Use name/practice plus email or LinkedIn checks before creating a new contact')
        existing={}
    c.setdefault('hubspot',{}).update(contact_id=selected,match_checked_at=timestamp,identity_confirmed=True,duplicate_check_complete=True,existing_properties=copy.deepcopy(existing),match_queries=copy.deepcopy(queries))
    p.save();p.export(updates={'candidates':{cid:{'hubspot':copy.deepcopy(c['hubspot'])}}})


def prepare(p, cid, kind, timestamp, confirmation=None):
    offline_research.external_write_guard(p)
    c=p.state['candidates'][cid]; saved=c.setdefault('hubspot',{})
    if saved.get('registration_excluded'):raise ValueError('User excluded this candidate from CRM writes')
    if not handoff.enrichment_eligible(c) or c.get('enrichment',{}).get('choice')!='Yes':raise ValueError('Candidate is not authorized for the handoff')
    if c.get('enrichment',{}).get('review_note') or saved.get('review_note'):raise ValueError('Material identity/data conflict requires review')
    permissions=p.state.get('integration_status',{}).get('hubspot',{})
    if permissions.get('account_id')!=342239911:raise ValueError('Verify the intended HubSpot portal first')
    if kind=='contact':
        if permissions.get('contact_write')!='AVAILABLE':raise ValueError('HubSpot CONTACT writes unavailable; reauthorize the connector')
        if not permissions.get('score_property_exists') or not permissions.get('development_partner_role_exists'):raise ValueError('Complete and verify Fit Score / Development Partner property setup first')
        if not saved.get('identity_confirmed') or not saved.get('match_checked_at'):raise ValueError('Match identity and complete CRM duplicate checks first')
        row=next(r for r in mapping.build(p.state,p.cfg['weights'])['contacts'] if r['candidate_id']==cid)
        props={k:str(v) for k,v in row['properties'].items() if v not in ('',None)}
        if not props.get('firstname') or not props.get('lastname'):raise ValueError('Sourced physician first/last names required')
        # Missing optional email/title/LinkedIn/specialty are omitted, never fabricated.
        existing=saved.get('existing_properties',{})
        if saved.get('contact_id'):
            props={k:v for k,v in props.items() if not existing.get(k)}
        props['development_partner_fit_score']=str(c['calculated']['total'])
        props['hs_role']='development_partner'
        associations=[]
        company=p.state.get('hubspot_companies',{}).get(mapping.company_key(c),{}).get('record_id')
        if company and saved.get('company_association_confirmed'):
            associations=[{'targetObjectType':'COMPANY','targetObjectId':int(company),'labels':[]}]
        if saved.get('contact_id'):
            obj={'objectType':'CONTACT','objectId':int(saved['contact_id']),'properties':props,'associations':associations or None}
            request={'createRequest':None,'updateRequest':{'objects':[obj]}}
        else:
            obj={'objectType':'CONTACT','properties':props,'associations':associations or None}
            request={'createRequest':{'objects':[obj]},'updateRequest':None}
    elif kind=='note':
        if permissions.get('note_write')!='AVAILABLE':raise ValueError('HubSpot NOTE writes unavailable; reauthorize the connector')
        if not saved.get('contact_id'):raise ValueError('A matched or created contact ID is required before its note')
        body=mapping.crm_note(c,p.state,p.cfg['weights']); fingerprint=hashlib.sha256(body.encode()).hexdigest()
        if saved.get('registered_fingerprint')==fingerprint:return {'status':'unchanged','candidate_id':cid,'note_id':saved.get('note_id')}
        props={'hs_note_body':'<div>'+html.escape(body).replace('\n','<br>')+'</div>','hs_timestamp':c.get('scored_at') or c['updated']}
        if saved.get('note_id'):
            obj={'objectType':'NOTE','objectId':int(saved['note_id']),'properties':props,'associations':None};request={'createRequest':None,'updateRequest':{'objects':[obj]}}
        else:
            obj={'objectType':'NOTE','properties':props,'associations':[{'targetObjectType':'CONTACT','targetObjectId':int(saved['contact_id']),'labels':[]}]};request={'createRequest':{'objects':[obj]},'updateRequest':None}
    else:raise ValueError('Choose contact or note')
    requests=p.state.setdefault('hubspot_requests',{})
    if any(j['candidate_id']==cid and j['kind']==kind and j['status'] in ('prepared','outcome_unknown') for j in requests.values()):raise ValueError('Existing prepared/unknown-outcome request must be reconciled; do not submit a duplicate')
    key='hs_'+uuid.uuid4().hex[:12]
    job={'id':key,'candidate_id':cid,'kind':kind,'status':'prepared','created':timestamp,'tool':'mcp__codex_apps__hubspot_manage_crm_objects','arguments':{'confirmationStatus':confirmation,**request},'note_fingerprint':fingerprint if kind=='note' else None}
    requests[key]=job;p.save();p.export();return job


def import_result(p, request_id, data, timestamp):
    job=p.state['hubspot_requests'][request_id]
    if job['status']=='completed':raise ValueError('HubSpot result already imported')
    if not data.get('raw_response'):raise ValueError('Preserve the actual connector response')
    c=p.state['candidates'][job['candidate_id']];saved=c.setdefault('hubspot',{})
    saved.setdefault('registration_responses',[]).append({'at':timestamp,'request_id':request_id,'response':copy.deepcopy(data['raw_response'])})
    ident=str(data.get('object_id') or '')
    if data.get('succeeded') is not True or not ident.isdigit():
        job.update(status='outcome_unknown',response=copy.deepcopy(data));p.save();p.export();return
    if ident not in json.dumps(data['raw_response']):raise ValueError('Returned object ID must be present in actual connector response')
    if job['kind']=='contact':saved['contact_id']=ident;saved['contact_registered_at']=timestamp
    else:saved.update(note_id=ident,registered_fingerprint=job['note_fingerprint'],note_registered_at=timestamp)
    job.update(status='completed',finished=timestamp,response=copy.deepcopy(data));p.save();p.export(updates={'candidates':{c['id']:{'hubspot':copy.deepcopy(saved)}}})
