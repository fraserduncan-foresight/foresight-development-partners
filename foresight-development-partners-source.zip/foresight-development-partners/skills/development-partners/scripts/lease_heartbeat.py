"""Bounded lease-only renewal; no database administration credentials."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.request
import uuid


def stamp():
    return dt.datetime.now(dt.timezone.utc)


def process_identity(pid):
    try:
        return subprocess.check_output(['ps','-p',str(pid),'-o','lstart=,comm='],text=True).strip()
    except (subprocess.CalledProcessError,ProcessLookupError):
        return ''


def controller():
    pid=os.getpid()
    for _ in range(12):
        row=subprocess.check_output(['ps','-p',str(pid),'-o','ppid=,comm='],text=True).strip().split(None,1)
        if len(row)!=2:break
        if Path(row[1]).name.lower()=='codex':return pid,process_identity(pid)
        pid=int(row[0])
        if pid<=1:break
    raise RuntimeError('No live Codex controller found; heartbeat not started')


def active(session, owner, generation, deadline, pid, signature):
    return (session.get('owner')==owner and session.get('generation')==generation
            and stamp()<deadline and bool(signature) and process_identity(pid)==signature)


def renew(endpoint, token, owner, generation):
    request=urllib.request.Request(endpoint,data=json.dumps({'owner':owner,'generation':generation}).encode(),
        headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
    with urllib.request.urlopen(request,timeout=20) as response:data=json.load(response)
    if data.get('ok') is not True or data.get('owner')!=owner or data.get('generation')!=generation:
        raise RuntimeError('Lease renewal rejected')
    expiry=dt.datetime.fromisoformat(data['expires_at'].replace('Z','+00:00'))
    if expiry<=stamp():raise RuntimeError('Lease already expired')
    return data


def write_status(root,data):
    target=root/'heartbeat-status.json';temp=root/('heartbeat-status-'+uuid.uuid4().hex+'.tmp')
    temp.write_text(json.dumps(data));os.chmod(temp,0o600);temp.replace(target)


def serve(config,owner,generation,token_file,until,pid,signature):
    import shared_master
    cfg,root=shared_master.settings(config)
    deadline=dt.datetime.fromisoformat(until)
    endpoint=cfg['shared_master']['heartbeat']['endpoint']
    token=Path(token_file).read_text().strip()
    path=root/'shared-session.json'
    last=0
    try:
        while True:
            session=json.loads(path.read_text()) if path.exists() else {}
            if not active(session,owner,generation,deadline,pid,signature):break
            if time.monotonic()-last>=60:
                data=renew(endpoint,token,owner,generation)
                write_status(root,dict(data,state='healthy',checked_at=stamp().isoformat(),pid=os.getpid()))
                last=time.monotonic()
            time.sleep(1)
    except Exception as exc:
        # Never leak HTTP bodies or token. Dispatch checks this failure marker.
        previous=json.loads((root/'heartbeat-status.json').read_text()) if (root/'heartbeat-status.json').exists() else {}
        write_status(root,dict(state='failed',owner=owner,generation=generation,checked_at=stamp().isoformat(),reason='renewal_failed',error_type=type(exc).__name__,http_status=getattr(exc,'code',None),expires_at=previous.get('expires_at','')))
    finally:
        Path(token_file).unlink(missing_ok=True)


def start(config,session,request):
    import sys
    pid,signature=controller()
    args=[sys.executable,str(Path(__file__).resolve()),'--config',str(config),'--owner',session['owner'],'--generation',str(session['generation']),
          '--token-file',request['heartbeat_token_file'],'--until',request['heartbeat_until'],'--controller-pid',str(pid),'--controller-signature',signature]
    subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True,close_fds=True)
    _,root=__import__('shared_master').settings(config)
    until=time.monotonic()+25
    while time.monotonic()<until:
        p=root/'heartbeat-status.json'
        data=json.loads(p.read_text()) if p.exists() else {}
        if data.get('owner')==session['owner'] and data.get('generation')==session['generation']:
            if data.get('state')=='healthy':return
            if data.get('state')=='failed':break
        time.sleep(.2)
    raise RuntimeError('Checkout saved, but independent heartbeat not healthy; stop and reconcile/release')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--owner',required=True);p.add_argument('--generation',type=int,required=True)
    p.add_argument('--token-file',required=True);p.add_argument('--until',required=True);p.add_argument('--controller-pid',type=int,required=True);p.add_argument('--controller-signature',required=True)
    a=p.parse_args();serve(a.config,a.owner,a.generation,a.token_file,a.until,a.controller_pid,a.controller_signature)
