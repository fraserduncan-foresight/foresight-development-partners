"""Research-only outage branches. External writes always require canonical lease."""
import argparse,copy,datetime as dt,fcntl,hashlib,json,pathlib,subprocess,sys
import shared_master as sm

def research_access(cfg, root):
    offline=cfg.get('offline_research')
    if not offline:
        return sm.require_lease(cfg,root)
    manifest=json.loads((pathlib.Path(root).parent/'manifest.json').read_text())
    if manifest['run_id']!=offline['run_id'] or pathlib.Path(root).resolve()!=pathlib.Path(manifest['branch']).resolve()/'state':
        raise RuntimeError('Invalid offline branch identity')
    # Saving finished research remains possible after the dispatch deadline.
    return {'offline_research_only':True}

def dispatch(cfg):
    if not cfg.get('offline_research'):
        return
    o=cfg['offline_research']
    result=subprocess.run([sys.executable,o['controller'],'check','--run-id',o['run_id'],'--phase','research'],capture_output=True,text=True)
    if result.returncode or not json.loads(result.stdout).get('allowed'):
        raise RuntimeError('Offline research deadline/allowance guard denied')

def external_write_guard(p):
    if p.cfg.get('offline_research'):
        raise RuntimeError('Offline research only: HubSpot and Clay writes are paused until canonical reconciliation')
    sm.require_lease(p.cfg,p.root)
    if (p.root/"offline-merge-pending.json").exists():
        raise RuntimeError("Offline merge requires accepted canonical checkpoint before external writes")

def enter(config, branch, run_id, controller, snapshot=None):
    config=pathlib.Path(config).resolve();cfg,root=sm.settings(config)
    if cfg.get('offline_research'):raise ValueError('Already an offline branch')
    baseline=json.loads((root/'shared-base.json').read_text())
    current=json.loads(pathlib.Path(snapshot or root/'state.json').read_text())
    branch=pathlib.Path(branch).resolve()
    if branch.exists():raise ValueError('Branch already exists; resume its saved config')
    branch.mkdir(parents=True);(branch/'state').mkdir()
    for name,data in [('base.json',baseline['document']),('state/state.json',current)]:sm.write(branch/name,data)
    sm.write(branch/'manifest.json',{'run_id':run_id,'base_revision':baseline['revision'],'branch':str(branch),'created_at':dt.datetime.now(dt.timezone.utc).isoformat(),'canonical_config':str(config),'mode':'research_only'})
    cfg['state_directory']='state';cfg['master_workbook']='Offline Research.xlsx'
    cfg['offline_research']={'run_id':run_id,'controller':str(pathlib.Path(controller).resolve())}
    sm.write(branch/'config.json',cfg)
    return {'config':str(branch/'config.json'),'mode':'research_only','base_revision':baseline['revision']}

def merge_values(base, local, remote):
    """Merge independent records, never replace a concurrently changed record."""
    target=copy.deepcopy(remote);conflicts=[]
    for group in set(base)|set(local):
        b,l,r=base.get(group),local.get(group),remote.get(group)
        if sm.json_equal(b,l):continue
        if isinstance(b,dict) and isinstance(l,dict) and isinstance(r,dict):
            records=target.setdefault(group,{})
            for key in set(b)|set(l):
                bv,lv,rv=b.get(key),l.get(key),r.get(key)
                if sm.json_equal(bv,lv):continue
                if sm.json_equal(lv,rv):continue
                if key not in l:
                    conflicts.append([group,key,'offline deletion withheld']);continue
                if not sm.json_equal(bv,rv):
                    conflicts.append([group,key,'concurrent record change']);continue
                if group=='candidates' and key not in r:
                    npi=lv.get('npi');name=(lv.get('name') or '').casefold().strip()
                    matches=[cid for cid,c in records.items() if cid!=key and ((npi and c.get('npi')==npi) or (name and (c.get('name') or '').casefold().strip()==name))]
                    if matches:
                        conflicts.append([group,key,'identity reconciliation',matches]);continue
                records[key]=copy.deepcopy(lv)
        elif isinstance(b,list) and isinstance(l,list) and isinstance(r,list) and len(l)>=len(b) and sm.json_equal(l[:len(b)],b):
            for row in l[len(b):]:
                if not any(sm.json_equal(row,x) for x in target[group]):target[group].append(copy.deepcopy(row))
        elif sm.json_equal(b,r):target[group]=copy.deepcopy(l)
        else:conflicts.append([group,'concurrent collection change'])
    return target,conflicts

def reconcile(config, branch):
    cfg,root=sm.settings(config);sm.require_lease(cfg,root)
    branch=pathlib.Path(branch);manifest=json.loads((branch/'manifest.json').read_text())
    if manifest.get('canonical_config')!=str(pathlib.Path(config).resolve()):raise ValueError('Wrong canonical destination')
    with (root/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        base=json.loads((branch/'base.json').read_text());local=json.loads((branch/'state/state.json').read_text());remote=json.loads((root/'state.json').read_text())
        target,conflicts=merge_values(base,local,remote)
        sm.require_lease(cfg,root)
        sm.write(branch/'reconciliation.json',{'conflicts':conflicts,'canonical_before':remote,'local_changes_retained':True,'requires_checkpoint_before_external_writes':True})
        sm.write(root/'offline-merge-pending.json',{'sha256':hashlib.sha256(json.dumps(target,sort_keys=True).encode()).hexdigest(),'branch':str(branch)})
        sm.write(root/'state.json',target)
    return {'conflicts':conflicts,'merged_locally':True,'requires_checkpoint_before_external_writes':True}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['enter','merge']);p.add_argument('--config',required=True);p.add_argument('--branch',required=True);p.add_argument('--run-id');p.add_argument('--controller');p.add_argument('--snapshot');a=p.parse_args()
    print(json.dumps(enter(a.config,a.branch,a.run_id,a.controller,a.snapshot) if a.action=='enter' else reconcile(a.config,a.branch)))
