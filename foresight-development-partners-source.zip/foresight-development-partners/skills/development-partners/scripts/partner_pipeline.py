#!/usr/bin/env python3
"""Persistent, time-bounded Codex physician screening and scoring workflow."""
from __future__ import annotations
import practice_tags

import argparse
import concurrent.futures as futures
import contextlib
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import tomllib
import unicodedata
import urllib.parse
import uuid
import zipfile
import xml.etree.ElementTree as ET
import clay_enrichment as clay
import hubspot_mapping as hubspot
import hubspot_regions as regions
import workflow_handoff as handoff
import hubspot_registration as registration
import bonus_checks
import shared_master
import offline_research
import commercial_fit
import physician_identity
import hot_zone_intake
import practice_screening
import source_policy

PACKAGE = Path(__file__).resolve().parents[1]
CATEGORIES = ('healthcare', 'practice', 'development', 'technology', 'influence', 'research')
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
STOP = threading.Event()


class WindowBudget:
    """Absolute research cutoff shared by every source in one nightly window."""
    def __init__(self, deadline=None):
        self.end = None
        if deadline:
            value = dt.datetime.fromisoformat(deadline.replace('Z', '+00:00'))
            if value.tzinfo is None:
                raise ValueError('Deadline must include a timezone')
            self.end = time.monotonic() + max(0, (value - dt.datetime.now(dt.timezone.utc)).total_seconds())

    def remaining(self):
        return float('inf') if self.end is None else max(0, self.end - time.monotonic())

    def allows(self, seconds):
        return self.remaining() >= seconds + 2


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def norm(value):
    text = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().lower()
    text = re.sub(r'^\s*(dr\.?|doctor)\s+', '', text)
    text = re.sub(r',\s*(m\.?d\.?|d\.?o\.?|ph\.?d\.?)\s*$', '', text)
    return re.sub(r'[^a-z0-9]', '', text)


def http_url(value):
    try:
        parsed = urllib.parse.urlsplit(str(value))
        return parsed.scheme in ('http', 'https') and bool(parsed.hostname) and not parsed.username
    except ValueError:
        return False


def canonical_url(value):
    if not http_url(value):
        return ''
    parsed = urllib.parse.urlsplit(value)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query = [(k, v) for k, v in query if not k.lower().startswith('utm_') and k not in ('fbclid', 'gclid')]
    return urllib.parse.urlunsplit((parsed.scheme.lower(), parsed.netloc.lower(), parsed.path.rstrip('/'), urllib.parse.urlencode(query), ''))


def stable_id(prefix, *parts):
    return prefix + hashlib.sha256('|'.join(str(x or '') for x in parts).encode()).hexdigest()[:12]


def verified_episode_cursor_advanced(source, previous, following):
    """Empty filtered chunks may advance through a verified ordered public index."""
    hot = source.get('hot_zone', {})
    inventory = hot.get('public_ordered_entry_inventory') or hot.get('public_episode_inventory', {})
    items = inventory.get('items', []) if isinstance(inventory, dict) else []
    clean = lambda value: re.sub(r'[^a-z0-9]', '', str(value).casefold())
    def position(cursor):
        # A cursor may explicitly distinguish completed work from a future resume hint.
        # Only the declared last-inspected section establishes observed progress.
        section = str(cursor)
        marker = re.search(r'\bLast inspected:\s*', section, flags=re.I)
        if marker:
            section = section[marker.end():]
            section = re.split(r'\s*\|\s*Resume with\b', section, maxsplit=1, flags=re.I)[0]
        matches = [i for i, item in enumerate(items)
                   if item.get('title') and len(clean(item['title'])) > 15
                   and clean(item['title']) in clean(section)]
        return matches[0] if len(matches) == 1 else None
    old, new = position(previous), position(following)
    return old is not None and new is not None and new > old


def atomic_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    os.replace(temp, path)


def fingerprint(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None


def read_workbook(path):
    """Read human fields through OOXML; authoring is handled by artifact-tool."""
    if not path.exists():
        return {}
    with zipfile.ZipFile(path) as book:
        shared = []
        if 'xl/sharedStrings.xml' in book.namelist():
            shared = [''.join(x.itertext()) for x in ET.fromstring(book.read('xl/sharedStrings.xml'))]
        relationships = ET.fromstring(book.read('xl/_rels/workbook.xml.rels'))
        targets = {x.attrib['Id']: x.attrib['Target'] for x in relationships}
        workbook = ET.fromstring(book.read('xl/workbook.xml'))
        out = {}
        for sheet in workbook.find('s:sheets', NS):
            rel = sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
            target = targets[rel]
            target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
            root = ET.fromstring(book.read(target))
            rows = {}
            for row in root.findall('.//s:sheetData/s:row', NS):
                cells = {}
                for c in row:
                    addr = c.attrib.get('r', '')
                    col = 0
                    for letter in re.match(r'[A-Z]+', addr).group():
                        col = col * 26 + ord(letter) - 64
                    typ = c.attrib.get('t')
                    value_node = c.find('s:v', NS)
                    value = value_node.text if value_node is not None else ''
                    if typ == 's':
                        value = shared[int(value)] if value else ''
                    elif typ == 'inlineStr':
                        value = ''.join(c.find('s:is', NS).itertext())
                    cells[col] = value or ''
                rows[int(row.attrib['r'])] = cells
            headers = rows.get(5, {})
            out[sheet.attrib['name']] = [
                {title: cells.get(col, '') for col, title in headers.items() if title}
                for index, cells in sorted(rows.items()) if index >= 6 and any(cells.values())
            ]
        return out


def obj(props):
    return {'type': 'object', 'properties': props, 'required': list(props), 'additionalProperties': False}


STR = {'type': 'string'}
BOOL = {'type': 'boolean'}
FACT_SCHEMA = obj({'fact': STR, 'url': STR})
FACTS_SCHEMA = {'type': 'array', 'items': FACT_SCHEMA}
PERSON_SCHEMA = obj({key: STR for key in ('name', 'first_name', 'last_name', 'practice', 'website', 'city', 'state', 'specialty', 'signal', 'npi', 'npi_entity_type', 'npi_registry_url', 'npi_match_evidence')} | {'evidence': FACTS_SCHEMA})
CHECK_SCHEMA = obj({'status': {'type': 'string', 'enum': ['pass', 'fail', 'uncertain']}, 'explanation': STR, 'evidence': FACTS_SCHEMA})
SIZE_SCHEMA = obj(CHECK_SCHEMA['properties'] | {key: {'type': ['integer', 'null'], 'minimum': 1} for key in ('clinic_count', 'provider_count')})
RATING_SCHEMA = obj({'rating': {'type': 'integer', 'minimum': 0, 'maximum': 4}, 'unknown': BOOL, 'rationale': STR, 'evidence': FACTS_SCHEMA})
SCHEMAS = {
    'discovery': obj({'candidates': {'type': 'array', 'items': PERSON_SCHEMA}, 'next_cursor': STR, 'exhausted': BOOL, 'partial': BOOL}),
    'practice': obj({'practice_id': STR, 'us_practice': CHECK_SCHEMA, 'private_ownership': CHECK_SCHEMA, 'practice_size': SIZE_SCHEMA, 'partial': BOOL}),
    'screen': obj({'candidate_id': STR, 'us_practice': CHECK_SCHEMA, 'private_ownership': CHECK_SCHEMA, 'decision_authority': CHECK_SCHEMA, 'practice_size': SIZE_SCHEMA, 'partial': BOOL}),
    'score': obj({'candidate_id': STR, 'ratings': obj({key: RATING_SCHEMA for key in CATEGORIES}), 'bonus': obj({'tier': {'type': 'integer', 'enum': [0, 10, 20]}, 'rationale': STR, 'evidence': FACTS_SCHEMA}), 'ai_coverage': obj({'adjustment': {'type': 'integer', 'enum': [0]}, 'rationale': STR, 'evidence': FACTS_SCHEMA}), 'strongest_signal': STR, 'unknowns': STR, 'eligibility_concern': STR, 'partial': BOOL})
}


def validate_schema(value, schema, where='response'):
    typ = schema['type']
    if isinstance(typ, list):
        if value is None and 'null' in typ:
            return
        typ = next(t for t in typ if t != 'null')
    if typ == 'object':
        if not isinstance(value, dict) or set(value) != set(schema['properties']):
            raise ValueError(f'{where}: incorrect fields')
        for key, sub in schema['properties'].items():
            validate_schema(value[key], sub, where + '.' + key)
    elif typ == 'array':
        if not isinstance(value, list):
            raise ValueError(f'{where}: expected array')
        for i, item in enumerate(value):
            validate_schema(item, schema['items'], f'{where}[{i}]')
    elif typ == 'string':
        if not isinstance(value, str):
            raise ValueError(f'{where}: expected text')
    elif typ == 'boolean':
        if not isinstance(value, bool):
            raise ValueError(f'{where}: expected boolean')
    elif typ == 'integer':
        if type(value) is not int or not schema.get('minimum', value) <= value <= schema.get('maximum', value):
            raise ValueError(f'{where}: invalid integer')
    if 'enum' in schema and value not in schema['enum']:
        raise ValueError(f'{where}: invalid choice')


def validate_facts(facts, required=False):
    if required and not facts:
        raise ValueError('Positive assessment requires cited evidence')
    for item in facts:
        if not item['fact'].strip() or not http_url(item['url']):
            raise ValueError('Evidence needs a specific fact and an HTTP(S) source URL')


def screen_status(result):
    validate_schema(result, SCHEMAS['screen'])
    statuses = []
    for key in commercial_fit.SCREEN_CHECKS:
        check = result[key]
        validate_facts(check['evidence'], check['status'] in ('pass', 'fail'))
        if key != 'practice_size':
            statuses.append(check['status'])
    size = result['practice_size']
    counts = (size['clinic_count'], size['provider_count'])
    if any(n is not None for n in counts):
        validate_facts(size['evidence'], required=True)
    if commercial_fit.size_status(size) == 'fail':
        statuses.append('fail')
    return 'fail' if 'fail' in statuses else 'pass' if all(x == 'pass' for x in statuses) else 'uncertain'


def calculate(result, weights):
    validate_schema(result, SCHEMAS['score'])
    if result['eligibility_concern'].strip():
        raise ValueError('Eligibility concern must return to verification')
    points = {}
    for key in CATEGORIES:
        item = result['ratings'][key]
        validate_facts(item['evidence'], item['rating'] > 0)
        if item['rating'] > 0 and (item['unknown'] or not item['rationale'].strip()):
            raise ValueError('Positive ratings require known evidence and rationale')
        points[key] = weights[key] * item['rating'] / 4
    bonus = result['bonus']
    validate_facts(bonus['evidence'], bonus['tier'] > 0)
    if bonus['tier'] and not bonus['rationale'].strip():
        raise ValueError('Bonus needs an explicit alignment explanation')
    coverage = result['ai_coverage']
    validate_facts(coverage['evidence'], False)
    if coverage['adjustment'] != 0:
        raise ValueError('Existing AI deductions are disabled under the current rubric')
    base = sum(points.values())
    return {'points': points, 'regular': base, 'bonus': bonus['tier'], 'ai_adjustment': coverage['adjustment'], 'total': base + bonus['tier'] + coverage['adjustment']}


def kill_group(proc):
    if proc.poll() is not None:
        return
    with contextlib.suppress(ProcessLookupError):
        os.killpg(proc.pid, signal.SIGTERM)
    try:
        proc.wait(timeout=0.4)
    except subprocess.TimeoutExpired:
        with contextlib.suppress(ProcessLookupError):
            os.killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=2)


class CodexWorker:
    def __init__(self, cli=None):
        self.cli = cli or shutil.which('codex')
        if not self.cli:
            raise RuntimeError('Codex CLI is unavailable; run the skill in an installed Codex environment')

    def run(self, stage, prompt, schema, seconds, directory):
        directory.mkdir(parents=True, exist_ok=True)
        schema_path = directory / 'schema.json'
        result_path = directory / 'result.json'
        result_path.unlink(missing_ok=True)
        atomic_json(schema_path, schema)
        command = [self.cli, 'exec', '--ignore-user-config', '--skip-git-repo-check', '--ephemeral', '--sandbox', 'read-only',
                   '--json', '--output-schema', str(schema_path), '-o', str(result_path),
                   '-c', 'features.shell_tool=false', '-c', 'features.multi_agent=false',
                   '-c', 'features.apps=false', '-c', 'web_search="live"']
        user_config = Path(os.environ.get('CODEX_HOME', str(Path.home() / '.codex'))) / 'config.toml'
        if user_config.exists():
            settings = tomllib.loads(user_config.read_text())
            # Desktop-only MCP transports cannot be loaded by standalone Codex. Preserve
            # model/account selection without importing connector configuration or secrets.
            if settings.get('model_provider', 'openai') != 'openai':
                raise RuntimeError('This worker requires the signed-in OpenAI Codex provider')
            for name in ('model', 'model_reasoning_effort', 'forced_chatgpt_workspace_id', 'forced_login_method'):
                if name in settings:
                    command.extend(['-c', name + '=' + json.dumps(settings[name])])
        command.append('-')
        started = time.monotonic()
        usage, web_actions, seen = None, 0, set()
        reason, answer, buffer = '', None, b''
        completed_response = False
        with (directory / 'stderr.log').open('wb') as err, (directory / 'events.jsonl').open('wb') as log:
            proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err,
                                    cwd=directory, start_new_session=True)
            try:
                proc.stdin.write(prompt.encode())
                proc.stdin.close()
                selector = selectors.DefaultSelector()
                selector.register(proc.stdout, selectors.EVENT_READ)
                while selector.get_map():
                    if STOP.is_set() or time.monotonic() - started >= seconds:
                        reason = 'interrupted' if STOP.is_set() else 'time_limit'
                        kill_group(proc)
                        break
                    for key, _ in selector.select(timeout=min(0.2, max(0.01, seconds - (time.monotonic() - started)))):
                        chunk = os.read(key.fileobj.fileno(), 65536)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            continue
                        log.write(chunk)
                        buffer += chunk
                        if len(buffer) > 4_000_000:
                            reason = 'invalid_event_stream'
                            kill_group(proc)
                            break
                        while b'\n' in buffer:
                            line, buffer = buffer.split(b'\n', 1)
                            try:
                                event = json.loads(line)
                            except (ValueError, UnicodeDecodeError):
                                continue
                            if event.get('type') == 'turn.completed':
                                usage = event.get('usage')
                                # The CLI can finish the model turn before its process
                                # exits (or before -o is flushed). Do not spend the
                                # remaining research allowance waiting for cleanup.
                                if answer is not None:
                                    completed_response = True
                                    break
                            item = event.get('item', {})
                            typ, ident = item.get('type'), item.get('id')
                            if typ == 'web_search' and ident not in seen:
                                seen.add(ident)
                                web_actions += 1
                            if typ in ('command_execution', 'mcp_tool_call', 'file_change'):
                                reason = 'unexpected_tool'
                                kill_group(proc)
                            if typ == 'agent_message':
                                try:
                                    proposed = json.loads(item.get('text', ''))
                                    validate_schema(proposed, schema)
                                    answer = proposed
                                    # Retain returned evidence even if the turn never
                                    # completes. This file is diagnostic, not a pass.
                                    atomic_json(directory / 'stream-response.json', proposed)
                                except (ValueError, TypeError):
                                    pass
                    if reason or completed_response:
                        break
                selector.close()
                if not reason and not completed_response:
                    proc.wait(timeout=max(0.01, seconds - (time.monotonic() - started)))
                if not reason and not completed_response and proc.returncode:
                    reason = 'worker_error'
                if not reason and result_path.exists():
                    try:
                        answer = json.loads(result_path.read_text())
                        validate_schema(answer, schema)
                    except (ValueError, TypeError):
                        answer = None
                        reason = 'invalid_response'
                if not answer and not reason:
                    reason = 'no_structured_response'
            except subprocess.TimeoutExpired:
                reason = 'time_limit'
            finally:
                kill_group(proc)
                if proc.stdout:
                    proc.stdout.close()
        return {'response': answer, 'reason': reason, 'elapsed': round(time.monotonic() - started, 3),
                'usage': usage, 'web_actions': web_actions, 'stage': stage}


class Pipeline:
    def __init__(self, config_path=None, worker=None):
        self.config_path = Path(config_path or PACKAGE / 'config.json').resolve()
        self.cfg = json.loads(self.config_path.read_text())
        if self.cfg.get('setup_required'):
            raise RuntimeError('Run Development Partners setup and pass its machine-local --config first')
        self.master = (self.config_path.parent / self.cfg['master_workbook']).resolve()
        self.root = (self.config_path.parent / self.cfg['state_directory']).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.state_path = self.root / 'state.json'
        self.state = json.loads(self.state_path.read_text()) if self.state_path.exists() else {
            'version': 1, 'sources': {}, 'people': {}, 'candidates': {}, 'runs': []}
        for run in self.state['runs']:
            if run.get('status') == 'running':
                run['status'] = 'interrupted'
                run['stop_reason'] = 'Previous process ended before finalization; saved stages retained'
        self.prompts = json.loads((PACKAGE / 'references/agents.json').read_text())
        self.rubric = json.loads((PACKAGE / 'references/rubric.json').read_text())
        if set(self.cfg['weights']) != set(CATEGORIES) or sum(self.cfg['weights'].values()) != 100:
            raise ValueError('The six category weights must total 100')
        if any(float(self.cfg['limits'][k]) <= 0 for k in ('screen_seconds', 'score_seconds', 'discovery_chunk_seconds', 'parallel_workers')):
            raise ValueError('Time limits and worker count must be positive')
        self.worker = worker
        self.worker_factory = CodexWorker
        self.stop_event = STOP
        self.budget = WindowBudget()
        self.validate_schema = validate_schema
        self.validate_facts = validate_facts
        self.practice_schema = SCHEMAS['practice']
        self.atomic_json = atomic_json
        self.score_schema = SCHEMAS['score']

    @contextlib.contextmanager
    def locked(self):
        offline_research.research_access(self.cfg, self.root)
        with (self.root / 'run.lock').open('w') as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise RuntimeError('Another development-partner operation is active')
            try:
                if self.state_path.exists():
                    self.state = json.loads(self.state_path.read_text())
                for run in self.state['runs']:
                    if run.get('status') == 'running':
                        run['status'] = 'interrupted'
                        run['stop_reason'] = 'Previous process ended; saved stages retained'
                yield
            finally:
                fcntl.flock(lock, fcntl.LOCK_UN)

    def save(self):
        try:
            offline_research.research_access(self.cfg, self.root)
        except RuntimeError:
            # Recovery snapshot only; never overwrite canonical input after lease loss.
            recovery = self.root / 'lease-loss-recovery' / (uuid.uuid4().hex + '.json')
            recovery.parent.mkdir(parents=True, exist_ok=True)
            atomic_json(recovery, self.state)
            self.stop_event.set()
            raise
        atomic_json(self.state_path, self.state)

    def ingest(self):
        # Shared runs load the canonical database first. Workbook exports are views,
        # not competing sources of input/notes from different colleagues' machines.
        if self.cfg.get('shared_master', {}).get('enabled'):
            offline_research.research_access(self.cfg, self.root)
            return
        book = read_workbook(self.master)
        for source in self.state['sources'].values():
            if source.get('kind') != 'hubspot_clinic':
                source['enabled'] = False
        for person in self.state['people'].values():
            person['enabled'] = False
        for row in book.get('Hot Zones', []):
            url = str(row.get('URL', '')).strip()
            if not url:
                continue
            if not http_url(url):
                raise ValueError('Hot Zones URL must start with http:// or https://')
            ident = row.get('Source ID') or stable_id('z_', canonical_url(url))
            old = self.state['sources'].get(ident, {})
            if old and canonical_url(old['url']) != canonical_url(url):
                ident = stable_id('z_', canonical_url(url))
                old = self.state['sources'].get(ident, {})
            self.state['sources'][ident] = old | {'id': ident, 'name': row.get('Source name') or url,
                'url': url, 'priority': self.priority(row.get('Priority')), 'enabled': str(row.get('Enabled', '')).lower() not in ('no', 'false', '0'),
                'instructions': row.get('Instructions', ''), 'notes': row.get('Notes', ''), 'status': old.get('status', 'queued'),
                'cursor': old.get('cursor', ''), 'exhausted': old.get('exhausted', False)}
        for row in book.get('Initial People', []):
            first_name, last_name = str(row.get('First Name', '')).strip(), str(row.get('Last Name', '')).strip()
            name = str(row.get('Physician name', '')).strip() or ' '.join(p for p in (first_name, last_name) if p)
            if not name:
                continue
            practice = row.get('Company name', row.get('Practice', ''))
            website = row.get('Company website', row.get('Website', ''))
            city, region = row.get('Company city', row.get('City', '')), row.get('Company state', row.get('State', ''))
            ident = row.get('Input ID') or stable_id('p_', norm(name), norm(practice), website, city, region)
            old = self.state['people'].get(ident, {})
            self.state['people'][ident] = old | {'id': ident, 'name': name, 'first_name': first_name, 'last_name': last_name, 'practice': practice,
                'website': website, 'city': city, 'state': region,
                'priority': self.priority(row.get('Priority')), 'enabled': str(row.get('Enabled', '')).lower() not in ('no', 'false', '0'),
                'notes': row.get('Notes', '')}
        for row in book.get('Candidates', []):
            ident = row.get('Candidate ID')
            if ident in self.state['candidates']:
                self.state['candidates'][ident]['notes'] = row.get('Notes', '')
        for row in book.get('Enrichment', []):
            ident = row.get('Candidate ID')
            if ident in self.state['candidates']:
                choice = str(row.get('Enrich?', '')).strip() or 'Pending'
                if choice not in ('Pending', 'Yes', 'No'):
                    raise ValueError('Enrich? must be Pending, Yes or No')
                self.state['candidates'][ident].setdefault('enrichment', {})['choice'] = choice
        for row in book.get('HubSpot Contacts', []):
            ident = row.get('Candidate ID')
            if ident in self.state['candidates']:
                c = self.state['candidates'][ident]
                # These are explicit user-correctable fields, held by stable candidate ID.
                c['first_name'], c['last_name'] = row.get('First Name', ''), row.get('Last Name', '')
                hs = c.setdefault('hubspot', {})
                for column, key in [('Record ID - Contacts', 'contact_id'), ('Record ID - Notes', 'note_id')]:
                    value = str(row.get(column, '')).strip()
                    if value and not value.isdigit():
                        raise ValueError(column + ' must be an exact HubSpot record ID')
                    hs[key] = value
        for row in book.get('HubSpot Companies', []):
            key = row.get('Company key')
            if key:
                value = str(row.get('Record ID - Companies', '')).strip()
                if value and not value.isdigit():
                    raise ValueError('Record ID - Companies must be an exact HubSpot record ID')
                saved = self.state.setdefault('hubspot_companies', {}).setdefault(key, {})
                saved['record_id'] = value
                for column, field in [('Street Address', 'address'), ('Postal Code', 'zip'), ('Country/Region', 'country')]:
                    saved[field] = row.get(column, '')
        for area in self.state.setdefault('regions', {}).values():
            area['enabled'] = False
        for row in book.get('HubSpot Areas', []):
            city, region_state = str(row.get('City', '')).strip(), str(row.get('State', '')).strip()
            if not city and not region_state:
                continue
            code = regions.state_code(region_state)
            ident = regions.region_id(city, code)
            old = self.state['regions'].get(ident, {})
            self.state['regions'][ident] = old | {'id': ident, 'city': city, 'state': code,
                'state_name': regions.STATES[code], 'name': f'{city}, {code}' if city else regions.STATES[code],
                'priority': self.priority(row.get('Priority')), 'enabled': str(row.get('Enabled', '')).lower() not in ('no', 'false', '0'),
                'notes': row.get('Notes', ''), 'account_id': regions.ACCOUNT_ID,
                'status': old.get('status', 'queued'), 'last_id': old.get('last_id', ''),
                'fetched_ids': old.get('fetched_ids', []), 'pages': old.get('pages', []),
                'query_complete': old.get('query_complete', False), 'reported_total': old.get('reported_total')}
        self.save()

    @staticmethod
    def priority(value):
        if value in ('', None):
            return 3
        value = float(value)
        if not value.is_integer() or value < 1:
            raise ValueError('Priority must be a positive whole number')
        return int(value)

    def add_candidate(self, person, source):
        name, practice = person.get('name', '').strip(), person.get('practice', '').strip()
        if not name:
            raise ValueError('Candidate name is missing')
        npi = physician_identity.verified(person)
        if npi:
            matches = [c for c in self.state['candidates'].values() if c.get('npi') == npi and physician_identity.verified(c) == npi]
            if len(matches) > 1:
                raise ValueError('Multiple historical records share this NPI; reconcile receipts before merging')
            if matches:
                physician_identity.attach(matches[0], person, source)
                return matches[0]['id']
        domain = urllib.parse.urlsplit(person.get('website', '')).hostname or ''
        for ident, old in self.state['candidates'].items():
            old_domain = urllib.parse.urlsplit(old.get('website', '')).hostname or ''
            location_conflict = any(old.get(k) and person.get(k) and norm(old[k]) != norm(person[k]) for k in ('city', 'state'))
            practice_conflict = practice and old.get('practice') and norm(old['practice']) != norm(practice)
            same_practice = practice and norm(old.get('practice')) == norm(practice)
            same_domain = domain and old_domain == domain and not practice_conflict
            if npi and old.get('npi') and old['npi'] != npi:
                continue
            if not npi and not old.get('npi') and norm(old['name']) == norm(name) and not location_conflict and (same_practice or same_domain):
                old['sources'] = sorted(set(old['sources'] + [source]))
                for key in ('first_name', 'last_name', 'practice', 'website', 'city', 'state', 'specialty', 'signal'):
                    if person.get(key) and not old.get(key):
                        old[key] = person[key]
                for fact in person.get('evidence', []):
                    if fact not in old['discovery_evidence']:
                        old['discovery_evidence'].append(fact)
                return ident
        ident = stable_id('c_', 'npi', npi) if npi else stable_id('c_', norm(name), domain, norm(practice), norm(person.get('city')), norm(person.get('state')), person.get('input_id', source) if not (domain or practice) else '')
        if ident in self.state['candidates']:
            return ident
        self.state['candidates'][ident] = dict(person) | {'id': ident, 'name': name, 'sources': [source],
            'qualification': 'queued', 'research_status': 'not started', 'notes': '', 'updated': now(),
            'discovery_evidence': person.get('evidence', [])}
        return ident

    def call(self, stage, payload, run, label):
        offline_research.dispatch(self.cfg)
        if self.cfg.get('shared_master', {}).get('enabled'):
            offline_research.research_access(self.cfg, self.root)
        if STOP.is_set():
            return {'response': None, 'reason': 'interrupted', 'elapsed': 0, 'usage': None, 'web_actions': 0, 'stage': stage}
        limits = self.cfg['limits']
        seconds = limits.get('practice_screen_seconds', limits['screen_seconds']) if stage == 'practice' else limits[{'discovery': 'discovery_chunk_seconds', 'screen': 'screen_seconds', 'score': 'score_seconds'}[stage]]
        if not self.budget.allows(seconds):
            run['stop_reason'] = 'window_limit'
            return {'response': None, 'reason': 'window_limit', 'elapsed': 0, 'usage': None, 'web_actions': 0, 'stage': stage}
        if stage == 'score' and bonus_checks.enabled(self):
            payload = dict(payload) | {'bonus_reference_cases': bonus_checks.cases()}
        research_seconds = seconds
        if stage == 'score' and bonus_checks.enabled(self):
            reserve = min(float(self.cfg.get('bonus_checks', {}).get('review_seconds', 45)), seconds / 2)
            research_seconds = seconds - reserve
        prompt = self.prompts['shared'] + '\n' + self.prompts[stage] + f'\nReturn well before {research_seconds} seconds.\nINPUT DATA:\n' + json.dumps(payload, ensure_ascii=False)
        directory = self.root / 'workers' / run['id'] / (label + '-' + uuid.uuid4().hex[:6])
        if self.worker is None:
            self.worker = CodexWorker()
        started = time.monotonic()
        call_started_at = now()
        result = self.worker.run(stage, prompt, SCHEMAS[stage], research_seconds, directory)
        if stage == 'score' and bonus_checks.enabled(self):
            result = bonus_checks.attach_review(self, payload, result, run, max(0, seconds - (time.monotonic() - started)))
        result.update(started_at=call_started_at, finished_at=now(), stage=stage, label=label, wall_seconds_including_review=round(time.monotonic()-started,3))
        return result

    def record_call(self, run, result):
        review_call = result.get('bonus_review_call')
        if review_call:
            run['calls'].append({k: v for k, v in review_call.items() if k != 'response'})
        run['calls'].append({k: v for k, v in result.items() if k not in ('response', 'bonus_review_call', 'unreviewed_response')})
        self.save()

    def discover(self, source, run):
        seen_cursors = set()
        seen_content = set(source.get('content_fingerprints', []))
        while not source.get('exhausted') and not STOP.is_set():
            if not self.budget.allows(self.cfg['limits']['discovery_chunk_seconds']):
                run['stop_reason'] = 'window_limit'
                break
            cursor = source.get('cursor', '')
            if cursor in seen_cursors:
                source['status'] = 'discovery needs review'
                run['stop_reason'] = 'repeated_cursor'
                break
            seen_cursors.add(cursor)
            crm_clinic = source.get('kind') == 'hubspot_clinic'
            result = self.call('discovery', {'url': source['url'], 'instructions': source['instructions'], 'cursor': cursor,
                'verified_public_directory_link_inventory': source.get('hot_zone', {}).get('public_ui_link_cache'),
                'hubspot_clinic': source.get('hubspot') if crm_clinic else None,
                'scope': ('This one practice organization and its public physician-owner/leadership pages. The supplied HubSpot URL is a provenance reference, not a public page to open. Resolve its official public identity if needed; do not expand to other clinics in the city. Return a next public page or precise cursor only if useful work remains.' if crm_clinic else 'This finite collection and its pagination, not the whole domain. Return a next URL or precise section cursor. No candidate count quota. The runner deduplicates; continue from the cursor instead of replaying pages.')}, run, 'discovery')
            self.record_call(run, result)
            data = result.get('response')
            if not data or result.get('reason'):
                source['status'] = 'discovery needs review'
                run['stop_reason'] = result['reason'] or 'discovery_failed'
                if result.get('reason') in ('worker_error', 'unexpected_tool', 'invalid_event_stream'):
                    STOP.set()
                break
            try:
                validate_schema(data, SCHEMAS['discovery'])
                added = 0
                for person in data['candidates']:
                    validate_facts(person['evidence'], True)
                    before = len(self.state['candidates'])
                    candidate_id = self.add_candidate(person, source['id'])
                    if crm_clinic:
                        c = self.state['candidates'][candidate_id]
                        c.setdefault('hubspot_clinic_ids', [])
                        company_id = source['hubspot']['company_id']
                        if company_id not in c['hubspot_clinic_ids']:
                            c['hubspot_clinic_ids'].append(company_id)
                        # Carry an exact CRM identity forward only when both name and public domain agree.
                        if norm(person.get('practice')) == norm(source['hubspot']['name']) and hubspot.domain(person.get('website')) and hubspot.domain(person.get('website')) == hubspot.domain(source['url']):
                            record = self.state.setdefault('hubspot_companies', {}).setdefault(hubspot.company_key(c), {})
                            if not record.get('source_record_id') or record['source_record_id'] == company_id:
                                record['source_record_id'] = company_id
                            else:
                                c.setdefault('hubspot', {})['review_note'] = 'Conflicting HubSpot company IDs for this practice identity'
                    added += len(self.state['candidates']) - before
                next_cursor = data['next_cursor'].strip()
                content_id = stable_id('page_', json.dumps(data['candidates'], sort_keys=True))
                repeated_content = content_id in seen_content
                if not data['candidates'] and verified_episode_cursor_advanced(source, cursor, next_cursor):
                    repeated_content = False
                seen_content.add(content_id)
                source['content_fingerprints'] = sorted(seen_content)
                source['cursor'], source['exhausted'] = next_cursor, data['exhausted']
                run['discovered'] += added
                if not source['exhausted'] and (not next_cursor or next_cursor == cursor or repeated_content):
                    source['status'] = 'discovery needs review'
                    run['stop_reason'] = 'no_discovery_progress'
                    break
                source['status'] = 'discovered' if source['exhausted'] else 'discovering'
                self.save()
                print(json.dumps({'stage': 'discovery', 'new_candidates': added, 'exhausted': source['exhausted']}), flush=True)
                if getattr(self, 'discovery_chunks', None) is not None:
                    self.discovery_chunks -= 1
                    if self.discovery_chunks <= 0:
                        break
            except (ValueError, KeyError, TypeError) as exc:
                source['status'] = 'discovery needs review'
                run['stop_reason'] = 'invalid_discovery: ' + str(exc)
                break

    def apply_screen(self, candidate, result):
        practice_tags.observe_concierge(candidate, result.get('response'))
        data = result.get('response')
        if not data or result.get('reason'):
            candidate['qualification'] = 'queued' if result.get('reason') == 'worker_error' else 'uncertain'
            candidate['screen_error'] = result['reason'] or 'no_screen_response'
        else:
            if data.get('candidate_id') != candidate['id']:
                raise ValueError('Screening returned the wrong candidate ID')
            practice = practice_screening.for_candidate(self, candidate)
            if practice:
                for key in ('private_ownership', 'practice_size'):
                    if data[key] != practice[key]:
                        raise ValueError('Individual screen changed verified practice facts')
            candidate['qualification'] = screen_status(data)
            candidate['screen'] = data
            candidate['screen']['commercial_policy_version'] = commercial_fit.POLICY['version']
            candidate.pop('screen_error', None)
        candidate['updated'] = now()
        candidate['screen_workflow_version'] = commercial_fit.POLICY['version']

    def score_allowed(self, candidate):
        if commercial_fit.status(candidate) != 'pass':
            return False
        if candidate['qualification'] == 'pass':
            return True
        checks = candidate.get('screen', {})
        return (candidate['id'] == getattr(self, 'provisional_candidate', None)
                and candidate['qualification'] == 'uncertain'
                and checks.get('us_practice', {}).get('status') == 'pass'
                and all(checks.get(key, {}).get('status') in ('pass', 'uncertain')
                        for key in ('private_ownership', 'decision_authority')))

    def apply_score(self, candidate, result):
        practice_tags.observe_concierge(candidate, result.get('response'))
        if not self.score_allowed(candidate):
            raise ValueError('Scoring gate: candidate has not passed screening')
        data = result.get('response')
        candidate['updated'] = now()
        if not data or result.get('reason'):
            candidate['research_status'] = 'partial - ' + (result['reason'] or 'no response')
            return
        if data.get('candidate_id') != candidate['id']:
            raise ValueError('Scoring returned the wrong candidate ID')
        if data.get('eligibility_concern'):
            candidate['qualification'] = 'uncertain'
            candidate['research_status'] = 'verification needed'
            candidate['screen_error'] = data['eligibility_concern']
            candidate.pop('score', None)
            candidate.pop('calculated', None)
            return
        if bonus_checks.enabled(self):
            try:
                candidate['bonus_check'] = bonus_checks.require_verified(self, data, result)
            except (ValueError, KeyError, TypeError) as exc:
                if candidate.get('score'):
                    candidate.setdefault('assessment_history', []).append({
                        'superseded_at': now(), 'reason': 'New score withheld pending bonus verification',
                        **{k: candidate[k] for k in ('score', 'calculated', 'scored_at', 'rubric_version') if k in candidate}})
                candidate['score_review'] = {'status': 'Needs bonus verification', 'reason': str(exc),
                                            'draft': result.get('unreviewed_response', data),
                                            'review_call': result.get('bonus_review_call'), 'at': now()}
                candidate.pop('score', None)
                candidate.pop('calculated', None)
                candidate.pop('bonus_check', None)
                candidate['research_status'] = 'partial - bonus verification required'
                return
            candidate.pop('score_review', None)
        candidate['calculated'] = calculate(data, self.cfg['weights'])
        candidate['score'] = data
        candidate['scored_at'] = now()
        candidate['rubric_version'] = self.rubric['version']
        candidate['assessment_weights'] = dict(self.cfg['weights'])
        candidate['research_status'] = ('provisional - eligibility unverified' + ('; assessment partial' if data['partial'] else '')) if candidate['qualification'] != 'pass' else ('partial' if data['partial'] else 'complete')
        candidate['updated'] = now()

    def parallel_stage(self, stage, candidates, run):
        workers = int(self.cfg['limits']['parallel_workers'])
        todo = iter(candidates)
        with futures.ThreadPoolExecutor(max_workers=workers) as pool:
            active = {}
            def submit_next():
                if STOP.is_set():
                    return
                seconds = self.cfg['limits']['screen_seconds' if stage == 'screen' else 'score_seconds']
                if not self.budget.allows(seconds):
                    run['stop_reason'] = 'window_limit'
                    return
                candidate = next(todo, None)
                if candidate is None:
                    return
                if stage == 'score' and not self.score_allowed(candidate):
                    raise ValueError('Scoring gate refused dispatch')
                if candidate['id'] == getattr(self, 'fresh_candidate', None) or candidate['id'] in getattr(self, 'rubric_rescore_ids', set()):
                    candidate_payload = {k: candidate[k] for k in ('id', 'name', 'first_name', 'last_name', 'practice', 'website', 'city', 'state') if k in candidate}
                    if stage == 'score':
                        candidate_payload['screen'] = candidate['screen']
                else:
                    candidate_payload = {k: v for k, v in candidate.items() if k not in ('score', 'calculated', 'notes', 'assessment_history', 'screen_review_history', 'research_followups', 'enrichment', 'handoff', 'hubspot')}
                payload = {'candidate': candidate_payload}
                if stage == 'screen':
                    payload['commercial_policy'] = commercial_fit.POLICY
                    payload['verified_practice'] = practice_screening.for_candidate(self, candidate)
                    if candidate.get('screen'):
                        payload['unresolved_checks'] = [k for k in ('us_practice', 'decision_authority')
                            if candidate['screen'].get(k, {}).get('status') == 'uncertain']
                if stage == 'score':
                    payload['rubric'] = self.rubric
                    payload['provisional_analysis'] = candidate['qualification'] != 'pass'
                    if candidate.get('score'):
                        payload['previous_assessment'] = candidate['score']
                active[pool.submit(self.call, stage, payload, run, candidate['id'] + '-' + stage)] = candidate
            for _ in range(workers):
                submit_next()
            while active:
                ready, _ = futures.wait(active, timeout=0.5, return_when=futures.FIRST_COMPLETED)
                for future in ready:
                    candidate = active.pop(future)
                    try:
                        result = future.result()
                        self.record_call(run, result)
                        if result.get('reason') == 'window_limit':
                            run['stop_reason'] = 'window_limit'
                            continue
                        fatal = result.get('reason') or result.get('bonus_review_call', {}).get('reason')
                        if fatal in ('worker_error', 'unexpected_tool', 'invalid_event_stream'):
                            run['stop_reason'] = fatal
                            STOP.set()
                        if stage == 'screen':
                            self.apply_screen(candidate, result)
                            run['screened'] += 1
                        else:
                            self.apply_score(candidate, result)
                            run['scoring_attempts'] += 1
                    except Exception as exc:
                        if stage == 'screen':
                            candidate['qualification'] = 'uncertain'
                        else:
                            candidate['research_status'] = 'partial - invalid response'
                        candidate[stage + '_error'] = str(exc)
                    self.save()
                    print(json.dumps({'stage': stage, 'candidate': candidate['name'], 'qualification': candidate['qualification'], 'research': candidate['research_status']}), flush=True)
                    submit_next()

    def screen_to_score_reserve(self, candidates):
        limits = self.cfg['limits']
        needs_practice = any(not practice_screening.for_candidate(self, c)
                             or practice_screening.status(practice_screening.for_candidate(self, c)) == 'uncertain'
                             for c in candidates)
        practice_seconds = 2 * limits.get('practice_screen_seconds', limits['screen_seconds']) if needs_practice else 0
        # One practice wave and one individual wave, each with its bounded follow-up; scoring includes bonus review.
        preflight = 2 * self.cfg.get('bonus_checks', {}).get('review_seconds',45) if bonus_checks.enabled(self) else 0
        return practice_seconds + 2 * limits['screen_seconds'] + limits['score_seconds'] + preflight

    def process(self, source_id=None, retry_uncertain=False, retry_partial=False, ingest_inputs=True, export_workbook=True, provisional_candidate=None, fresh_candidate=None, rescore_stale=False):
        self.provisional_candidate = provisional_candidate
        self.fresh_candidate = fresh_candidate
        self.rubric_rescore_ids = set()
        if rescore_stale and fresh_candidate:
            raise ValueError('Choose either fresh screening or a rubric refresh')
        if fresh_candidate and (source_id != 'people' or fresh_candidate not in self.state['candidates']):
            raise ValueError('Fresh analysis requires one existing Initial People candidate')
        if fresh_candidate and provisional_candidate and fresh_candidate != provisional_candidate:
            raise ValueError('Fresh and provisional analysis must name the same candidate')
        if provisional_candidate and (source_id != 'people' or provisional_candidate not in self.state['candidates']):
            raise ValueError('Provisional analysis requires one existing Initial People candidate')
        if ingest_inputs:
            self.ingest()
        choices = sorted([s for s in self.state['sources'].values() if s.get('kind') != 'hubspot_clinic' and s.get('enabled') and s.get('status') in ('queued', 'discovered', 'discovering') and not source_policy.problem(s)], key=lambda s: (source_policy.FAMILIES[s['hot_zone']['source_family']], s['priority']))
        if source_id and source_id != 'people':
            if source_id not in self.state['sources']:
                raise ValueError('Unknown source ID')
            source = self.state['sources'][source_id]
            if source.get('zone_selection', {}).get('status') in ('pending', 'rejected', 'deferred'):
                raise ValueError('Select this proposed hot zone before starting physician research')
        elif source_id == 'people':
            source = None
        else:
            source = choices[0] if choices else None
        label = source['id'] if source else 'people'
        if source and source_policy.problem(source):
            raise ValueError('Source policy blocked research: ' + source_policy.problem(source))
        run = {'id': 'r_' + uuid.uuid4().hex[:12], 'started': now(), 'source': label, 'status': 'running',
            'discovered': 0, 'screened': 0, 'scoring_attempts': 0, 'calls': [], 'stop_reason': ''}
        self.state['runs'].append(run)
        self.save()
        started = time.monotonic()
        score_attempted = set()
        def finish_scores(rows):
            ready = [c for c in rows if c['id'] not in score_attempted and self.score_allowed(c)
                     and ('score' not in c or (retry_partial and c['research_status'].startswith('partial')))]
            if ready and bonus_checks.enabled(self):
                if self.budget.allows(2 * self.cfg.get('bonus_checks', {}).get('review_seconds', 45)):
                    bonus_checks.ensure_ready(self, now(), run=run)
                else:
                    run['stop_reason'] = 'window_limit'
                    ready = []
            score_attempted.update(c['id'] for c in ready)
            self.parallel_stage('score', ready, run)
        try:
            # Complete already-screened candidates before spending time on another discovery chunk.
            if source and not (fresh_candidate or provisional_candidate or rescore_stale):
                backlog = [c for c in self.state['candidates'].values() if label in c['sources']]
                finish_scores(backlog)
                run['backlog_score_attempts_before_discovery'] = len(score_attempted)
            if source:
                discovery_started = time.monotonic()
                self.discover(source, run)
                run['discovery_wall_seconds'] = round(time.monotonic()-discovery_started,3)
            else:
                active_people = set()
                priorities = {}
                for person in sorted(self.state['people'].values(), key=lambda p: p['priority']):
                    if person.get('enabled'):
                        person['candidate_id'] = self.add_candidate(person | {'input_id': person['id']}, 'people')
                        active_people.add(person['candidate_id'])
                        priorities[person['candidate_id']] = min(priorities.get(person['candidate_id'], person['priority']), person['priority'])
                self.save()
            candidates = [c for c in self.state['candidates'].values() if label in c['sources']]
            if not source:
                candidates = sorted([c for c in candidates if c['id'] in active_people], key=lambda c: priorities[c['id']])
            if provisional_candidate:
                candidates = [c for c in candidates if c['id'] == provisional_candidate]
                run['provisional_candidate'] = provisional_candidate
            if fresh_candidate:
                candidates = [c for c in candidates if c['id'] == fresh_candidate]
                if not candidates:
                    raise ValueError('Fresh candidate must be enabled in Initial People')
                run['fresh_candidate'] = fresh_candidate
                for candidate in candidates:
                    candidate.setdefault('assessment_history', []).append({
                        'superseded_at': now(), 'reason': 'Explicit fresh rerun; prior assessment excluded from worker inputs',
                        **{k: candidate[k] for k in ('screen', 'score', 'calculated', 'qualification', 'research_status', 'scored_at', 'rubric_version', 'assessment_weights', 'assessment_revision') if k in candidate}})
                    for key in ('screen', 'score', 'calculated', 'screen_error', 'score_error', 'scored_at', 'rubric_version', 'assessment_weights', 'assessment_revision'):
                        candidate.pop(key, None)
                    candidate['qualification'] = 'queued'
                    candidate['research_status'] = 'not started'
                self.save()
            initial_statuses = ('queued', 'uncertain') if retry_uncertain else ('queued',)
            screening = [c for c in candidates if (rescore_stale or c.get('research_status') != 'complete')
                and c['id'] not in getattr(self, 'screen_skip_ids', set())
                and (c['qualification'] in initial_statuses
                or (c['qualification'] == 'pass' and commercial_fit.status(c) == 'uncertain'))]
            # Small worker-sized batches: finish each batch's scores before admitting more screens.
            width = max(1, int(self.cfg['limits']['parallel_workers']))
            for offset in range(0, len(screening), width):
                batch = screening[offset:offset + width]
                reserve = self.screen_to_score_reserve(batch)
                if not self.budget.allows(reserve):
                    run['screening_admission'] = {'reason': 'reserve_for_scoring', 'required_seconds': reserve,
                                                 'remaining_seconds': self.budget.remaining(),
                                                 'deferred_candidate_ids': [c['id'] for c in screening[offset:]]}
                    break
                batch_started = time.monotonic()
                individual = practice_screening.prepare(self, batch, run)
                self.parallel_stage('screen', individual, run)
                followups = [c for c in individual if c['qualification'] == 'uncertain'
                             and c.get('screen') and not c.get('screen_error')]
                self.parallel_stage('screen', followups, run)
                finish_scores(batch)
                run.setdefault('screen_batches', []).append({'candidate_ids': [c['id'] for c in batch],
                    'wall_seconds': round(time.monotonic()-batch_started,3)})
                self.save()
                # Recompute remaining time on the next iteration; unused reserve is immediately reusable.
                if STOP.is_set():
                    break
            if rescore_stale:
                for candidate in candidates:
                    if not self.score_allowed(candidate) or not candidate.get('score') or candidate.get('rubric_version') == self.rubric['version']:
                        continue
                    candidate.setdefault('assessment_history', []).append({
                        'superseded_at': now(), 'reason': 'Explicit source rerun with updated rubric; prior assessment excluded from scoring inputs',
                        **{k: candidate[k] for k in ('score', 'calculated', 'qualification', 'research_status', 'scored_at', 'rubric_version', 'assessment_weights', 'assessment_revision') if k in candidate}})
                    for key in ('score', 'calculated', 'score_error', 'scored_at', 'rubric_version', 'assessment_weights', 'assessment_revision'):
                        candidate.pop(key, None)
                    candidate['research_status'] = 'not started'
                    self.rubric_rescore_ids.add(candidate['id'])
                run['rubric_refresh'] = {'version': self.rubric['version'], 'candidate_ids': sorted(self.rubric_rescore_ids)}
                self.save()
            finish_scores(candidates)
            if source:
                source['status'] = 'complete' if source.get('exhausted') and all(c['qualification'] == 'fail' or c.get('research_status') == 'complete' for c in candidates) else ('discovery needs review' if source.get('status') == 'discovery needs review' else 'paused')
            run['status'] = 'stopped' if run['stop_reason'] in ('worker_error', 'unexpected_tool', 'invalid_event_stream') else ('paused' if run['stop_reason'] == 'window_limit' else ('interrupted' if STOP.is_set() else 'finished'))
        finally:
            run['elapsed_seconds'] = round(time.monotonic() - started, 2)
            run['finished'] = now()
            if run['status'] == 'running':
                run['status'] = 'error'
            self.save()
            if export_workbook:
                export_started = time.monotonic()
                self.export()
                run['export_wall_seconds'] = round(time.monotonic()-export_started,3)
            run['total_wall_seconds_including_export'] = round(time.monotonic()-started,3)
            self.save()
        summary = {k: v for k, v in run.items() if k != 'calls'}
        if export_workbook:
            summary['enrichment_review'] = [r for r in clay.view(self) if r['eligible'] and r['choice'] == 'Pending']
        return summary

    def export(self, render_dir=None, updates=None):
        # Re-read human edits immediately before exporting, then detect races before replacement.
        expected = fingerprint(self.master)
        self.ingest()
        if fingerprint(self.master) != expected:
            raise RuntimeError('Workbook changed while reading inputs. Saved edits were preserved; run sync again.')
        for group, records in (updates or {}).items():
            for ident, record in records.items():
                self.state[group][ident] = self.state[group].get(ident, {}) | record
        handoff.apply(self, now())
        self.save()
        payload = self.root / 'export.json'
        atomic_json(payload, {'state': self.state, 'weights': self.cfg['weights'], 'hubspot': hubspot.build(self.state, self.cfg['weights']),
            'regions': [regions.summary(self, a) for a in self.state.get('regions', {}).values()], 'workflow': handoff.plan(self)})
        command = [self.cfg['node'], str(PACKAGE / 'scripts/workbook.mjs'), str(self.master), str(payload)]
        if render_dir:
            command.append(str(render_dir))
        environment = os.environ.copy()
        environment['DP_NODE_MODULES'] = self.cfg['node_modules']
        result = subprocess.run(command, capture_output=True, text=True, env=environment, timeout=180)
        if result.returncode:
            raise RuntimeError('Workbook refresh failed: ' + result.stderr[-2500:])
        pending = self.master.with_name(self.master.stem + '.pending.xlsx')
        if fingerprint(self.master) != expected:
            raise RuntimeError('Workbook changed during refresh. Saved edits were preserved; run sync again.')
        if self.master.exists():
            shutil.copy2(self.master, self.root / 'master-recovery.xlsx')
        os.replace(pending, self.master)

    def add_zone(self, name, url, priority=3, notes=''):
        self.ingest()
        if not http_url(url):
            raise ValueError('Source URL must be HTTP(S)')
        existing = hot_zone_intake.find_source(self.state, url)
        ident = existing['id'] if existing else stable_id('z_', canonical_url(url))
        old = self.state['sources'].get(ident, {})
        self.state['sources'][ident] = old | {'id': ident, 'name': name or url, 'url': url, 'priority': priority,
            'enabled': True, 'instructions': old.get('instructions', ''), 'notes': notes or old.get('notes', ''),
            'status': old.get('status', 'queued'), 'cursor': old.get('cursor', ''), 'exhausted': old.get('exhausted', False)}
        if old.get('zone_selection'):
            selection = self.state['sources'][ident]['zone_selection']
            selection.update(status='selected', decided_at=now())
            selection.setdefault('history', []).append({'status': 'selected', 'at': now(), 'reason': 'User directly supplied this source for research'})
            if self.state['sources'][ident]['status'] in ('awaiting selection', 'rejected', 'deferred'):
                self.state['sources'][ident]['status'] = 'queued'
        self.save()
        self.export(updates={'sources': {ident: json.loads(json.dumps(self.state['sources'][ident]))}})
        return ident

    def add_person(self, **person):
        self.ingest()
        person['name'] = person.get('name') or ' '.join(p for p in (person.get('first_name'), person.get('last_name')) if p)
        if not person['name'].strip():
            raise ValueError('Provide a physician name or first/last name')
        ident = stable_id('p_', norm(person['name']), norm(person.get('practice')), person.get('website'), person.get('city'), person.get('state'))
        old = self.state['people'].get(ident, {})
        self.state['people'][ident] = old | person | {'id': ident, 'enabled': True, 'priority': person.get('priority', 3)}
        self.save()
        self.export(updates={'people': {ident: json.loads(json.dumps(self.state['people'][ident]))}})
        return ident

    def process_region(self, region_id, retry_uncertain=False, retry_partial=False):
        self.ingest()
        area = self.state['regions'][region_id]
        if not area.get('enabled'):
            raise ValueError('This HubSpot area is disabled')
        if not area.get('query_complete'):
            raise ValueError('Finish the paginated HubSpot area lookup before starting clinic research')
        source_ids = ['hsclinic_' + i for i in area.get('fetched_ids', [])]
        area['status'] = 'processing'
        self.save()
        totals = {'discovered': 0, 'screened': 0, 'scoring_attempts': 0}
        last_export = time.monotonic()
        try:
            for source_id in source_ids:
                if STOP.is_set() or not self.state['regions'][region_id].get('enabled'):
                    break
                source = self.state['sources'][source_id]
                if source.get('status') == 'complete' or not source.get('enabled'):
                    continue
                if source.get('status') == 'discovery needs review':
                    continue
                result = self.process(source_id, retry_uncertain, retry_partial, ingest_inputs=False, export_workbook=False)
                for key in totals:
                    totals[key] += result[key]
                # State is saved after every stage. Refresh the large workbook periodically,
                # rather than importing/exporting it again for every clinic in a state.
                if time.monotonic() - last_export >= 60:
                    self.export()
                    last_export = time.monotonic()
        finally:
            area = self.state['regions'][region_id]
            area['status'] = 'complete' if all(self.state['sources'][i].get('status') == 'complete' or not self.state['sources'][i].get('enabled') for i in source_ids) else 'paused'
            self.save()
            self.export()
        return regions.summary(self, area) | totals | {'enrichment_review': [r for r in clay.view(self) if r['eligible'] and r['choice'] == 'Pending' and any(i in self.state['candidates'][r['candidate_id']]['sources'] for i in source_ids)]}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config')
    parser.add_argument('--deadline', help='Timezone-aware absolute research cutoff; reuse across all sources in the same window')
    parser.add_argument('--discovery-chunks', type=int, help='Discovery chunks before screening this pass; resume saved source cursor on the next pass')
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('status')
    commands.add_parser('sync')
    commands.add_parser('doctor')
    commands.add_parser('review')
    commands.add_parser('clay-plan')
    commands.add_parser('hubspot-plan')
    commands.add_parser('handoff-plan')
    commands.add_parser('hubspot-setup-plan')
    commands.add_parser('check-scoring')
    match = commands.add_parser('hubspot-match')
    match.add_argument('--candidate', required=True)
    match.add_argument('--file', required=True)
    crm_prepare = commands.add_parser('hubspot-prepare')
    crm_prepare.add_argument('--candidate', required=True)
    crm_prepare.add_argument('--kind', choices=['contact', 'note'], required=True)
    crm_prepare.add_argument('--confirmation', choices=['CONFIRMED', 'CONFIRMATION_WAIVED_FOR_SESSION'])
    crm_result = commands.add_parser('hubspot-results')
    crm_result.add_argument('--request', required=True)
    crm_result.add_argument('--file', required=True)
    area = commands.add_parser('add-region')
    area.add_argument('--city', default='')
    area.add_argument('--state', required=True)
    area.add_argument('--priority', type=int, default=3)
    area.add_argument('--notes', default='')
    next_page = commands.add_parser('region-query')
    next_page.add_argument('--region', required=True)
    imported_page = commands.add_parser('region-import')
    imported_page.add_argument('--region', required=True)
    imported_page.add_argument('--file', required=True)
    regional = commands.add_parser('run-region')
    regional.add_argument('--region', required=True)
    regional.add_argument('--retry-uncertain', action='store_true')
    regional.add_argument('--retry-partial', action='store_true')
    select = commands.add_parser('select-enrichment')
    select.add_argument('--candidate', action='append', required=True)
    select.add_argument('--choice', choices=['Pending', 'Yes', 'No'], required=True)
    prepare = commands.add_parser('clay-prepare')
    prepare.add_argument('--kind', choices=['lookup', 'email', 'company'], required=True)
    prepare.add_argument('--candidate', action='append', required=True)
    attach = commands.add_parser('clay-task')
    attach.add_argument('--request', required=True)
    attach.add_argument('--task-id', required=True)
    imported = commands.add_parser('clay-results')
    imported.add_argument('--request', required=True)
    imported.add_argument('--file', required=True)
    reuse = commands.add_parser('clay-reuse')
    reuse.add_argument('--candidate', action='append', required=True)
    retry = commands.add_parser('clay-retry')
    retry.add_argument('--request', required=True)
    init = commands.add_parser('init')
    init.add_argument('--render-dir')
    run = commands.add_parser('run')
    run.add_argument('--source')
    run.add_argument('--retry-uncertain', action='store_true')
    run.add_argument('--retry-partial', action='store_true')
    run.add_argument('--rescore-stale', action='store_true', help='Explicitly refresh eligible assessments from older rubric versions, retaining their history and enrichment')
    run.add_argument('--provisional-candidate', help='User-requested provisional assessment of one unresolved physician')
    run.add_argument('--fresh-candidate', help='Explicit fresh rerun of one physician with no prior assessment/evidence in worker inputs')
    zone = commands.add_parser('add-zone')
    zone.add_argument('--name', default='')
    zone.add_argument('--url', required=True)
    zone.add_argument('--priority', type=int, default=3)
    zone.add_argument('--notes', default='')
    person = commands.add_parser('add-person')
    person.add_argument('--name', default='')
    person.add_argument('--first-name', default='')
    person.add_argument('--last-name', default='')
    for key in ('practice', 'website', 'city', 'state', 'notes'):
        person.add_argument('--' + key, default='')
    person.add_argument('--priority', type=int, default=3)
    args = parser.parse_args()
    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    pipeline = Pipeline(args.config)
    pipeline.budget = WindowBudget(args.deadline)
    if args.discovery_chunks is not None and args.discovery_chunks < 1:
        parser.error('--discovery-chunks must be positive')
    pipeline.discovery_chunks = args.discovery_chunks
    with pipeline.locked():
        if args.command == 'check-scoring':
            report = bonus_checks.ensure_ready(pipeline, now(), force=True)
            print(json.dumps({k: v for k, v in report.items() if k != 'results'} | {'cases': [{k: v for k, v in row.items() if k != 'raw_result'} for row in report['results']]}, indent=2))
        elif args.command == 'doctor':
            print(json.dumps({'codex': shutil.which('codex'), 'node_exists': Path(pipeline.cfg['node']).exists(),
                'artifact_tool_exists': (Path(pipeline.cfg['node_modules']) / '@oai/artifact-tool').exists(),
                'master': str(pipeline.master), 'master_exists': pipeline.master.exists(),
                'limits': pipeline.cfg['limits'], 'live_research_tested': False}, indent=2))
        elif args.command == 'init':
            pipeline.export(Path(args.render_dir) if args.render_dir else None)
            print(str(pipeline.master))
        elif args.command == 'sync':
            pipeline.export()
            print(str(pipeline.master))
        elif args.command == 'status':
            pipeline.ingest()
            print(json.dumps({'sources': [s for s in pipeline.state['sources'].values() if s.get('kind') != 'hubspot_clinic'], 'initial_people': list(pipeline.state['people'].values()),
                'candidate_count': len(pipeline.state['candidates']), 'master': str(pipeline.master),
                'hubspot_regions': [regions.summary(pipeline, a) for a in pipeline.state.get('regions', {}).values()],
                'hubspot_clinic_count': sum(s.get('kind') == 'hubspot_clinic' for s in pipeline.state['sources'].values()),
                'enrichment_review': clay.view(pipeline)}, indent=2))
        elif args.command == 'add-region':
            pipeline.ingest()
            print(json.dumps(regions.add_region(pipeline, args.city, args.state, args.priority, args.notes, now()), indent=2))
        elif args.command == 'region-query':
            pipeline.ingest()
            print(json.dumps(regions.summary(pipeline, pipeline.state['regions'][args.region]), indent=2))
        elif args.command == 'region-import':
            pipeline.ingest()
            print(json.dumps(regions.ingest_page(pipeline, args.region, json.loads(Path(args.file).read_text()), now()), indent=2))
        elif args.command == 'run-region':
            print(json.dumps(pipeline.process_region(args.region, args.retry_uncertain, args.retry_partial), indent=2))
        elif args.command in ('review', 'clay-plan'):
            pipeline.ingest()
            print(json.dumps({'candidates': clay.view(pipeline),
                'requests': [{k: v for k, v in r.items() if k in ('id', 'kind', 'candidate_ids', 'status', 'task_id', 'created', 'finished')} for r in pipeline.state.get('clay_requests', {}).values()], 'clay': pipeline.cfg.get('clay')}, indent=2))
        elif args.command == 'handoff-plan':
            pipeline.export()
            print(json.dumps(handoff.plan(pipeline), indent=2))
        elif args.command == 'hubspot-setup-plan':
            print(json.dumps(registration.setup_plan(pipeline), indent=2))
        elif args.command == 'hubspot-match':
            pipeline.ingest()
            registration.import_match(pipeline, args.candidate, json.loads(Path(args.file).read_text()), now())
        elif args.command == 'hubspot-prepare':
            pipeline.ingest()
            print(json.dumps(registration.prepare(pipeline, args.candidate, args.kind, now(), args.confirmation), indent=2))
        elif args.command == 'hubspot-results':
            pipeline.ingest()
            registration.import_result(pipeline, args.request, json.loads(Path(args.file).read_text()), now())
        elif args.command == 'hubspot-plan':
            pipeline.ingest()
            print(json.dumps(hubspot.build(pipeline.state, pipeline.cfg['weights']), indent=2))
        elif args.command == 'select-enrichment':
            pipeline.ingest()
            clay.select(pipeline, args.candidate, args.choice, now())
            print(json.dumps(clay.view(pipeline), indent=2))
        elif args.command == 'clay-prepare':
            pipeline.ingest()
            print(json.dumps(clay.prepare(pipeline, args.kind, args.candidate, now()), indent=2))
        elif args.command == 'clay-task':
            pipeline.ingest()
            clay.attach(pipeline, args.request, args.task_id, now())
        elif args.command == 'clay-results':
            pipeline.ingest()
            clay.ingest_results(pipeline, args.request, json.loads(Path(args.file).read_text()), now())
        elif args.command == 'clay-reuse':
            pipeline.ingest()
            clay.reuse(pipeline, args.candidate, now())
        elif args.command == 'clay-retry':
            pipeline.ingest()
            clay.retry(pipeline, args.request, now())
        elif args.command == 'run':
            print(json.dumps(pipeline.process(args.source, args.retry_uncertain, args.retry_partial, provisional_candidate=args.provisional_candidate, fresh_candidate=args.fresh_candidate, rescore_stale=args.rescore_stale), indent=2))
        elif args.command == 'add-zone':
            print(pipeline.add_zone(args.name, args.url, args.priority, args.notes))
        elif args.command == 'add-person':
            print(pipeline.add_person(**{key: getattr(args, key) for key in ('name', 'first_name', 'last_name', 'practice', 'website', 'city', 'state', 'notes', 'priority')}))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
