"""Verified individual NPI keys; organization identifiers never identify physicians."""
from urllib.parse import urlsplit


def verified(person):
    number = person.get('npi', '')
    if not number:
        return None
    if not isinstance(number, str) or len(number) != 10 or not number.isascii() or not number.isdigit():
        raise ValueError('NPI must contain ten digits')
    digits = [int(x) for x in '80840' + number]
    total = sum((d * 2 - 9 if d * 2 > 9 else d * 2) if i % 2 else d for i, d in enumerate(reversed(digits)))
    if total % 10:
        raise ValueError('Invalid NPI checksum')
    if person.get('npi_entity_type') != 'NPI-1':
        raise ValueError('Physician identity requires verified Type 1 NPI')
    url = person.get('npi_registry_url', '')
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or parsed.hostname != 'npiregistry.cms.hhs.gov' or parsed.username or parsed.password:
        raise ValueError('NPI verification requires official registry provenance')
    if not person.get('npi_match_evidence', '').strip():
        raise ValueError('Record name and specialty/location evidence matching this physician')
    return number


def attach(old, person, source):
    old['sources'] = sorted(set(old.get('sources', []) + [source]))
    for key in ('npi','npi_entity_type','npi_registry_url','npi_match_evidence'):
        old[key] = person[key]
    for fact in person.get('evidence', []):
        if fact not in old.setdefault('discovery_evidence', []):
            old['discovery_evidence'].append(fact)
    alias = {k:person.get(k, '') for k in ('name','practice','website','city','state')}
    if alias not in old.setdefault('identity_appearances', []):
        old['identity_appearances'].append(alias)
    # Keep established practice facts, assessments and connector receipts unchanged.
