import practice_tags
"""Practice-first screens shared by exact practice identity, with bounded follow-ups."""
import concurrent.futures as futures
import copy
import datetime as dt
import hashlib
import json
from urllib.parse import urlsplit

import commercial_fit


def identity(candidate):
    host = (urlsplit(candidate.get('website', '')).hostname or '').lower().removeprefix('www.')
    name = ' '.join(candidate.get('practice', '').casefold().split())
    # Missing/ambiguous organization identity is deliberately not shared.
    parts = [host, name] if host and name else ['candidate', candidate['id']]
    return 'practice_' + hashlib.sha256(json.dumps(parts).encode()).hexdigest()[:16]


def fresh(record):
    if record.get('version') != commercial_fit.POLICY['version']:
        return False
    try:
        age = dt.datetime.now(dt.timezone.utc) - dt.datetime.fromisoformat(record['checked_at'])
        return dt.timedelta(0) <= age <= dt.timedelta(days=7)
    except (KeyError, ValueError):
        return False


def for_candidate(p, candidate):
    record = p.state.get('practice_screens', {}).get(identity(candidate), {})
    if getattr(p, 'fresh_candidate', None) == candidate['id'] and not record.get('run_id') == getattr(p, '_practice_run_id', None):
        return None
    return copy.deepcopy(record.get('screen')) if fresh(record) else None


def status(screen):
    checks = [screen[k]['status'] for k in ('us_practice', 'private_ownership')]
    if 'fail' in checks or commercial_fit.size_status(screen['practice_size']) == 'fail':
        return 'fail'
    return 'pass' if all(x == 'pass' for x in checks) else 'uncertain'


def prepare(p, candidates, run):
    """Resolve organization facts before dispatching individual authority checks."""
    if not candidates:
        return []
    p._practice_run_id = run['id']
    records = p.state.setdefault('practice_screens', {})
    groups = {}
    for c in candidates:
        c['screen_workflow_version'] = commercial_fit.POLICY['version']
        groups.setdefault(identity(c), []).append(c)
    todo = []
    for key, group in groups.items():
        cached = for_candidate(p, group[0])
        if not cached or status(cached) == 'uncertain':
            todo.append((key, group))
    # Existing three-worker ceiling; each individual call checks the absolute deadline.
    def research(key, group):
        old = for_candidate(p, group[0])
        payload = {'practice_id': key, 'practice': group[0].get('practice', ''),
                   'website': group[0].get('website', ''), 'commercial_policy': commercial_fit.POLICY,
                   'physicians': [{k: c.get(k, '') for k in ('id', 'name', 'practice', 'website', 'city', 'state', 'discovery_evidence')} for c in group],
                   'saved_practice': old,
                   'unresolved_checks': [k for k in ('us_practice', 'private_ownership', 'practice_size') if not old or old[k]['status'] == 'uncertain']}
        # At most two attempts per organization/run. The second targets only gaps.
        calls = []
        for attempt in range(2):
            result = p.call('practice', payload, run, key + '-practice')
            calls.append(result)
            if result.get('reason') in ('worker_error', 'unexpected_tool', 'invalid_event_stream'):
                p.stop_event.set()
                run['stop_reason'] = result['reason']
            screen = result.get('response')
            if result.get('reason') or not screen:
                break
            p.validate_schema(screen, p.practice_schema)
            if screen['practice_id'] != key:
                raise ValueError('Practice screen returned the wrong identity')
            for k in ('us_practice', 'private_ownership', 'practice_size'):
                p.validate_facts(screen[k]['evidence'], screen[k]['status'] in ('pass', 'fail'))
                if old and old[k]['status'] != 'uncertain' and screen[k] != old[k]:
                    raise ValueError('Follow-up changed an established practice check')
            if status(screen) != 'uncertain':
                break
            old = screen
            payload.update(saved_practice=screen, unresolved_checks=[k for k in ('us_practice', 'private_ownership') if screen[k]['status'] == 'uncertain'])
        return key, calls

    with futures.ThreadPoolExecutor(max_workers=int(p.cfg['limits']['parallel_workers'])) as pool:
        pending = {pool.submit(research, key, group): key for key, group in todo}
        for future in futures.as_completed(pending):
            key = pending[future]
            try:
                _, calls = future.result()
                for result in calls:
                    p.record_call(run, result)
                    screen = result.get('response')
                    if screen and not result.get('reason'):
                        records[key] = {'version': commercial_fit.POLICY['version'], 'checked_at': dt.datetime.now(dt.timezone.utc).isoformat(),
                                        'run_id': run['id'], 'screen': copy.deepcopy(screen), 'candidate_ids': [c['id'] for c in groups[key]]}
                    elif result.get('reason') == 'window_limit':
                        run['stop_reason'] = 'window_limit'
                    else:
                        run.setdefault('practice_errors', []).append({'practice_id': key, 'reason': result.get('reason') or 'no_response'})
            except Exception as exc:
                run.setdefault('practice_errors', []).append({'practice_id': key, 'reason': str(exc)})
            p.save()
    individual = []
    for key, group in groups.items():
        screen = for_candidate(p, group[0])
        for c in group:
            practice_tags.observe_concierge(c, screen)
            if screen and status(screen) == 'pass':
                individual.append(c)
                continue
            c['qualification'] = status(screen) if screen else 'uncertain'
            c['screen_error'] = 'Practice screening unresolved' if c['qualification'] == 'uncertain' else 'Practice exclusion'
            c['practice_screen_id'] = key
            if screen:
                c['practice_screen'] = copy.deepcopy(screen)
            run['screened'] += 1
    p.save()
    return individual
