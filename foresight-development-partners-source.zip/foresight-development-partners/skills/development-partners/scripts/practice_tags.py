"""Lightweight observed practice wording, without extra research or CRM changes."""
import re

def observe_concierge(candidate, extra=None):
    items=[]
    for key in ('practice','signal'):
        if candidate.get(key):items.append({'fact':candidate[key],'url':candidate.get('website',''),'basis':key})
    for key in ('evidence','discovery_evidence'):
        items.extend(x for x in candidate.get(key,[]) if isinstance(x,dict))
    for data in (candidate.get('screen'),candidate.get('practice_screen'),extra):
        if isinstance(data,dict):
            for value in data.values():
                if isinstance(value,dict):items.extend(x for x in value.get('evidence',[]) if isinstance(x,dict))
    matches=[]
    for item in items:
        fact=item.get('fact','')
        # Ignore explicitly negated wording rather than matching the substring blindly.
        text=re.sub(r'\b(?:not\s+(?:a\s+)?|non[-\s]?|no\s+)concierge\b','',fact,flags=re.I)
        if re.search(r'\bconcierge\b',text,re.I) and item not in matches:matches.append(item)
    old=candidate.get('concierge_observation',{})
    prior=old.get('evidence',[]) if candidate.get('concierge')=='Yes' else []
    combined=prior+[x for x in matches if x not in prior]
    candidate['concierge']='Yes' if combined else 'No'
    candidate['concierge_observation']={'method':'Observed concierge wording during ordinary research; no extra lookup','no_means':'Not observed, not verified absence','evidence':combined}
    return candidate['concierge']
