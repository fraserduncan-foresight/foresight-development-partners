"""Bounded parent-connector checkout transfer; never acquires or changes a lease."""
import argparse
import hashlib
import json
from pathlib import Path
import shared_master as sm

def plan(receipt, directory):
    meta = sm.unpack(json.loads(Path(receipt).read_text()))
    if not meta.get('ok') or 'document_length' not in meta:
        raise ValueError('Expected successful metadata-only checkout receipt')
    root = Path(directory); root.mkdir(parents=True, exist_ok=True)
    sm.write(root/'metadata.json', meta)
    requests = []
    for start in range(0, meta['document_length'], 100000):
        query = ("select jsonb_build_object('revision',m.revision,'offset',"+str(start)+",'chunk',substring(m.document::text from "+str(start+1)+" for 100000)) as shared_result from development_partners.master m join development_partners.run_lock l on l.id=m.id where m.id='foresight' and m.revision="+str(int(meta['revision']))+" and l.owner="+sm.quote(meta['owner'])+"::uuid and l.generation="+str(int(meta['generation']))+" and l.expires_at>clock_timestamp();")
        requests.append({'offset':start,'arguments':{'project_id':sm.PROJECT,'query':query},'response_file':str(root/(str(start)+'.json'))})
    sm.write(root/'plan.json', requests)
    return {'pages':len(requests),'plan':str(root/'plan.json')}

def assemble(directory, output):
    root=Path(directory);meta=json.loads((root/'metadata.json').read_text())
    chunks=[]
    for job in json.loads((root/'plan.json').read_text()):
        row=sm.unpack(json.loads(Path(job['response_file']).read_text()))
        if row.get('revision')!=meta['revision'] or row.get('offset')!=job['offset']:
            raise ValueError('Checkout page revision/offset mismatch')
        chunks.append(row['chunk'])
    document=''.join(chunks)
    if len(document)!=meta['document_length'] or hashlib.md5(document.encode()).hexdigest()!=meta['document_md5']:
        raise ValueError('Checkout document checksum/length mismatch')
    result=meta|{'document':json.loads(document)}
    sm.write(output,{'content':[{'type':'text','text':json.dumps({'result':[{'shared_result':result}]})}], 'retrieval':'Verified metadata receipt and pinned pages; raw responses retained in '+str(root)})
    return {'assembled':str(output),'revision':meta['revision']}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['plan','assemble']);p.add_argument('--receipt');p.add_argument('--directory',required=True);p.add_argument('--output');a=p.parse_args()
    print(json.dumps(plan(a.receipt,a.directory) if a.action=='plan' else assemble(a.directory,a.output)))
