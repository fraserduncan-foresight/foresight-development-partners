"""Parent-connector SQL bridge; no credentials, remote authentication or network calls."""
from __future__ import annotations
import argparse
import datetime as dt
import fcntl
import json
from pathlib import Path
import re
import uuid
import os
import secrets
import hashlib

PROJECT = 'svdtzmjpqvdvntlicpvt'
PACKAGE = Path(__file__).resolve().parents[1]


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix('.tmp')
    pending.write_text(json.dumps(data, ensure_ascii=False) + '\n')
    pending.replace(path)


def settings(config):
    path = Path(config).resolve()
    cfg = json.loads(path.read_text())
    if cfg.get('setup_required'):
        raise RuntimeError('Run Development Partners setup and use its machine-local config first')
    root = (path.parent / cfg['state_directory']).resolve()
    return cfg, root


def require_lease(cfg, root, allow_unhealthy=False):
    if cfg.get('offline_research'):
        raise RuntimeError('Offline branch cannot access canonical lease or external writes')
    if not cfg.get('shared_master', {}).get('enabled'):
        return None
    path = root / 'shared-session.json'
    if not path.exists():
        raise RuntimeError('Shared master requires checkout through Supabase before this operation')
    session = json.loads(path.read_text())
    if session.get('heartbeat_enabled'):
        health_path = root / 'heartbeat-status.json'
        health = json.loads(health_path.read_text()) if health_path.exists() else {}
        checked = dt.datetime.fromisoformat(health.get('checked_at', '2000-01-01T00:00:00+00:00'))
        if not allow_unhealthy and (health.get('state') != 'healthy' or health.get('owner') != session['owner'] or health.get('generation') != session['generation'] or (dt.datetime.now(dt.timezone.utc)-checked).total_seconds() > 150):
            raise RuntimeError('Independent lease heartbeat unhealthy; stop dispatch and external writes')
        session['expires_at'] = max(session.get('expires_at') or '', health.get('expires_at') or '')
    expiry = dt.datetime.fromisoformat((session.get('expires_at') or '').replace('Z', '+00:00')) if session.get('expires_at') else None
    if session.get('project_id') != cfg['shared_master']['project_id'] or not expiry or expiry <= dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=15):
        raise RuntimeError('Shared lease missing/expired; stop, reconnect and reconcile before continuing')
    uuid.UUID(session['owner'])
    return session


def quote(value):
    return "'" + value.replace("'", "''") + "'"


def json_equal(a, b):
    """JSONB treats numeric 1 and 1.0 equally, but never boolean true as 1."""
    if isinstance(a, bool) or isinstance(b, bool):
        return type(a) is type(b) and a == b
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(json_equal(a[k], b[k]) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a, b))
    return a == b


def document_changes(base, target, path=()):
    """Absolute, idempotent changes; recurse through keyed records, replace arrays."""
    if isinstance(base, dict) and isinstance(target, dict):
        rows = []
        for key in sorted(set(base) | set(target)):
            if key not in target:
                rows.append((path + (key,), None, True))
            elif key not in base:
                rows.append((path + (key,), target[key], False))
            else:
                rows.extend(document_changes(base[key], target[key], path + (key,)))
        return rows
    return [] if json_equal(base, target) else [(path, target, False)]


def _json_literal(value):
    return quote(json.dumps(value,ensure_ascii=False,separators=(',',':'))) + '::jsonb'


def _delta_value(old,new,path=()):
    ref='m.document' if not path else '(m.document #> ARRAY['+','.join(quote(x) for x in path)+']::text[])'
    if isinstance(old,list) and isinstance(new,list):
        for i in range(min(len(old),len(new))):
            if not json_equal(old[i], new[i]):
                ref='jsonb_set('+ref+',ARRAY['+quote(str(i))+']::text[],'+_delta_value(old[i],new[i],path+(str(i),))+',true)'
        for i in range(len(old)-1,len(new)-1,-1):ref='('+ref+' - '+str(i)+')'
        if len(new)>len(old):ref='('+ref+' || '+_json_literal(new[len(old):])+')'
        return ref
    if not isinstance(old,dict) or not isinstance(new,dict):return _json_literal(new)
    removed=sorted(set(old)-set(new))
    if removed:ref='('+ref+' - ARRAY['+','.join(quote(x) for x in removed)+']::text[])'
    changed=[k for k in new if k not in old or not json_equal(old[k], new[k])]
    # Existing objects are patched recursively; entire unchanged records stay server-side.
    for i in range(0,len(changed),30):
        fields=[]
        for k in changed[i:i+30]:fields += [quote(k),_delta_value(old[k],new[k],path+(k,)) if k in old else _json_literal(new[k])]
        ref='('+ref+' || jsonb_build_object('+','.join(fields)+'))'
    return ref

def delta_expression(base, target):
    """Patch only changed nested fields/array indexes; retain guarded RPC semantics."""
    return _delta_value(base, target)


def save_query(request, document, base=None):
    payload = quote(json.dumps(document, ensure_ascii=False, separators=(',', ':'))) + '::jsonb'
    if base is not None:
        payload = "(with m as materialized (select document || '{}'::jsonb as document from development_partners.master where id = 'foresight') select " + delta_expression(base, document) + " from m)"
    # The existing server function still checks owner, lease, revision, and request
    # signature. Replaying absolute changes on an already-saved target is idempotent.
    return ('select development_partners.save_checkpoint('
            f"{quote(request['id'])}::uuid, {quote(request['owner'])}::uuid, {int(request['generation'])}, {int(request['revision'])}, "
            f"{payload}, {'true' if request['action'] == 'release' else 'false'}) as shared_result;")


def heartbeat_deadline_allowed(cfg, until, at):
    if until.tzinfo is None or until <= at:
        return False
    if until <= at + dt.timedelta(minutes=129):
        return True
    window = cfg.get('shared_master', {}).get('heartbeat', {}).get('authorized_extended_window', {})
    try:
        start = dt.datetime.fromisoformat(window['setup_after'])
        finish = dt.datetime.fromisoformat(window['finish_until'])
        minutes = float(window['maximum_minutes'])
        return 0 < minutes <= 540 and start <= at < finish and until <= finish and until <= at + dt.timedelta(minutes=minutes)
    except (KeyError, ValueError, TypeError):
        return False


def prepare(config, action, holder='', heartbeat_until=None):
    cfg, root = settings(config)
    if cfg.get('offline_research'):
        raise ValueError('Use canonical config for checkout/checkpoint/release')
    if not cfg.get('shared_master', {}).get('enabled'):
        raise ValueError('This config is not connected to the shared master')
    request = {'id': str(uuid.uuid4()), 'action': action, 'project_id': cfg['shared_master']['project_id']}
    if action == 'checkout':
        # Existing live local session must be resolved rather than abandoned.
        if (root / 'shared-session.json').exists():
            try:
                require_lease(cfg, root)
            except RuntimeError:
                pass
            else:
                raise ValueError('A local shared session is active; checkpoint/release it first')
        request['owner'] = str(uuid.uuid4())
        query = f"select development_partners.checkout({quote(request['owner'])}::uuid, {quote(holder)}) as shared_result;"
        if cfg['shared_master'].get('heartbeat', {}).get('enabled'):
            until = dt.datetime.fromisoformat(heartbeat_until.replace('Z','+00:00')) if heartbeat_until else dt.datetime.now(dt.timezone.utc)+dt.timedelta(minutes=125)
            if not heartbeat_deadline_allowed(cfg, until, dt.datetime.now(dt.timezone.utc)):
                raise ValueError('Heartbeat deadline exceeds ordinary129-minute or explicitly authorized occurrence bounds')
            token = secrets.token_hex(32)
            token_file = root / 'heartbeat-secrets' / (request['owner']+'.token')
            token_file.parent.mkdir(parents=True,exist_ok=True)
            os.chmod(token_file.parent,0o700)
            fd=os.open(token_file,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'w') as out:out.write(token)
            request.update(heartbeat_token_file=str(token_file),heartbeat_until=until.isoformat())
            hashed=hashlib.sha256(token.encode()).hexdigest()
            query = (f"with c as materialized (select development_partners.checkout({quote(request['owner'])}::uuid, {quote(holder)}) as r) "
                     f"select case when (r->>'ok')::boolean then case when development_partners.enable_heartbeat({quote(request['owner'])}::uuid,(r->>'generation')::bigint,{quote(hashed)},{quote(until.isoformat())}::timestamptz) then r else r end else r end as shared_result from c;")

        # Return a bounded checkout receipt; fetch the pinned document in pages.
        query = "with checkout_result as materialized (" + query.rstrip(';') + ") select (shared_result - 'document') || case when shared_result ? 'document' then jsonb_build_object('document_length', length((shared_result->'document')::text), 'document_md5', md5((shared_result->'document')::text)) else '{}'::jsonb end as shared_result from checkout_result;"
    else:
        session = require_lease(cfg, root, allow_unhealthy=action == 'release')
        request.update({k: session[k] for k in ('owner', 'generation', 'revision')})
        document = json.loads((root / 'state.json').read_text())
        base_path = root / 'shared-base.json'
        base = json.loads(base_path.read_text()) if base_path.exists() else {}
        query = save_query(request, document, base.get('document') if base.get('revision') == session['revision'] else None)
        request['prepared_document'] = document
    request['arguments'] = {'project_id': request['project_id'], 'query': query}
    write(root / 'shared-requests' / (request['id'] + '.json'), request)
    return request


def unpack(raw):
    if raw.get('isError'):
        raise ValueError('Supabase returned an error; no local checkpoint accepted')
    for block in raw.get('content', []):
        if block.get('type') != 'text':
            continue
        outer = json.loads(block['text'])
        value = outer.get('result')
        if isinstance(value, str):
            match = re.search(r'^<untrusted-data-[^>]+>\s*([\s\S]*?)\s*^</untrusted-data-[^>]+>', value, re.MULTILINE)
            if match:
                value = json.loads(match[1])
        if isinstance(value, list) and len(value) == 1 and 'shared_result' in value[0]:
            return value[0]['shared_result']
    raise ValueError('Expected actual Supabase execute_sql shared_result response')


def accept(config, request_id, raw):
    cfg, root = settings(config)
    request_path = root / 'shared-requests' / (str(uuid.UUID(request_id)) + '.json')
    request = json.loads(request_path.read_text())
    if request.get('accepted'):
        raise ValueError('Response already accepted')
    result = unpack(raw)
    if result.get('ok') is not True:
        raise RuntimeError('Shared master busy: ' + str(result.get('holder', 'another colleague')))
    if result.get('owner') != request['owner']:
        raise ValueError('Shared response owner mismatch')
    session = {'project_id': request['project_id'], 'owner': result['owner'],
               'generation': result['generation'], 'revision': result['revision'],
               'expires_at': result.get('expires_at')}
    if request['action'] == 'checkout':
        document = result.get('document')
        if not isinstance(document, dict) or not all(k in document for k in ('candidates', 'sources', 'people', 'runs')):
            raise ValueError('Invalid shared state')
        root.mkdir(parents=True, exist_ok=True)
        with (root / 'run.lock').open('w') as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise RuntimeError('A local run is still active; stop it before restoring shared state')
            if (root / 'state.json').exists():
                write(root / 'before-shared-checkout.json', json.loads((root / 'state.json').read_text()))
            write(root / 'state.json', document)
            write(root / 'shared-base.json', {'revision': result['revision'], 'document': document})
    elif result['revision'] != request['revision'] + 1 or result['generation'] != request['generation']:
        raise ValueError('Shared response revision/generation mismatch')
    elif request.get('prepared_document') is not None:
        # Never use the live state here: workers may have saved newer work since
        # this particular request was prepared.
        write(root / 'shared-base.json', {'revision': result['revision'], 'document': request['prepared_document']})
    marker = root / 'offline-merge-pending.json'
    if marker.exists() and request.get('prepared_document') is not None:
        digest = hashlib.sha256(json.dumps(request['prepared_document'],sort_keys=True).encode()).hexdigest()
        if json.loads(marker.read_text()).get('sha256') == digest:
            marker.unlink()
    request['accepted'] = True
    request['response_summary'] = {k: v for k, v in result.items() if k != 'document'}
    write(request_path, request)
    if request['action'] == 'checkout' and request.get('heartbeat_token_file'):
        session['heartbeat_enabled'] = True
    elif (root / 'shared-session.json').exists():
        session['heartbeat_enabled'] = json.loads((root / 'shared-session.json').read_text()).get('heartbeat_enabled', False)
    if result.get('released'):
        (root / 'shared-session.json').unlink(missing_ok=True)
    else:
        write(root / 'shared-session.json', session)
        if request['action'] == 'checkout' and session.get('heartbeat_enabled'):
            import lease_heartbeat
            lease_heartbeat.start(config,session,request)
    return {k: v for k, v in result.items() if k != 'document'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default=str(PACKAGE / 'config.json'))
    sub = parser.add_subparsers(dest='command', required=True)
    command = sub.add_parser('prepare')
    command.add_argument('action', choices=('checkout', 'checkpoint', 'release'))
    command.add_argument('--holder', default='')
    command.add_argument('--heartbeat-until')
    command.add_argument('--output', required=True)
    command = sub.add_parser('accept')
    command.add_argument('--request', required=True)
    command.add_argument('--file', required=True)
    args = parser.parse_args()
    if args.command == 'prepare':
        request = prepare(args.config, args.action, args.holder, args.heartbeat_until)
        write(args.output, request)
        print(json.dumps({'request_id': request['id'], 'file': args.output, 'action': args.action}))
    else:
        print(json.dumps(accept(args.config, args.request, json.loads(Path(args.file).read_text()))))


if __name__ == '__main__':
    main()
