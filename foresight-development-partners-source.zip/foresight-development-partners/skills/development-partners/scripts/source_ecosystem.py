"""Typed source-discovery map and auditable frontier; no browsing or extra service."""
import copy
import source_policy

VERSION = '2026-10-21.ecosystem-v1'
RELATIONS = {'publishes', 'hosts', 'maintains'}


def get(state):
    return state.get('source_ecosystem', {'version': VERSION, 'organizations': {}, 'relationships': [], 'frontier': {}, 'discovery_sessions': []})


def seed(p, document, timestamp):
    graph = copy.deepcopy(get(p.state))
    from hot_zone_intake import url_key
    for org in document.get('organizations', []):
        if not all(org.get(k) for k in ('id', 'name', 'specialty', 'official_url')):
            raise ValueError('Organization requires id, name, specialty and official URL')
        url_key(org['official_url'])
        previous = graph['organizations'].get(org['id'])
        if previous and url_key(previous['official_url']) != url_key(org['official_url']):
            raise ValueError('Organization identity conflict')
        graph['organizations'][org['id']] = copy.deepcopy(org)
    for edge in document.get('relationships', []):
        if edge.get('relation') not in RELATIONS or edge.get('organization_id') not in graph['organizations'] or edge.get('source_id') not in p.state['sources'] or not edge.get('evidence'):
            raise ValueError('Relationship needs known endpoints, allowed relation and evidence')
        for fact in edge['evidence']:
            url_key(fact['url'])
            if not fact.get('fact'):raise ValueError('Relationship evidence needs a fact')
        if edge not in graph['relationships']:graph['relationships'].append(copy.deepcopy(edge))
    for task in document.get('frontier', []):
        if task.get('organization_id') not in graph['organizations'] or task.get('source_family') not in source_policy.FAMILIES or not task.get('reason'):
            raise ValueError('Frontier task needs an organization, approved family and rationale')
        # These are research tasks, never represented as verified collections.
        task = copy.deepcopy(task)
        task['status'] = 'pending'
        task['created_at'] = timestamp
        graph['frontier'].setdefault(task['id'], task)
    p.state['source_ecosystem'] = graph
    p.save()
    return {'organizations': len(graph['organizations']), 'relationships': len(graph['relationships']), 'pending_discovery_tasks': sum(x['status']=='pending' for x in graph['frontier'].values())}


def discovery_plan(state, limit=10, run_id=None):
    graph = get(state)
    counts = {}
    for session in graph['discovery_sessions']:
        org = graph['organizations'].get(session.get('organization_id'), {})
        specialty = org.get('specialty', 'unknown')
        counts[specialty] = counts.get(specialty, 0) + 1
    tasks = [t for t in graph['frontier'].values() if t['status']=='pending' and source_policy.specialty_allowed(graph['organizations'][t['organization_id']]['specialty']) and (not run_id or t.get('last_run_id') != run_id)]
    tasks.sort(key=lambda t:(source_policy.FAMILIES[t['source_family']], counts.get(graph['organizations'][t['organization_id']]['specialty'],0),t['id']))
    return {'version': graph['version'], 'tasks': [copy.deepcopy(t)|{'organization':copy.deepcopy(graph['organizations'][t['organization_id']])} for t in tasks[:limit]],
            'discovery_routes':['organization_first', 'hot_zone_first'],
            'instructions':'Use both discovery routes: follow official organizations to collections, OR search directly for approved conference faculty, narrow-AI customer archives and other approved collections, then verify their publishers. Direct discoveries need not originate in an existing frontier task. Save a new verified publisher together with its collection using propose organizations plus zones. Follow the official organization site to the specific roster/archive/directory, inspect physician examples and extraction access, then record actual findings. Only verified approved collections enter hot-zone proposals. If the frontier is empty, expand to new official organizations across specialties; do not substitute general EHR archives. No global category-exhaustion claim follows from an empty frontier.'}


def record(p, document, timestamp):
    graph = copy.deepcopy(get(p.state))
    task = graph['frontier'].get(document.get('task_id'))
    if not task or document.get('outcome') not in ('verified_collection', 'no_public_roster', 'low_relevance', 'duplicate', 'blocked', 'partial'):
        raise ValueError('Use a known frontier task and an actual supported outcome')
    if not document.get('inspected_urls') or not document.get('finding'):
        raise ValueError('Record inspected official URLs and a substantive finding')
    from hot_zone_intake import url_key
    for url in document['inspected_urls']:url_key(url)
    if document['outcome']=='verified_collection':
        source = p.state['sources'].get(document.get('source_id'))
        if not source or source_policy.problem(source):raise ValueError('Save and verify the collection before recording it as ready')
    graph['discovery_sessions'].append(copy.deepcopy(document)|{'organization_id':task['organization_id'],'recorded_at':timestamp})
    task.update(status='pending' if document['outcome']=='partial' else 'reviewed',last_outcome=document['outcome'],updated_at=timestamp)
    if document.get('run_id'):task['last_run_id']=document['run_id']
    p.state['source_ecosystem']=graph;p.save()
    return {'task_id':task['id'],'status':task['status'],'outcome':task['last_outcome']}


def record_replenishment(p, document, timestamp):
    """Journal actual bounded discovery; never treats empty saved frontier as exhaustion."""
    if not document.get('run_id') or document.get('status') not in ('bounded_complete','partial'):
        raise ValueError('Supply current run_id and bounded_complete/partial status')
    expected = source_policy.plan(p.state, document['run_id'])['replenishment_inventory_key']
    if document.get('inventory_key') != expected:
        raise ValueError('Use the current inventory key; re-plan after saving new sources')
    attempts = document.get('attempts', [])
    if not attempts:
        raise ValueError('A replenishment receipt needs actual attempts')
    from hot_zone_intake import url_key
    for attempt in attempts:
        if attempt.get('source_family') not in ('conference','narrow_ai_customer_stories'):
            raise ValueError('Replenishment targets conferences and narrow AI only')
        if attempt.get('discovery_route') not in ('organization_first','hot_zone_first'):
            raise ValueError('Record actual discovery route')
        if not attempt.get('queries') or not attempt.get('inspected_urls') or not attempt.get('finding'):
            raise ValueError('Record actual queries, inspected URLs and substantive findings')
        for url in attempt['inspected_urls']:url_key(url)
    graph = copy.deepcopy(get(p.state))
    graph.setdefault('replenishment_rounds', []).append(copy.deepcopy(document)|{'recorded_at':timestamp})
    p.state['source_ecosystem']=graph;p.save()
    return {'recorded':True,'status':document['status'],'attempt_count':len(attempts)}
