"""Approved source families and deterministic scheduling inventory."""
import hashlib
import json

VERSION = '2026-10-21.five-families-ai-only'
FAMILIES = {
    'conference': 1,
    'narrow_ai_customer_stories': 2,
    'physician_owner_podcast': 3,
    'private_practice_association_leadership': 4,
    'independent_practice_directory': 5,
}
TARGET_SPECIALTIES = {'neurology', 'cardiology', 'endocrinology', 'rheumatology', 'pulmonology', 'internal-medicine', 'primary-care'}
EXCLUDED_ORGANIZATIONS = {'lugpa','msk-summit','music-city-scale','aacs','odac','asipp','aappm','beauty-and-the-biz'}

def specialty_allowed(value):
    return value in TARGET_SPECIALTIES or value == 'multispecialty'

AI_SCOPES = {'ai_scribe', 'ai_reception', 'narrow_ai_workflow'}


def validate(row):
    if row.get('organization_id') in EXCLUDED_ORGANIZATIONS:
        raise ValueError('Source is outside the seven user-approved specialties')
    if 'target_specialties' in row and (not row['target_specialties'] or not set(row['target_specialties']).issubset(TARGET_SPECIALTIES)):
        raise ValueError('Source target_specialties must use only the seven user-approved specialties')
    family = row.get('source_family')
    if family not in FAMILIES:
        raise ValueError('Source must belong to one of the five approved families')
    if family == 'narrow_ai_customer_stories' and row.get('ai_tool_scope') not in AI_SCOPES:
        raise ValueError('Tier 2 requires a specifically identified narrow AI tool, not general EHR, billing, patient-access or communication software')
    for key in ('pool_basis', 'relevance', 'extraction_route'):
        if not isinstance(row.get(key), str) or not row[key].strip():
            raise ValueError('Source verification requires ' + key)
    if not row.get('examples') or not row.get('evidence'):
        raise ValueError('Verify publicly identifiable physician examples and collection evidence')
    return FAMILIES[family]


def problem(source):
    if source.get('kind') == 'hubspot_clinic':
        return ''  # Existing CRM clinic route is not hot-zone discovery.
    zone = source.get('hot_zone', {})
    if zone.get('policy_excluded'):
        return zone['policy_excluded']
    if zone.get('source_policy_version') != VERSION:
        return 'Source needs review against the current five-family policy'
    try:
        validate(zone)
    except ValueError as exc:
        return str(exc)
    return ''


def plan(state, run_id=None):
    new, resumable, blocked = [], [], []
    attempted = {r.get('source') for r in state.get('runs', [])}
    for s in state.get('sources', {}).values():
        if s.get('kind') == 'hubspot_clinic':
            continue
        item = {'id': s['id'], 'name': s['name'], 'url': s['url'],
                'family': s.get('hot_zone', {}).get('source_family'),
                'source_rank': s.get('priority'), 'status': s.get('status'),
                'decision': s.get('zone_selection', {}).get('status')}
        why = problem(s)
        if why:
            blocked.append(item | {'reason': why})
            continue
        if item['decision'] in ('rejected', 'deferred'):
            continue
        if not s.get('discovery_started_at') and s['id'] not in attempted:
            new.append(item)
        elif not s.get('exhausted'):
            resumable.append(item)
    key = lambda x: (FAMILIES[x['family']], x['source_rank'] if isinstance(x['source_rank'], (int,float)) else 999, x['name'])
    new.sort(key=key);resumable.sort(key=key)
    best_tier = FAMILIES[new[0]['family']] if new else 6
    higher_tasks = [dict(t) for t in state.get('source_ecosystem', {}).get('frontier', {}).values()
                    if t.get('status') == 'pending' and specialty_allowed(state.get('source_ecosystem', {}).get('organizations', {}).get(t.get('organization_id'), {}).get('specialty')) and (not run_id or t.get('last_run_id') != run_id)
                    and FAMILIES.get(t.get('source_family'), 99) < best_tier]
    high = [x for x in new if FAMILIES[x['family']] <= 2]
    inventory_key = hashlib.sha256(json.dumps(sorted(x['id'] for x in new)).encode()).hexdigest()[:16]
    rounds = state.get('source_ecosystem', {}).get('replenishment_rounds', [])
    round_done = bool(run_id) and any(r.get('run_id') == run_id and r.get('inventory_key') == inventory_key
        and r.get('status') == 'bounded_complete' for r in rounds)
    thin_high = len(high) < 2
    replenish = thin_high and not round_done
    return {'policy_version': VERSION, 'high_priority_untried_count': len(high),
            'replenishment_inventory_key': inventory_key,
            'bounded_replenishment_completed_for_inventory': round_done,
            'replenish_before_lower_tiers': replenish and best_tier > 2,
            'replenishment_policy': 'When fewer than two untried conference/narrow-AI sources remain, perform one bounded fresh discovery round for this run/inventory before descending below tier2. Record actual searches/official inspections with record-replenishment. Use new publishers and specialty/query cells across both routes; a completed unproductive round permits lower tiers. Do not repeat the same round unchanged. High-tier work may proceed while replenishment is queued.',
            'untried': new, 'partial_sources_for_explicit_or_time-budget_resume': resumable,
            'blocked': blocked, 'fresh_discovery_needed': len(new) < 3 or bool(higher_tasks) or replenish,
            'higher_priority_discovery_before_lower_tiers': higher_tasks,
            'discovery_instructions': 'Search new conferences and specifically narrow AI sources first, then physician-owner podcasts, association leadership and independent networks. An empty saved queue is not category exhaustion. Verify ten new collections when possible; never substitute broad EHR/billing sources or pad inaccessible collections. Preserve searched/rejected/discovery coverage evidence.'}
