import unittest
from unittest.mock import patch
import copy
import partner_pipeline as pp,commercial_fit as fit,source_policy
from test_practice_screening import pipeline,candidate,check,FACT
class Budget:
 def __init__(self,n):self.n=n
 def allows(self,n):return self.n>=n+2
 def remaining(self):return self.n
class AdmissionTests(unittest.TestCase):
 def run_case(self,stage_cost):
  pp.STOP.clear();p=pipeline();p.budget=Budget(1000)
  zone={'source_policy_version':source_policy.VERSION,'source_family':'conference','pool_basis':'seven names','relevance':'owners','extraction_route':'roster','examples':['A'],'evidence':copy.deepcopy(FACT)}
  people=[candidate(str(i)) for i in range(7)];p.state.update(runs=[],sources={'z1':dict(id='z1',enabled=True,status='queued',priority=1,exhausted=True,hot_zone=zone)},candidates={c['id']:c for c in people})
  p.discover=lambda *a:None;events=[]
  def prepare(p,rows,run):events.append(('practice',[c['id'] for c in rows]));return rows
  def stage(name,rows,run):
   if not rows:return
   events.append((name,[c['id'] for c in rows]));p.budget.n-=stage_cost
   for c in rows:
    if name=='screen':c.update(qualification='pass',screen={'commercial_policy_version':fit.POLICY['version'],'practice_size':dict(check(),clinic_count=1,provider_count=2)})
    else:c.update(score={'test':True},research_status='complete')
  p.parallel_stage=stage
  with patch.object(pp.practice_screening,'prepare',side_effect=prepare):p.process('z1',ingest_inputs=False,export_workbook=False)
  return p,events
 def test_ready_scores_finish_before_next_screen_batch(self):
  p,e=self.run_case(200)
  self.assertEqual([x[0] for x in e],['practice','screen','score','practice','screen','score'])
  self.assertEqual(len(p.state['runs'][-1]['screening_admission']['deferred_candidate_ids']),1)
  self.assertEqual(p.state['candidates']['6']['qualification'],'queued')
 def test_early_completion_reuses_time_for_next_batch(self):
  p,e=self.run_case(10)
  self.assertEqual(len([x for x in e if x[0]=='score']),3)
  self.assertTrue(all(c['research_status']=='complete' for c in p.state['candidates'].values()))
 def test_too_little_time_never_starts_fresh_screen(self):
  p=pipeline();p.budget=Budget(100)
  self.assertFalse(p.budget.allows(p.screen_to_score_reserve([candidate('a')])))
if __name__=='__main__':unittest.main()
