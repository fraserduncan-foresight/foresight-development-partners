import datetime as dt
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import lease_heartbeat as hb
import shared_master as sm

class HeartbeatTests(unittest.TestCase):
    def test_controller_exit_reuse_deadline_and_ownership_stop_renewal(self):
        now=hb.stamp();session={'owner':'one','generation':2}
        with patch.object(hb,'process_identity',return_value='original'):
            self.assertTrue(hb.active(session,'one',2,now+dt.timedelta(seconds=10),1,'original'))
            self.assertFalse(hb.active(session,'two',2,now+dt.timedelta(seconds=10),1,'original'))
            self.assertFalse(hb.active(session,'one',3,now+dt.timedelta(seconds=10),1,'original'))
            self.assertFalse(hb.active(session,'one',2,now-dt.timedelta(seconds=1),1,'original'))
            self.assertFalse(hb.active(session,'one',2,now+dt.timedelta(seconds=10),1,'reused-pid'))
        with patch.object(hb,'process_identity',return_value=''):
            self.assertFalse(hb.active(session,'one',2,now+dt.timedelta(seconds=10),1,'original'))

    def test_independent_expiry_and_fail_closed_recovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);owner='00000000-0000-0000-0000-000000000001'
            cfg={'shared_master':{'enabled':True,'project_id':'p'}}
            session={'project_id':'p','owner':owner,'generation':1,'revision':123,'expires_at':(hb.stamp()-dt.timedelta(seconds=30)).isoformat(),'heartbeat_enabled':True}
            (root/'shared-session.json').write_text(json.dumps(session))
            health=dict(owner=owner,generation=1,state='healthy',checked_at=hb.stamp().isoformat(),expires_at=(hb.stamp()+dt.timedelta(minutes=5)).isoformat())
            (root/'heartbeat-status.json').write_text(json.dumps(health))
            self.assertEqual(sm.require_lease(cfg,root)['revision'],123)
            for change in [{'state':'failed'},{'generation':2},{'checked_at':(hb.stamp()-dt.timedelta(seconds=151)).isoformat()}]:
                (root/'heartbeat-status.json').write_text(json.dumps(health|change))
                with self.assertRaises(RuntimeError):sm.require_lease(cfg,root)
            (root/'heartbeat-status.json').write_text(json.dumps(health|{'state':'failed'}))
            self.assertEqual(sm.require_lease(cfg,root,allow_unhealthy=True)['owner'],owner)

    def test_transport_failure_is_not_accepted_as_renewal(self):
        with patch('urllib.request.urlopen',side_effect=TimeoutError):
            with self.assertRaises(TimeoutError):hb.renew('https://example.com','x'*64,'owner',1)

if __name__=='__main__':unittest.main()
