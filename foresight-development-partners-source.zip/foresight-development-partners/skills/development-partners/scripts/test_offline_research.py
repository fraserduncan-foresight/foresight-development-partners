import copy,unittest
from types import SimpleNamespace
import offline_research as o

class OfflineTests(unittest.TestCase):
    def test_disjoint_changes_merge_without_overwriting_remote(self):
        b={'candidates':{'a':{'score':1},'b':{'score':2}},'runs':[]}
        l=copy.deepcopy(b);l['candidates']['a']['score']=3;l['runs'].append({'id':'offline'})
        r=copy.deepcopy(b);r['candidates']['b']['score']=4
        t,c=o.merge_values(b,l,r)
        self.assertFalse(c);self.assertEqual(t['candidates'],{'a':{'score':3},'b':{'score':4}})
        self.assertEqual(o.merge_values(b,l,t)[0],t)

    def test_concurrent_candidate_changes_are_withheld(self):
        t,c=o.merge_values({'candidates':{'a':{'score':1}}},{'candidates':{'a':{'score':3}}},{'candidates':{'a':{'score':4}}})
        self.assertEqual(t['candidates']['a']['score'],4);self.assertTrue(c)

    def test_new_alias_with_same_npi_is_not_imported_twice(self):
        t,c=o.merge_values({'candidates':{}},{'candidates':{'new':{'name':'A','npi':'123'}}},{'candidates':{'old':{'name':'Alias','npi':'123'}}})
        self.assertNotIn('new',t['candidates']);self.assertTrue(c)

    def test_external_writes_are_blocked_offline(self):
        with self.assertRaises(RuntimeError):o.external_write_guard(SimpleNamespace(cfg={'offline_research':{'run_id':'test'}}))

    def test_local_deletion_cannot_remove_canonical_record(self):
        t,c=o.merge_values({'candidates':{'a':1}},{'candidates':{}},{'candidates':{'a':1}})
        self.assertEqual(t['candidates']['a'],1);self.assertTrue(c)

if __name__=='__main__':unittest.main()
