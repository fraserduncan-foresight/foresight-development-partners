import unittest
import partner_pipeline as pp
from test_practice_screening import pipeline


def person(npi='1234567893'):
    return dict(name='Test Physician',practice='First Practice',website='https://example.com',city='Phoenix',state='AZ',evidence=[],npi=npi,npi_entity_type='NPI-1',npi_registry_url='https://npiregistry.cms.hhs.gov/provider-view/'+npi,npi_match_evidence='Official record matches name, specialty and location')


class IdentityTests(unittest.TestCase):
    def test_alias_same_npi_reuses_research(self):
        p=pipeline();a=person();ident=p.add_candidate(a,'first')
        p.state['candidates'][ident]['research_status']='complete'
        b=person();b.update(name='Different published name',practice='Different Practice',city='Denver',state='CO')
        self.assertEqual(p.add_candidate(b,'second'),ident)
        self.assertEqual(len(p.state['candidates']),1)
        self.assertEqual(p.state['candidates'][ident]['sources'],['first','second'])
        self.assertEqual(p.state['candidates'][ident]['research_status'],'complete')
        self.assertEqual(p.state['candidates'][ident]['practice'],'First Practice')

    def test_different_npis_same_name_stay_separate(self):
        p=pipeline();self.assertNotEqual(p.add_candidate(person(),'a'),p.add_candidate(person('1245319599'),'b'))

    def test_invalid_and_type2_never_merge(self):
        p=pipeline()
        for field,value in [('npi','1234567890'),('npi_entity_type','NPI-2'),('npi_registry_url','https://example.com'),('npi_match_evidence','')]:
            a=person();a[field]=value
            with self.assertRaises(ValueError):p.add_candidate(a,'source')
        self.assertFalse(p.state['candidates'])

if __name__=='__main__':unittest.main()
