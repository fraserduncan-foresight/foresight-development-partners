"""Offline behavior checks for practice-first screening and scoring-only AI exclusion."""
import copy
import datetime as dt
import threading
import unittest
from pathlib import Path
import json

import commercial_fit as fit
import partner_pipeline as pp
import practice_screening as ps
import workflow_handoff as handoff


FACT = [{'fact': 'Current official practice statement.', 'url': 'https://example.com/team'}]
def check(value='pass'):
    return {'status': value, 'explanation': 'Source-supported current fact.', 'evidence': copy.deepcopy(FACT) if value != 'uncertain' else []}
def practice(key, value='pass'):
    return {'practice_id': key, 'us_practice': check(), 'private_ownership': check(value),
            'practice_size': dict(check(), clinic_count=2, provider_count=6), 'partial': value=='uncertain'}
def candidate(ident, name='Shared Clinic', domain='https://example.com'):
    return dict(id=ident,name=ident,practice=name,website=domain,qualification='queued',research_status='not started',sources=['z1'])
def pipeline():
    p=pp.Pipeline.__new__(pp.Pipeline)
    p.state={'practice_screens':{},'candidates':{}}
    p.cfg={'limits':{'screen_seconds':45,'score_seconds':240,'parallel_workers':3},'bonus_checks':{'enabled':False},
           'weights':{'healthcare':25,'practice':30,'development':10,'technology':20,'influence':10,'research':5},
           'post_scoring':{'enabled':True,'threshold':75,'version':'current','include_provisional':False}}
    p.budget=pp.WindowBudget();p.stop_event=threading.Event()
    p.practice_schema=pp.SCHEMAS['practice'];p.validate_schema=pp.validate_schema;p.validate_facts=pp.validate_facts
    p.save=lambda:None;p.record_call=lambda *args:None
    p.rubric={'version':fit.SCORING_POLICY_VERSION}
    return p


class PracticeFirstTests(unittest.TestCase):
    def setUp(self):
        pp.STOP.clear();self.p=pipeline();self.calls=[]
        def call(stage,payload,run,label):
            self.calls.append(copy.deepcopy(payload))
            return {'response':practice(payload['practice_id']),'reason':''}
        self.p.call=call
        self.run={'id':'r1','screened':0,'stop_reason':''}

    def test_three_physicians_share_one_practice_and_cached_next_pass(self):
        people=[candidate(str(i)) for i in range(3)]
        self.assertEqual(len(ps.prepare(self.p,people,self.run)),3)
        self.assertEqual(len(self.calls),1)
        self.assertEqual(len(ps.prepare(self.p,[candidate('four')],dict(self.run,id='r2'))),1)
        self.assertEqual(len(self.calls),1)

    def test_same_domain_different_practice_not_merged(self):
        ps.prepare(self.p,[candidate('a','Clinic A'),candidate('b','Clinic B')],self.run)
        self.assertEqual(len(self.calls),2)

    def test_definite_practice_failure_stops_individual_screens(self):
        self.p.call=lambda stage,payload,*args:{'response':practice(payload['practice_id'],'fail'),'reason':''}
        c=candidate('a');self.assertEqual(ps.prepare(self.p,[c],self.run),[])
        self.assertEqual(c['qualification'],'fail')

    def test_followup_is_gap_only_and_stops_after_two_attempts(self):
        def call(stage,payload,*args):
            self.calls.append(copy.deepcopy(payload))
            return {'response':practice(payload['practice_id'],'uncertain'),'reason':''}
        self.p.call=call
        self.assertEqual(ps.prepare(self.p,[candidate('a')],self.run),[])
        self.assertEqual(len(self.calls),2)
        self.assertEqual(self.calls[1]['unresolved_checks'],['private_ownership'])
        self.assertIsNotNone(self.calls[1]['saved_practice'])

    def test_timeout_followup_does_not_erase_completed_practice_evidence(self):
        def call(stage,payload,*args):
            self.calls.append(copy.deepcopy(payload))
            return {'response':practice(payload['practice_id'],'uncertain'),'reason':''} if len(self.calls)==1 else {'response':None,'reason':'time_limit'}
        self.p.call=call;c=candidate('a');ps.prepare(self.p,[c],self.run)
        self.assertIsNotNone(ps.for_candidate(self.p,c))
        self.assertEqual(c['qualification'],'uncertain')

    def test_stale_cache_and_explicit_fresh_do_not_reuse(self):
        c=candidate('a');ps.prepare(self.p,[c],self.run)
        record=self.p.state['practice_screens'][ps.identity(c)]
        record['checked_at']=(dt.datetime.now(dt.timezone.utc)-dt.timedelta(days=8)).isoformat()
        self.assertIsNone(ps.for_candidate(self.p,c))
        record['checked_at']=dt.datetime.now(dt.timezone.utc).isoformat()
        self.p.fresh_candidate='a';self.p._practice_run_id='another-run'
        self.assertIsNone(ps.for_candidate(self.p,c))

    def test_ai_is_not_in_screen_schema_and_negative_score_does_not_block_screen(self):
        self.assertNotIn('workflow_ai',pp.SCHEMAS['screen']['properties'])
        c=candidate('a');ps.prepare(self.p,[c],self.run);org=ps.for_candidate(self.p,c)
        result={k:copy.deepcopy(org[k]) for k in ['us_practice','private_ownership','practice_size']}
        result.update(candidate_id='a',decision_authority=check(),partial=False)
        self.p.apply_screen(c,{'response':result,'reason':''})
        self.assertEqual(c['qualification'],'pass')
        c['calculated']={'ai_adjustment':-120}
        self.assertEqual(fit.status(c),'pass')

    def test_maximum_score_has_no_ai_penalty_and_is_eligible(self):
        c=candidate('a');ps.prepare(self.p,[c],self.run);org=ps.for_candidate(self.p,c)
        screen={k:copy.deepcopy(org[k]) for k in ['us_practice','private_ownership','practice_size']}
        screen.update(candidate_id='a',decision_authority=check(),partial=False)
        self.p.apply_screen(c,{'response':screen,'reason':''})
        score={'candidate_id':'a','ratings':{k:{'rating':4,'unknown':False,'rationale':'Supported','evidence':copy.deepcopy(FACT)} for k in pp.CATEGORIES},
               'bonus':{'tier':20,'rationale':'AI solution linked to own practice','evidence':copy.deepcopy(FACT)},
               'ai_coverage':{'adjustment':0,'rationale':'Confirmed broad embedded AI','evidence':copy.deepcopy(FACT)},
               'strongest_signal':'Supported','unknowns':'','eligibility_concern':'','partial':False}
        self.p.apply_score(c,{'response':score,'reason':''})
        self.assertEqual(c['calculated']['total'],120)
        self.assertEqual(c['qualification'],'pass')
        self.assertEqual(c['research_status'],'complete')
        self.p.state['candidates']['a']=c;handoff.apply(self.p,'now')
        self.assertEqual(c.get('enrichment',{}).get('choice'),'Yes')
        self.assertTrue(handoff.enrichment_eligible(c))
        self.assertTrue(handoff.above(c,75))
        snapshot=copy.deepcopy(self.p.state)
        handoff.apply(self.p,'later')
        self.assertEqual(self.p.state,snapshot)

    def test_missing_negative_evidence_is_rejected(self):
        score={'candidate_id':'a','ratings':{k:{'rating':0,'unknown':True,'rationale':'Unknown','evidence':[]} for k in pp.CATEGORIES},
               'bonus':{'tier':0,'rationale':'','evidence':[]},'ai_coverage':{'adjustment':-120,'rationale':'Unsupported','evidence':[]},
               'strongest_signal':'','unknowns':'','eligibility_concern':'','partial':False}
        with self.assertRaises(ValueError):pp.calculate(score,self.p.cfg['weights'])

    def test_five_minimum_with_lenient_uncertainty(self):
        data=practice('p')
        self.assertEqual(ps.status(data),'pass')
        data['practice_size']['provider_count']=5
        self.assertEqual(ps.status(data),'pass')
        data['practice_size']['provider_count']=4
        self.assertEqual(ps.status(data),'fail')
        data['practice_size']['status']='uncertain'
        self.assertEqual(ps.status(data),'pass')
        data['practice_size']['provider_count']=None
        self.assertEqual(ps.status(data),'pass')
        data['practice_size']['status']='pass'
        data['practice_size']['provider_count']=60
        data['practice_size']['clinic_count']=10
        self.assertEqual(ps.status(data),'pass')
        data['practice_size']['clinic_count']=11
        self.assertEqual(ps.status(data),'fail')

    def test_small_practice_cannot_pass_individual_screen_or_handoff(self):
        org=practice('p');org['practice_size']['provider_count']=4
        data={k:copy.deepcopy(org[k]) for k in ['us_practice','private_ownership','practice_size']}
        data.update(candidate_id='a',decision_authority=check(),partial=False)
        self.assertEqual(pp.screen_status(data),'fail')
        c=candidate('a');self.p.apply_screen(c,{'response':data,'reason':''})
        self.assertEqual(c['qualification'],'fail')
        self.assertFalse(handoff.enrichment_eligible(c))

    def test_unknown_size_advances_and_oversize_fails(self):
        data=practice('p');data['practice_size']['provider_count']=None
        self.assertEqual(ps.status(data),'pass')
        data['practice_size']['provider_count']=61
        self.assertEqual(ps.status(data),'fail')

    def test_unclear_size_needs_no_followup_and_passes_individual_gate(self):
        def call(stage,payload,*args):
            self.calls.append(stage)
            data=practice(payload['practice_id'])
            data['practice_size']=dict(check('uncertain'),clinic_count=None,provider_count=None)
            data['partial']=True
            return {'response':data,'reason':''}
        self.p.call=call;c=candidate('a')
        self.assertEqual(ps.prepare(self.p,[c],self.run),[c])
        self.assertEqual(self.calls,['practice'])
        org=ps.for_candidate(self.p,c)
        data={k:copy.deepcopy(org[k]) for k in ['us_practice','private_ownership','practice_size']}
        data.update(candidate_id='a',decision_authority=check(),partial=True)
        self.p.apply_screen(c,{'response':data,'reason':''})
        self.assertEqual(c['qualification'],'pass')
        self.assertTrue(self.p.score_allowed(c))
        self.assertIsNone(c['screen']['practice_size']['provider_count'])
        data.pop('commercial_policy_version',None)
        data['private_ownership']=check('uncertain')
        self.assertEqual(pp.screen_status(data),'uncertain')
        data['practice_size']['provider_count']=61
        data['practice_size']['evidence']=copy.deepcopy(FACT)
        self.assertEqual(pp.screen_status(data),'fail')

    def test_old_assessment_is_not_automatically_revived(self):
        self.assertFalse(handoff.research_complete({'rubric_version':'2026-10-17.1','score':{'x':1},'calculated':{'total':100},'research_status':'complete'}))

    def test_complete_source_reuses_practice_and_reaches_scoring(self):
        import source_policy
        zone={'source_policy_version':source_policy.VERSION,'source_family':'conference','pool_basis':'three named physicians','relevance':'physician owners','extraction_route':'public roster','examples':['A','B'],'evidence':copy.deepcopy(FACT)}
        self.p.state.update(runs=[],sources={'z1':dict(id='z1',enabled=True,status='queued',priority=1,exhausted=True,hot_zone=zone)})
        people=[candidate(str(i)) for i in range(3)]
        self.p.state['candidates']={c['id']:c for c in people}
        self.p.discover=lambda *args:None
        calls=[]
        def worker(stage,payload,*args):
            calls.append(stage)
            if stage=='practice':data=practice(payload['practice_id'])
            elif stage=='screen':
                data={k:copy.deepcopy(payload['verified_practice'][k]) for k in ['us_practice','private_ownership','practice_size']}
                data.update(candidate_id=payload['candidate']['id'],decision_authority=check(),partial=False)
            else:
                data={'candidate_id':payload['candidate']['id'],'ratings':{k:{'rating':3,'unknown':False,'rationale':'Supported','evidence':copy.deepcopy(FACT)} for k in pp.CATEGORIES},
                      'bonus':{'tier':10,'rationale':'Personal AI and practice frustration','evidence':copy.deepcopy(FACT)},
                      'ai_coverage':{'adjustment':0,'rationale':'No confirmed broad deployment','evidence':[]},
                      'strongest_signal':'Supported','unknowns':'','eligibility_concern':'','partial':False}
            return {'response':data,'reason':''}
        self.p.call=worker
        self.p.process('z1',ingest_inputs=False,export_workbook=False)
        self.assertEqual(calls.count('practice'),1)
        self.assertEqual(calls.count('screen'),3)
        self.assertEqual(calls.count('score'),3)
        self.assertTrue(all(c['calculated']['total']==85 for c in people))
        handoff.apply(self.p,'now')
        self.assertTrue(all(c['enrichment']['choice']=='Yes' for c in people))


if __name__=='__main__':unittest.main()
