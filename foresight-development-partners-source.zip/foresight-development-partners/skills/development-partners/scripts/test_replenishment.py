import unittest
import source_policy as policy,source_ecosystem as ecosystem,hot_zone_intake as intake
from test_source_ecosystem import pipeline,zone
class ReplenishmentTests(unittest.TestCase):
 def setup_queue(self):
  p=pipeline();org={'id':'org','name':'Example','specialty':'rheumatology','official_url':'https://example.com'}
  rows=[zone('podcast'+str(i),'physician_owner_podcast') for i in range(4)]
  intake.propose(p,{'organizations':[org],'zones':rows},'now');return p
 def test_lower_tier_volume_does_not_suppress_high_discovery(self):
  p=self.setup_queue();r=policy.plan(p.state,'run1');self.assertTrue(r['fresh_discovery_needed']);self.assertTrue(r['replenish_before_lower_tiers'])
 def receipt(self,p,status='bounded_complete'):
  return {'run_id':'run1','inventory_key':policy.plan(p.state,'run1')['replenishment_inventory_key'],'status':status,'attempts':[{'source_family':'conference','discovery_route':'hot_zone_first','queries':['rheumatology private practice conference faculty'],'inspected_urls':['https://example.com/faculty'],'finding':'Official roster inaccessible; bounded attempt saved.'}]}
 def test_complete_round_allows_fallback_but_new_run_requires_discovery(self):
  p=self.setup_queue();ecosystem.record_replenishment(p,self.receipt(p),'now');self.assertFalse(policy.plan(p.state,'run1')['replenish_before_lower_tiers']);self.assertTrue(policy.plan(p.state,'run2')['replenish_before_lower_tiers'])
 def test_partial_does_not_claim_completed_search(self):
  p=self.setup_queue();ecosystem.record_replenishment(p,self.receipt(p,'partial'),'now');self.assertTrue(policy.plan(p.state,'run1')['replenish_before_lower_tiers'])
 def test_stale_inventory_receipt_rejected(self):
  p=self.setup_queue();r=self.receipt(p);r['inventory_key']='old';self.assertRaises(ValueError,ecosystem.record_replenishment,p,r,'now')
if __name__=='__main__':unittest.main()
