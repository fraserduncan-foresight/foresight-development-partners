import hashlib,json,tempfile,unittest
from pathlib import Path
import shared_checkout_pages as pages

def raw(value):
    return {'content':[{'type':'text','text':json.dumps({'result':[{'shared_result':value}]})}]}

class CheckoutPagesTests(unittest.TestCase):
    def test_roundtrip_and_corruption_rejection(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);text=json.dumps({'candidates':{},'sources':{},'people':{},'runs':[]})
            meta={'ok':True,'owner':'00000000-0000-0000-0000-000000000001','generation':1,'revision':8,'document_length':len(text),'document_md5':hashlib.md5(text.encode()).hexdigest()}
            receipt=root/'receipt.json';receipt.write_text(json.dumps(raw(meta)))
            pages.plan(receipt,root/'pages')
            f=root/'pages'/'0.json';f.write_text(json.dumps(raw({'revision':8,'offset':0,'chunk':text})))
            pages.assemble(root/'pages',root/'assembled.json')
            f.write_text(json.dumps(raw({'revision':9,'offset':0,'chunk':text})))
            with self.assertRaises(ValueError):pages.assemble(root/'pages',root/'bad.json')
            f.write_text(json.dumps(raw({'revision':8,'offset':0,'chunk':text+'x'})))
            with self.assertRaises(ValueError):pages.assemble(root/'pages',root/'bad.json')

if __name__=='__main__':unittest.main()
