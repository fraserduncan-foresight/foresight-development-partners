import copy,json,unittest
import shared_master as shared

class DeltaTests(unittest.TestCase):
    def test_changes_reconstruct_exact_document_and_replay(self):
        base={'candidates':{'a':{'screen':True},'b':{'score':5}},'runs':[1],'gone':3}
        target={'candidates':{'a':{'screen':1},'c':{'score':0}},'runs':[1,2],'new':{'x':[]}}
        changes=shared.document_changes(base,target)
        def apply(doc):
            doc=copy.deepcopy(doc)
            for path,value,remove in changes:
                obj=doc
                for k in path[:-1]:obj=obj[k]
                if remove:obj.pop(path[-1],None)
                else:obj[path[-1]]=copy.deepcopy(value)
            return doc
        self.assertEqual(json.dumps(apply(base),sort_keys=True),json.dumps(target,sort_keys=True))
        self.assertEqual(json.dumps(apply(target),sort_keys=True),json.dumps(target,sort_keys=True))

    def test_large_unchanged_history_not_transmitted(self):
        base={'candidates':{'old':{'evidence':'x'*1000000},'new':{'screen':'queued'}},'runs':[]}
        target=copy.deepcopy(base);target['candidates']['new']['screen']='pass'
        sql=shared.delta_expression(base,target)
        self.assertLess(len(sql),500)
        self.assertNotIn('x'*100,sql)
        self.assertIn('new',sql)

    def test_bounded_sql_nesting_for_many_source_changes(self):
        base={'sources':{str(i):{'enabled':True} for i in range(200)}}
        target={'sources':{str(i):{'enabled':False} for i in range(200)}}
        self.assertLess(shared.delta_expression(base,target).count('jsonb_set('),5)

    def test_nested_array_history_is_not_retransmitted(self):
        base={'runs':[{'history':['x'*500000], 'status':'running'}]}
        target=copy.deepcopy(base);target['runs'][0]['status']='done';target['runs'].append({'status':'new'})
        sql=shared.delta_expression(base,target)
        self.assertLess(len(sql),800)
        self.assertNotIn('x'*100,sql)

    def test_no_change_uses_existing_document_with_guarded_function(self):
        request={'id':'00000000-0000-0000-0000-000000000001','owner':'00000000-0000-0000-0000-000000000002','generation':2,'revision':3,'action':'release'}
        sql=shared.save_query(request,{'sources':{}},{'sources':{}})
        self.assertIn('save_checkpoint',sql);self.assertIn('2, 3,',sql);self.assertIn('true)',sql)
        self.assertNotIn('update development_partners.master',sql)

    def test_numeric_roundtrip_does_not_create_phantom_changes(self):
        self.assertEqual(shared.document_changes({'score':15.0},{'score':15}), [])
        self.assertEqual(shared.delta_expression({'score':15.0},{'score':15}), 'm.document')
        self.assertFalse(shared.json_equal(True,1))

    def test_checkpoint_materializes_detoasted_document_once(self):
        r={'id':'00000000-0000-0000-0000-000000000001','owner':'00000000-0000-0000-0000-000000000002','generation':1,'revision':2,'action':'checkpoint'}
        sql=shared.save_query(r,{'a':2},{'a':1})
        self.assertIn("with m as materialized",sql)
        self.assertIn("document || '{}'::jsonb",sql)

if __name__=='__main__':unittest.main()
