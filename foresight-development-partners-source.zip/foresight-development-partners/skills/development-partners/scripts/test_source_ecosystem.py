import copy
import unittest
from types import SimpleNamespace
import hot_zone_intake as intake
import source_policy as policy
import source_ecosystem as ecosystem
import partner_pipeline as pp

def zone(name='Conference',family='conference'):
    return dict(target_specialties=['rheumatology'],name=name,url='https://example.com/'+name,source_family=family,
                family_key='example:'+name.lower(),publisher='Example Society',organization_id='org',
                scope='Named physician roster',rationale='Practice owners',risk='Screen current eligibility',
                examples=['Named Physician'],pool_basis='Visible named physician roster; total unknown',
                relevance='US physician owners with operational context',extraction_route='Public faculty pages',
                evidence=[dict(fact='Official named faculty visible',url='https://example.com/faculty')])
def pipeline():
    return SimpleNamespace(state={'sources':{},'runs':[]},save=lambda:None)

class SourceTests(unittest.TestCase):
    def setUp(self):
        self.p=pipeline();ecosystem.seed(self.p,{'organizations':[dict(id='org',name='Example Society',specialty='rheumatology',official_url='https://example.com')],
        'frontier':[dict(id='task',organization_id='org',source_family='conference',reason='Inspect current public faculty')], 'relationships':[]},'now')

    def test_generic_ehr_family_is_rejected_without_mutation(self):
        before=copy.deepcopy(self.p.state)
        with self.assertRaises(ValueError):intake.propose(self.p,{'zones':[zone(family='ehr_customer_stories')]},'now')
        self.assertEqual(self.p.state,before)

    def test_general_software_cannot_pass_as_narrow_ai(self):
        z=zone(family='narrow_ai_customer_stories');z['ai_tool_scope']='general_ehr'
        with self.assertRaises(ValueError):policy.validate(z)
        z['ai_tool_scope']='ai_scribe';self.assertEqual(policy.validate(z),2)

    def test_missing_examples_or_verification_does_not_pass(self):
        for key in ['examples','pool_basis','extraction_route','relevance','evidence']:
            z=zone();z.pop(key)
            with self.assertRaises(ValueError):policy.validate(z)

    def test_direct_hot_zone_saves_new_publisher_and_relationship_together(self):
        p=pipeline(); z=zone();z['discovery_route']='hot_zone_first'
        b=intake.propose(p,{'organizations':[dict(id='org',name='Example Society',specialty='rheumatology',official_url='https://example.com')],'zones':[z]},'now')
        self.assertIn('org',p.state['source_ecosystem']['organizations'])
        self.assertEqual(p.state['source_ecosystem']['relationships'][0]['source_id'],b['source_ids'][0])
        self.assertEqual(p.state['sources'][b['source_ids'][0]]['hot_zone']['discovery_route'],'hot_zone_first')

    def test_invalid_direct_collection_does_not_save_publisher(self):
        p=pipeline();before=copy.deepcopy(p.state)
        with self.assertRaises(ValueError):
            intake.propose(p,{'organizations':[dict(id='org',name='Example',specialty='rheumatology',official_url='https://example.com')],'zones':[zone(family='ehr_customer_stories')]},'now')
        self.assertEqual(p.state,before)

    def test_out_of_scope_source_and_metadata_are_rejected(self):
        z=zone();z['organization_id']='lugpa'
        with self.assertRaises(ValueError):policy.validate(z)
        z=zone();z['target_specialties']=['urology']
        with self.assertRaises(ValueError):policy.validate(z)

    def test_unknown_organization_blocks_proposal(self):
        z=zone();z['organization_id']='unknown'
        with self.assertRaises(ValueError):intake.propose(self.p,{'zones':[z]},'now')
        self.assertFalse(self.p.state['sources'])

    def test_source_tier_orders_before_old_batch_position(self):
        rows=[zone('Podcast','physician_owner_podcast'),zone('Conference')]
        saved=intake.propose(self.p,{'zones':rows},'now')
        plan=policy.plan(self.p.state)
        self.assertEqual([x['name'] for x in plan['untried']],['Conference','Podcast'])
        self.assertEqual(len(self.p.state['source_ecosystem']['relationships']),2)

    def test_excluded_source_cannot_be_selected_or_researched(self):
        b=intake.propose(self.p,{'zones':[zone()]},'now')
        source=self.p.state['sources'][b['source_ids'][0]]
        source['hot_zone']['policy_excluded']='Broad EHR archive';source['enabled']=True
        with self.assertRaises(ValueError):intake.select(self.p,b['id'],[1],'selected','now')
        self.assertFalse(policy.plan(self.p.state)['untried'])
        source['zone_selection']['status']='selected'  # Simulate a stale enabled legacy entry.
        p=pp.Pipeline.__new__(pp.Pipeline);p.state=self.p.state;p.state['runs']=[];p.cfg={};p.save=lambda:None
        with self.assertRaisesRegex(ValueError,'Source policy blocked'):p.process(source['id'],ingest_inputs=False,export_workbook=False)

    def test_missing_legacy_policy_blocks_and_empty_queue_requests_discovery(self):
        self.p.state['sources']['old']={'id':'old','name':'Old EHR','url':'https://old.example','enabled':True}
        plan=policy.plan(self.p.state)
        self.assertTrue(plan['fresh_discovery_needed']);self.assertEqual(len(plan['blocked']),1)

    def test_frontier_is_not_a_verified_source(self):
        self.assertFalse(self.p.state['sources'])
        self.assertEqual(len(ecosystem.discovery_plan(self.p.state)['tasks']),1)
        with self.assertRaises(ValueError):ecosystem.record(self.p,{'task_id':'task','outcome':'verified_collection','source_id':'fake','inspected_urls':['https://example.com'],'finding':'Found roster'},'now')

    def test_discovery_receipt_preserves_partial_vs_verified(self):
        d={'task_id':'task','outcome':'partial','inspected_urls':['https://example.com/faculty'],'finding':'Only one page inspected'}
        ecosystem.record(self.p,d,'now');self.assertEqual(len(ecosystem.discovery_plan(self.p.state)['tasks']),1)
        b=intake.propose(self.p,{'zones':[zone()]},'now')
        d.update(outcome='verified_collection',source_id=b['source_ids'][0],finding='Verified public roster and named examples')
        ecosystem.record(self.p,d,'later');self.assertFalse(ecosystem.discovery_plan(self.p.state)['tasks'])

    def test_source_no_repeat_and_rejected_history_are_preserved(self):
        b=intake.propose(self.p,{'zones':[zone()]},'now');intake.select(self.p,b['id'],[1],'rejected','later')
        with self.assertRaises(ValueError):intake.propose(self.p,{'zones':[zone()]},'again')
        self.assertFalse(policy.plan(self.p.state)['untried']);self.assertEqual(len(intake.history(self.p.state)),1)

    def test_many_lower_tier_sources_do_not_hide_unexplored_conference_task(self):
        intake.propose(self.p,{'zones':[zone('pod'+str(i),'physician_owner_podcast') for i in range(4)]},'now')
        plan=policy.plan(self.p.state)
        self.assertTrue(plan['fresh_discovery_needed'])
        self.assertEqual(plan['higher_priority_discovery_before_lower_tiers'][0]['source_family'],'conference')

    def test_partial_frontier_is_not_retried_in_same_run_or_declared_exhausted(self):
        ecosystem.record(self.p,{'task_id':'task','outcome':'partial','run_id':'night-one','inspected_urls':['https://example.com'],'finding':'No usable public roster found in this bounded inspection'},'now')
        self.assertFalse(ecosystem.discovery_plan(self.p.state,run_id='night-one')['tasks'])
        self.assertEqual(len(ecosystem.discovery_plan(self.p.state,run_id='night-two')['tasks']),1)
        self.assertEqual(self.p.state['source_ecosystem']['frontier']['task']['status'],'pending')

if __name__=='__main__':unittest.main()
