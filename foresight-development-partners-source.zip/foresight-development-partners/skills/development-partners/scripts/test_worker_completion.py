"""Offline regression tests: completed Codex turns must survive CLI cleanup delays."""
import json
from pathlib import Path
import tempfile
import time
import unittest
import sys

from partner_pipeline import CodexWorker, STOP


class WorkerCompletionTests(unittest.TestCase):
    def run_fake(self, events, result=None, linger=True):
        STOP.clear()
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        cli = root / 'fake-codex'
        # Exercise the real subprocess/event/watchdog implementation, no network.
        cli.write_text('#!' + sys.executable + '\nimport sys,json,time,pathlib\n'
                       'sys.stdin.read()\n'
                       + ("pathlib.Path(sys.argv[sys.argv.index('-o')+1]).write_text(" + repr(json.dumps(result)) + ')\n' if result is not None else '')
                       + 'events=' + repr(events) + '\n'
                       + 'for event in events: print(json.dumps(event),flush=True)\n'
                       + ('time.sleep(10)\n' if linger else ''))
        cli.chmod(0o700)
        schema = {'type': 'object', 'properties': {'ok': {'type': 'boolean'}},
                  'required': ['ok'], 'additionalProperties': False}
        start = time.monotonic()
        actual = CodexWorker(str(cli)).run('screen', 'test', schema, 1.5, root / 'worker')
        return actual, time.monotonic() - start, root

    def test_completed_turn_does_not_wait_for_cli_exit_or_result_file(self):
        events = [dict(type='item.completed', item=dict(type='agent_message', text='{"ok":true}')),
                  dict(type='turn.completed', usage=dict(input_tokens=123, output_tokens=10))]
        actual, elapsed, root = self.run_fake(events)
        self.assertEqual(actual['reason'], '')
        self.assertEqual(actual['response'], {'ok': True})
        self.assertEqual(actual['usage']['input_tokens'], 123)
        self.assertLess(elapsed, 1.2)
        self.assertEqual(json.loads((root/'worker/stream-response.json').read_text()), {'ok': True})

    def test_answer_without_completed_turn_still_times_out(self):
        actual, _, root = self.run_fake([dict(type='item.completed', item=dict(type='agent_message', text='{"ok":true}'))])
        self.assertEqual(actual['reason'], 'time_limit')
        self.assertTrue((root/'worker/stream-response.json').exists())

    def test_completed_turn_with_invalid_schema_is_not_accepted(self):
        actual, _, _ = self.run_fake([dict(type='item.completed', item=dict(type='agent_message', text='{"ok":"yes"}')),
                                     dict(type='turn.completed', usage={})])
        self.assertEqual(actual['reason'], 'time_limit')
        self.assertIsNone(actual['response'])

    def test_normal_result_file_exit_still_works(self):
        actual, _, _ = self.run_fake([], result={'ok': True}, linger=False)
        self.assertEqual(actual['reason'], '')
        self.assertEqual(actual['response'], {'ok': True})

    def test_unexpected_tool_remains_fatal(self):
        actual, _, _ = self.run_fake([dict(type='item.started', item=dict(type='command_execution'))])
        self.assertEqual(actual['reason'], 'unexpected_tool')


if __name__ == '__main__':
    unittest.main()
