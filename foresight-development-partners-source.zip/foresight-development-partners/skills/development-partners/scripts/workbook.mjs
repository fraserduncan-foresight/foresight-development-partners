import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, SpreadsheetFile, Workbook } from '@oai/artifact-tool';

const [master, payloadPath, previewDir] = process.argv.slice(2);
const { state, weights, hubspot: crm, regions = [], workflow = {} } = JSON.parse(await fs.readFile(payloadPath, 'utf8'));
const exists = await fs.access(master).then(() => true, () => false);
const wb = exists ? await SpreadsheetFile.importXlsx(await FileBlob.load(master)) : Workbook.create();
const keys = ['healthcare', 'practice', 'development', 'technology', 'influence', 'research'];
const names = { healthcare: 'Healthcare', practice: 'Practice', development: 'Development', technology: 'Technology', influence: 'Influence', research: 'Research' };
const color = { ink: '#19324A', header: '#29465E', input: '#FFF6DC', auto: '#F0F3F5', text: '#243747', line: '#D7E0E7' };
const text = value => typeof value === 'string' && /^[=+@\-]/.test(value) ? "'" + value : value ?? null;
const cols = number => { let s = ''; for (let n = number; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + (n - 1) % 26) + s; return s; };
const allCandidates = Object.values(state.candidates);
const readyForEnrichment = c => workflow.eligibility?.[c.id] ?? (c.qualification === 'pass' && c.research_status === 'complete' && !!c.calculated);
const candidates = [...allCandidates].sort((a, b) => (b.calculated?.total ?? -1) - (a.calculated?.total ?? -1) || a.name.localeCompare(b.name));
const candidateRows = candidates.map(c => [
  c.id, c.name, c.practice, c.specialty, [c.city, c.state].filter(Boolean).join(', '), c.qualification,
  c.research_status, null, null, c.calculated ? c.calculated.bonus : null,
  ...keys.map(() => null), c.score?.strongest_signal || c.signal || '',
  [c.score?.unknowns, c.screen_error, c.score_error,
    ...['us_practice', 'private_ownership', 'decision_authority', 'practice_size', 'workflow_ai'].map(k => c.screen?.[k]?.status === 'uncertain' ? c.screen[k].explanation : ''),
    c.handoff?.qualification_flag?.startsWith('Commercial fit:') ? c.handoff.status : ''].filter(Boolean).join(' | '), c.notes || '', c.updated,
  ...keys.map(key => c.score ? c.score.ratings[key].rating : null), c.calculated ? c.calculated.ai_adjustment || 0 : null,
  c.enrichment?.choice || 'Pending', c.enrichment?.status || 'Awaiting selection'
]);
const sources = Object.values(state.sources).sort((a, b) => a.priority - b.priority || a.name.localeCompare(b.name));
const hotZones = sources.filter(s => s.kind !== 'hubspot_clinic');
const clinicSources = sources.filter(s => s.kind === 'hubspot_clinic');
const regionRows = regions.map(a => [a.id, a.city, a.state, a.priority, a.enabled ? 'Yes' : 'No', a.notes || '',
  a.status, a.reported_total ?? null, a.fetched_clinics, a.completed_clinics, a.clinics_needing_review,
  a.last_fetched ? new Date(a.last_fetched) : null, a.last_id || '']);
const clinicRows = clinicSources.map(s => {
  const found = candidates.filter(c => c.sources.includes(s.id));
  return [s.id, s.hubspot.company_id, s.name, s.hubspot.city, s.hubspot.state, s.url,
    s.hubspot.url, (s.region_ids || []).map(id => state.regions?.[id]?.name || id).join(', '),
    s.status, found.length, s.status === 'complete' && !found.length ? 'No named physician identified' :
      found.filter(c => c.qualification === 'uncertain').map(c => c.screen_error || 'Eligibility unresolved').join('; '),
    s.hubspot.checked_at ? new Date(s.hubspot.checked_at) : null, s.cursor || ''];
});
const people = Object.values(state.people).sort((a, b) => a.priority - b.priority || a.name.localeCompare(b.name));
const contactRows = (crm?.contacts || []).map(c => [c.candidate_id, c.contact_id, c.properties.firstname,
  c.properties.lastname, c.properties.email, c.fit_score, c.properties.company, c.company_id,
  c.company_domain, c.properties.jobtitle, c.properties.hs_linkedin_url, c.properties.type,
  c.note_body, c.status, c.review, c.note_id, c.note_timestamp ? new Date(c.note_timestamp) : null,
  c.note_fingerprint, c.email_status, c.company_key, c.full_name]);
const companyRows = (crm?.companies || []).map(c => [c.key, c.record_id, c.properties.name,
  c.properties.domain, c.properties.website, c.properties.city, c.properties.state,
  c.properties.country || '', c.properties.address || '', c.properties.zip || '',
  c.properties.linkedin_company_page, c.properties.numberofemployees ?? null,
  c.properties.specialty, c.status, c.review.join('; '), c.unparsed_address, c.source]);
const enrichmentRows = candidates.filter(c => readyForEnrichment(c) || c.enrichment).map(c => {
  const e = c.enrichment || {}, f = e.fields || {}, value = k => f[k]?.value ?? null;
  const missing = ['first_name', 'last_name', 'linkedin', 'job_title', 'work_email', 'email_status', 'company_linkedin', 'practice_address', 'employee_count'].filter(k => (c[k] || value(k)) === null || (c[k] || value(k)) === '');
  const ready = readyForEnrichment(c);
  const choice = e.choice || 'Pending';
  const status = !ready ? 'Qualification needs review' : choice === 'Pending' ? 'Awaiting selection' : choice === 'No' ? 'Skipped' : e.status || 'Ready for Clay';
  return [c.id, c.name, c.practice, c.calculated?.total ?? null, choice, status,
    value('work_email'), value('email_status'), value('linkedin'), value('job_title'), c.website,
    value('company_linkedin'), value('practice_address'), value('employee_count'), e.updated ? new Date(e.updated) : null,
    (e.task_ids || []).join(', '), missing.join(', '), e.review_note || '',
    Object.entries(f).map(([k, v]) => `${k}: ${v.source} (${v.status})`).join('\n'),
    (e.notes || []).map(n => `${n.kind}: ${n.match}${n.note ? ' — ' + n.note : ''}`).join('\n')];
});
const evidence = [];
for (const c of candidates) {
  for (const fact of c.discovery_evidence || []) evidence.push([c.id, c.name, 'Discovery', null, null, fact.fact, fact.url, '', '']);
  for (const key of ['us_practice', 'private_ownership', 'decision_authority', 'practice_size', 'workflow_ai']) {
    const item = c.screen?.[key];
    if (item && !item.evidence.length) evidence.push([c.id, c.name, key, item.status, null, '', '', item.explanation, 'Unknown']);
    if (item) for (const fact of item.evidence) evidence.push([c.id, c.name, key, item.status, null, fact.fact, fact.url, item.explanation, '']);
  }
  for (const key of keys) {
    const item = c.score?.ratings[key];
    if (!item) continue;
    if (!item.evidence.length) evidence.push([c.id, c.name, names[key], item.rating, c.calculated.points[key], '', '', item.rationale, item.unknown ? 'Unknown' : 'No evidence']);
    for (const fact of item.evidence) evidence.push([c.id, c.name, names[key], item.rating, c.calculated.points[key], fact.fact, fact.url, item.rationale, item.unknown ? 'Unknown' : 'Documented']);
  }
  if (c.score?.bonus.tier) for (const fact of c.score.bonus.evidence) evidence.push([c.id, c.name, 'Alignment bonus', c.score.bonus.tier, c.score.bonus.tier, fact.fact, fact.url, c.score.bonus.rationale, 'Documented']);
  if (c.score?.ai_coverage?.adjustment) for (const fact of c.score.ai_coverage.evidence) evidence.push([c.id, c.name, 'Existing AI coverage', null, c.score.ai_coverage.adjustment, fact.fact, fact.url, c.score.ai_coverage.rationale, 'Documented']);
}
const runRows = state.runs.map(r => {
  const calls = r.calls || [], usage = calls.map(c => c.usage), known = usage.filter(Boolean);
  const sum = key => known.reduce((total, item) => total + (item[key] || 0), 0);
  return [r.id, r.started, r.source, r.status, r.discovered, r.screened, r.scoring_attempts, r.elapsed_seconds ?? null,
    known.length ? sum('input_tokens') : null, known.length ? sum('cached_input_tokens') : null,
    known.length ? sum('output_tokens') : null, calls.reduce((n, c) => n + (c.web_actions || 0), 0),
    calls.length ? (known.length === calls.length ? 'Reported' : 'Partial / unavailable') : 'No model calls', r.stop_reason || '', r.finished || ''];
});
const specs = [
  { name: 'Workflow', title: 'Automatic enrichment and HubSpot handoff', note: 'Final score >75 plus verified commercial fit: at most 10 clinics and 60 clinical providers, without substantial competing workflow AI deployment or active comprehensive rollout. Isolated AI tools remain eligible.',
    headers: ['Candidate ID', 'Physician', 'Fit score', 'Qualification flag', 'Workflow status', 'Clay status', 'HubSpot status', 'HubSpot contact ID'],
    rows: (workflow.candidates || []).map(c => [c.candidate_id, c.name, c.score, c.flag, c.status, c.enrichment_status, c.crm_status, c.hubspot_contact_id]),
    widths: [20, 28, 14, 65, 58, 36, 65, 26], editable: [] },
  { name: 'Candidates', title: 'Development partner candidates', note: 'Ranked by demonstrated fit. HubSpot Contacts and HubSpot Companies hold CRM fields. Notes are editable.',
    headers: ['Candidate ID', 'Full name', 'Company name', 'Specialty', 'Practice location', 'Qualification', 'Research status', 'Total score', 'Regular / 100', 'Bonus',
      ...keys.map(k => `${names[k]} / ${weights[k]}`), 'Strongest signal', 'Unknowns', 'Notes', 'Updated (UTC)', ...keys.map(k => `${names[k]} rating`), 'AI coverage adjustment', 'Enrichment choice', 'Enrichment status'],
    rows: candidateRows, widths: [19, 27, 31, 24, 23, 17, 24, 15, 17, 12, 17, 17, 18, 17, 16, 16, 64, 64, 48, 25, 19, 19, 19, 19, 19, 19, 24, 22, 30], editable: [19] },
  { name: 'Enrichment', title: 'Clay enrichment queue', note: 'Completed scores above 75 are selected automatically, including clearly flagged provisional candidates. Manual No pauses a candidate. Codex runs connected steps during the invoked workflow.',
    headers: ['Candidate ID', 'Full name', 'Company name', 'Fit score', 'Enrich?', 'Enrichment status', 'Work email', 'Email status', 'LinkedIn', 'Current role', 'Company website', 'Company LinkedIn', 'Company address', 'Employee count', 'Enriched (UTC)', 'Clay task IDs', 'Missing fields', 'Review needed', 'Field sources and status', 'Lookup notes'],
    rows: enrichmentRows, widths: [19, 27, 31, 14, 15, 32, 38, 22, 60, 35, 58, 60, 55, 18, 25, 45, 70, 70, 100, 80], editable: [5] },
  { name: 'Hot Zones', title: 'Hot zones to inspect', note: 'Add a source name and URL. Amber cells are editable. Blank Enabled means Yes; blank Priority means 3. Save, then ask Codex to run.',
    headers: ['Source ID', 'Source name', 'URL', 'Priority', 'Enabled', 'Instructions', 'Status', 'Resume cursor', 'Notes'],
    rows: hotZones.map(s => [s.id, s.name, s.url, s.priority, s.enabled ? 'Yes' : 'No', s.instructions, s.status, s.cursor, s.notes]),
    widths: [19, 32, 62, 12, 12, 65, 26, 62, 48], editable: [2, 3, 4, 5, 6, 9] },
  { name: 'HubSpot Areas', title: 'Cities and states to inspect in HubSpot', note: 'Enter a state, plus a city when needed. Save, then ask Codex to run that area. Blank Enabled means Yes; blank Priority means 3.',
    headers: ['Area ID', 'City', 'State', 'Priority', 'Enabled', 'Notes', 'Query / research status', 'CRM total reported', 'Company records fetched', 'Clinics completed', 'Clinics needing review', 'Last CRM read (UTC)', 'Resume after company ID'],
    rows: regionRows, widths: [22, 26, 21, 12, 12, 58, 29, 24, 25, 22, 24, 27, 27], editable: [2, 3, 4, 5, 6] },
  { name: 'HubSpot Clinics', title: 'HubSpot clinic records selected by area', note: 'Starting records from HubSpot company city/state fields. Public research verifies physician identity, ownership and decision authority.',
    headers: ['Source ID', 'Record ID - Companies', 'Company name', 'Company city', 'Company state', 'Website URL', 'HubSpot record URL', 'Requested areas', 'Research status', 'Physicians identified', 'Review / result', 'CRM read (UTC)', 'Resume cursor'],
    rows: clinicRows, widths: [30, 25, 35, 25, 22, 62, 100, 40, 29, 24, 78, 27, 68], editable: [] },
  { name: 'Initial People', title: 'Physicians to research', note: 'Add a physician name and any known practice details. These enter screening directly. Save, then ask Codex to run Initial People.',
    headers: ['Input ID', 'Physician name', 'Company name', 'Company website', 'Company city', 'Company state', 'Priority', 'Enabled', 'Notes', 'Status', 'Candidate ID', 'First Name', 'Last Name'],
    rows: people.map(p => [p.id, p.name, p.practice, p.website, p.city, p.state, p.priority, p.enabled ? 'Yes' : 'No', p.notes,
      state.candidates[p.candidate_id]?.qualification || 'queued', p.candidate_id || '', p.first_name || '', p.last_name || '']),
    widths: [19, 27, 31, 58, 22, 14, 12, 12, 58, 20, 19, 24, 27], editable: [2, 3, 4, 5, 6, 7, 8, 9, 12, 13] },
  { name: 'HubSpot Contacts', title: 'Physician contacts for HubSpot', note: 'First/last names and exact record IDs are editable. Fit Score is a proposed CRM field. Assessment becomes one note. Refresh through Codex.',
    headers: ['Candidate ID', 'Record ID - Contacts', 'First Name', 'Last Name', 'Email', 'Fit Score', 'Company Name', 'Record ID - Companies', 'Company Domain Name', 'Job Title', 'LinkedIn URL', 'Practice Specialty', 'Assessment note', 'CRM preparation status', 'Review needed', 'Record ID - Notes', 'Assessment date (UTC)', 'Assessment fingerprint', 'Email validation status', 'Company key', 'Full name'],
    rows: contactRows, widths: [19, 24, 24, 27, 38, 14, 34, 25, 32, 35, 60, 24, 105, 35, 85, 24, 26, 68, 28, 21, 32], editable: [2, 3, 4, 16] },
  { name: 'HubSpot Companies', title: 'Practice companies for HubSpot', note: 'One row per practice identity. Match an exact company ID before linking contacts. Company name text alone does not create the association.',
    headers: ['Company key', 'Record ID - Companies', 'Company name', 'Company Domain Name', 'Website URL', 'City', 'State/Region', 'Country/Region', 'Street Address', 'Postal Code', 'LinkedIn Company Page', 'Number of Employees', 'Specialty', 'CRM preparation status', 'Review needed', 'Full address for review', 'Enrichment sources'],
    rows: companyRows, widths: [21, 25, 34, 32, 58, 24, 20, 24, 48, 18, 60, 22, 24, 35, 85, 65, 90], editable: [2, 8, 9, 10] },
  { name: 'HubSpot Mapping', title: 'HubSpot field mapping and planned setup', note: 'Verified against portal 342239911 on 10/16/26. Role option, conditional Fit Score display and record registration are planned for later.',
    headers: ['Workbook tab', 'Column / setting', 'HubSpot object', 'HubSpot property / relationship', 'Data type', 'Mapping status', 'Mapping rule'],
    rows: crm?.mapping || [], widths: [26, 48, 20, 48, 20, 42, 112], editable: [] },
  { name: 'Evidence', title: 'Evidence supporting assessments', note: 'Specific facts and URLs explain each rating. Repeated coverage does not earn additional points.',
    headers: ['Candidate ID', 'Physician', 'Category', 'Rating / status', 'Points', 'Supporting fact', 'Source URL', 'Rating explanation', 'Evidence status'],
    rows: evidence, widths: [19, 27, 25, 18, 12, 88, 75, 85, 22], editable: [] },
  { name: 'Runs', title: 'Research run history', note: 'Per candidate: screening up to 45 seconds, scoring up to 4 minutes. Three workers. Token counts are reported usage, not a spending ceiling.',
    headers: ['Run ID', 'Started (UTC)', 'Source', 'Status', 'Discovered', 'Screened', 'Scoring attempts', 'Elapsed seconds', 'Input tokens', 'Cached input tokens', 'Output tokens', 'Web actions', 'Usage coverage', 'Stop reason', 'Finished (UTC)'],
    rows: runRows, widths: [19, 25, 20, 17, 14, 14, 18, 19, 17, 22, 18, 15, 27, 55, 25], editable: [] }
];

for (const spec of specs) {
  let sheet;
  try { sheet = wb.worksheets.getItem(spec.name); } catch { sheet = wb.worksheets.add(spec.name); }
  if (!sheet) sheet = wb.worksheets.add(spec.name);
  const count = spec.headers.length, end = cols(count), last = Math.max(35, spec.rows.length + 5);
  const used = sheet.getUsedRange();
  if (used) used.clear({ applyTo: 'contents' });
  for (const table of [...sheet.tables.items]) table.delete();
  sheet.showGridLines = false;
  sheet.getRange(`A1:${end}${last}`).format.font = { name: 'Arial', size: 10, color: color.text };
  sheet.getRange(`A1:${end}${last}`).format.verticalAlignment = 'center';
  sheet.getRange('A2').values = [[spec.title]];
  sheet.getRange('A2').format.font = { name: 'Arial', size: 15, bold: true, color: color.ink };
  sheet.getRange('A3').values = [[spec.note]];
  sheet.getRange('A3').format.font = { name: 'Arial', size: 10, italic: true, color: '#586C7B' };
  sheet.getRange(`A5:${end}5`).values = [spec.headers];
  sheet.getRange(`A5:${end}5`).format = { fill: color.header, font: { name: 'Arial', size: 10, bold: true, color: '#FFFFFF' },
    horizontalAlignment: 'center', verticalAlignment: 'center', wrapText: true, rowHeight: 38 };
  if (spec.rows.length) sheet.getRange(`A6:${end}${spec.rows.length + 5}`).values = spec.rows.map(row => row.map(text));
  sheet.getRange(`A6:${end}${last}`).format.rowHeight = 27;
  for (let i = 0; i < count; i++) sheet.getRange(`${cols(i + 1)}1:${cols(i + 1)}${last}`).format.columnWidth = spec.widths[i] || 22;
  for (const col of spec.editable) sheet.getRange(`${cols(col)}6:${cols(col)}${last}`).format.fill = color.input;
  sheet.freezePanes.freezeRows(5);
  sheet.freezePanes.freezeColumns(spec.name === 'Candidates' ? 2 : 1);
  sheet.tables.add(`A5:${end}${last}`, true, 'DP' + spec.name.replaceAll(' ', ''));
  if (spec.name === 'Candidates') {
    sheet.tabColor = color.ink;
    sheet.getRange(`H6:P${last}`).setNumberFormat('0.00');
    sheet.getRange(`U6:Z${last}`).setNumberFormat('0');
    for (let r = 6; r <= last; r++) {
      for (let i = 0; i < keys.length; i++) sheet.getRange(`${cols(11 + i)}${r}`).formulas = [[`=IF(${cols(21 + i)}${r}="","",${weights[keys[i]]}*${cols(21 + i)}${r}/4)`]];
      sheet.getRange(`I${r}`).formulas = [[`=IF(AND(OR(F${r}="pass",AND(F${r}="uncertain",LEFT(G${r},11)="provisional")),COUNT(U${r}:Z${r})=6),SUM(K${r}:P${r}),"")`]];
      sheet.getRange(`H${r}`).formulas = [[`=IF(I${r}="","",I${r}+J${r}+AA${r})`]];
    }
    sheet.getRange(`F6:F${last}`).conditionalFormats.add('containsText', { text: 'uncertain', format: { fill: '#FFF0CE', font: { color: '#805B18' } } });
  }
  if (spec.name === 'Enrichment') {
    sheet.getRange('E6:E5000').dataValidation = { rule: { type: 'list', values: ['Pending', 'Yes', 'No'] } };
    sheet.getRange(`D6:D${last}`).setNumberFormat('0.00');
    sheet.getRange(`N6:N${last}`).setNumberFormat('#,##0');
    sheet.getRange(`O6:O${last}`).setNumberFormat('mm/dd/yy hh:mm');
    for (let i = 0; i < enrichmentRows.length; i++) {
      const r = i + 6, row = enrichmentRows[i];
      const c = state.candidates[row[0]], e = c.enrichment || {};
      const ready = readyForEnrichment(c);
      const activeStatus = (e.status || 'Ready for Clay').replaceAll('"', '""');
      sheet.getRange(`F${r}`).formulas = [[ready ? `=IF(E${r}="Pending","Awaiting selection",IF(E${r}="No","Skipped","${activeStatus}"))` : '="Qualification needs review"']];
    }
    sheet.getRange(`E6:E${last}`).conditionalFormats.add('containsText', { text: 'Yes', format: { fill: '#E4EFE8' } });
  }
  if (spec.name === 'HubSpot Contacts') {
    sheet.getRange(`B6:B${last}`).setNumberFormat('@');
    sheet.getRange(`H6:H${last}`).setNumberFormat('@');
    sheet.getRange(`P6:P${last}`).setNumberFormat('@');
    sheet.getRange(`F6:F${last}`).setNumberFormat('0.00');
    sheet.getRange(`Q6:Q${last}`).setNumberFormat('mm/dd/yy hh:mm');
    for (let i = 0; i < contactRows.length; i++) {
      const r = i + 6, sourceLast = Math.max(35, candidates.length + 5);
      const lookup = `INDEX(Candidates!$H$6:$H$${sourceLast},MATCH(A${r},Candidates!$A$6:$A$${sourceLast},0))`;
      sheet.getRange(`F${r}`).formulas = [[`=IF(${lookup}="","",${lookup})`]];
    }
  }
  if (spec.name === 'HubSpot Companies') {
    sheet.getRange(`B6:B${last}`).setNumberFormat('@');
    sheet.getRange(`J6:J${last}`).setNumberFormat('@');
    sheet.getRange(`L6:L${last}`).setNumberFormat('#,##0');
  }
  if (spec.name === 'HubSpot Mapping' && spec.rows.length) {
    sheet.getRange(`G6:G${spec.rows.length + 5}`).format.wrapText = true;
    for (let i = 0; i < spec.rows.length; i++) {
      sheet.getRange(`A${i + 6}:G${i + 6}`).format.rowHeight = Math.max(27, Math.ceil(String(spec.rows[i][6]).length / 105) * 15 + 8);
    }
  }
  if (spec.name === 'HubSpot Areas') {
    sheet.getRange(`H6:K${last}`).setNumberFormat('#,##0');
    sheet.getRange(`L6:L${last}`).setNumberFormat('mm/dd/yy hh:mm');
    sheet.getRange(`M6:M${last}`).setNumberFormat('@');
  }
  if (spec.name === 'HubSpot Clinics') {
    sheet.getRange(`B6:B${last}`).setNumberFormat('@');
    sheet.getRange(`J6:J${last}`).setNumberFormat('#,##0');
    sheet.getRange(`L6:L${last}`).setNumberFormat('mm/dd/yy hh:mm');
  }
  if (['Hot Zones', 'Initial People', 'HubSpot Areas'].includes(spec.name)) {
    const enabledCol = spec.name === 'Initial People' ? 'H' : 'E';
    const priorityCol = spec.name === 'Initial People' ? 'G' : 'D';
    sheet.getRange(`${enabledCol}6:${enabledCol}5000`).dataValidation = { rule: { type: 'list', values: ['Yes', 'No'] } };
    sheet.dataValidations.add({ range: `${priorityCol}6:${priorityCol}5000`, rule: { type: 'whole', operator: 'between', formula1: 1, formula2: 999 } });
  }
}
wb.recalculate();
const errors = await wb.inspect({ kind: 'match', searchTerm: '#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#NULL!|#SPILL!|#CALC!', options: { useRegex: true, maxResults: 20 }, summary: 'Formula errors' });
if (errors.ndjson && /"(?:value|text)":"#(?:REF|DIV|VALUE|NAME|NUM|NULL|SPILL|CALC)/.test(errors.ndjson)) throw new Error(errors.ndjson);
if (previewDir) {
  await fs.mkdir(previewDir, { recursive: true });
  for (const spec of specs) {
    const range = spec.name === 'Candidates' ? 'A2:J10' : spec.name === 'Initial People' ? 'A2:M10' : spec.name === 'Runs' ? 'A2:H10' : spec.name === 'HubSpot Mapping' ? 'A2:G12' : 'A2:I10';
    const image = await wb.render({ sheetName: spec.name, range, scale: 1.5, format: 'png' });
    await fs.writeFile(path.join(previewDir, spec.name.replaceAll(' ', '-') + '.png'), new Uint8Array(await image.arrayBuffer()));
  }
  const selection = await wb.render({ sheetName: 'Candidates', range: 'AA2:AC10', scale: 1.5, format: 'png' });
  await fs.writeFile(path.join(previewDir, 'Candidates-enrichment.png'), new Uint8Array(await selection.arrayBuffer()));
  const inspect = await wb.inspect({ kind: 'table', range: 'Candidates!F5:P10', include: 'values,formulas', tableMaxRows: 6, tableMaxCols: 11 });
  await fs.writeFile(path.join(previewDir, 'verification.jsonl'), inspect.ndjson);
}
const output = await SpreadsheetFile.exportXlsx(wb);
await output.save(master.replace(/\.xlsx$/i, '.pending.xlsx'));
console.log(JSON.stringify({ candidates: candidates.length, sources: sources.length, people: people.length, evidence: evidence.length, runs: state.runs.length }));
