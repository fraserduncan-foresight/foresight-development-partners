"""Persistent, score-authorized handoff queue; external calls stay in the parent chat."""
import copy
import math
import commercial_fit


def research_complete(c):
    if c.get('rubric_version') != commercial_fit.SCORING_POLICY_VERSION:
        return False
    status = c.get('research_status', '')
    return bool(c.get('score') and c.get('calculated')) and (status == 'complete' or (status.startswith('provisional - eligibility unverified') and 'partial' not in status))


def screening_allows(c, include_provisional=False):
    if commercial_fit.status(c) != 'pass':
        return False
    if c.get('qualification') == 'pass':
        return True
    s = c.get('screen', {})
    return (include_provisional and c.get('qualification') == 'uncertain'
            and s.get('us_practice', {}).get('status') == 'pass'
            and all(s.get(k, {}).get('status') in ('pass', 'uncertain') for k in ('private_ownership', 'decision_authority')))


def above(c, threshold):
    value = c.get('calculated', {}).get('total')
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > threshold


def enrichment_eligible(c):
    auth = c.get('enrichment', {}).get('authorization', {})
    auto = auth.get('mode') == 'score_policy'
    if auto and not above(c, auth['threshold']):
        return False
    return research_complete(c) and screening_allows(c, auto and auth.get('include_provisional', False))


def apply(p, timestamp):
    # Preserve timestamps for unchanged queue records; checkpoints must be semantic.
    before = {cid: copy.deepcopy(c.get("handoff", {})) for cid, c in p.state["candidates"].items()}
    _apply(p, timestamp)
    for cid, c in p.state["candidates"].items():
        old, current = before[cid], c.get("handoff", {})
        if {k:v for k,v in old.items() if k != "updated"} == {k:v for k,v in current.items() if k != "updated"}:
            if "updated" in old:
                current["updated"] = old["updated"]
            else:
                current.pop("updated", None)


def _apply(p, timestamp):
    policy = p.cfg.get('post_scoring', {})
    if not policy.get('enabled'):
        return
    for c in p.state['candidates'].values():
        # A new nightly policy never revives historical work or explicit exclusions.
        if c.get('enrichment', {}).get('choice') == 'No' or c.get('hubspot', {}).get('registration_excluded'):
            continue
        if policy.get('eligible_scored_after') and (c.get('scored_at') or '') < policy['eligible_scored_after']:
            continue
        if commercial_fit.status(c) != 'pass':
            if c.get('score') or c.get('handoff'):
                c.setdefault('handoff', {}).update(status=commercial_fit.reason(c),
                    score=c.get('calculated', {}).get('total'), updated=timestamp,
                    qualification_flag='Commercial fit: ' + commercial_fit.status(c))
            continue
        if not (research_complete(c) and screening_allows(c, policy.get('include_provisional', False)) and above(c, policy['threshold'])):
            if c.get('handoff', {}).get('policy_version') == policy['version']:
                c['handoff'].update(status='Not eligible under current score/assessment',
                                    score=c.get('calculated', {}).get('total'), updated=timestamp)
            continue
        e = c.setdefault('enrichment', {})
        first = e.get('policy_version') != policy['version']
        if first:
            e.setdefault('selection_history', []).append({'at': timestamp, 'previous_choice': e.get('choice', 'Pending'), 'reason': 'User-authorized automatic score policy'})
            e.update(choice='Yes', policy_version=policy['version'], selected_at=timestamp,
                     authorization={'mode': 'score_policy', 'threshold': policy['threshold'], 'include_provisional': policy.get('include_provisional', False), 'authorized_at': timestamp})
            if e.get('status') in (None, '', 'Awaiting selection', 'Skipped'):
                e['status'] = 'Queued automatically for Clay'
        h = c.setdefault('handoff', {})
        h.update(policy_version=policy['version'], score=c['calculated']['total'], provisional=c['qualification'] != 'pass', updated=timestamp)
        if e.get('choice') == 'No':
            h['status'] = 'Paused by manual enrichment choice'
        elif e.get('review_note') or c.get('hubspot', {}).get('review_note'):
            h['status'] = 'Review required before HubSpot'
        elif c.get('hubspot', {}).get('registration_excluded'):
            h['status'] = 'CRM writes excluded by user; enrichment retained'
        elif c.get('hubspot', {}).get('registered_fingerprint'):
            h['status'] = 'Registered in HubSpot'
        elif c.get('hubspot', {}).get('contact_registered_at') and c.get('hubspot', {}).get('contact_id'):
            h['status'] = 'Contact registered; assessment note pending'
        elif policy.get('allow_unmatched_clay_handoff') and not e.get('contact_entity_id'):
            h['status'] = 'HubSpot registration queued'
            h['enrichment_gap'] = 'Email preferred, optional; Clay match/enrichment does not block CRM registration'
        elif not e.get('contact_entity_id'):
            prior_lookup = next((n for n in reversed(e.get('notes', [])) if n.get('kind') == 'lookup'), None)
            h['status'] = ('Clay lookup completed; person not matched' if prior_lookup and prior_lookup.get('match') in ('no_match', 'ambiguous', 'error') else 'Clay person lookup queued')
        else:
            h['status'] = 'HubSpot registration queued'
        permissions = p.state.get('integration_status', {}).get('hubspot', {})
        h['crm_status'] = ('Needs HubSpot reauthorization' if permissions.get('contact_write') == 'REQUIRES_REAUTHORIZATION' else 'Check permissions and connector confirmation before writing')
        if h['status'] == 'Contact registered; assessment note pending' and permissions.get('note_write') == 'REQUIRES_REAUTHORIZATION':
            h['crm_status'] = 'Contact complete; NOTE authorization required'
        h['qualification_flag'] = 'PROVISIONAL: ownership/decision authority unverified' if h['provisional'] else 'Screening passed'


def plan(p):
    policy = p.cfg.get('post_scoring', {})
    return {'policy': copy.deepcopy(policy), 'commercial_policy': copy.deepcopy(commercial_fit.POLICY), 'integrations': copy.deepcopy(p.state.get('integration_status', {})),
            'candidates': [{'candidate_id': c['id'], 'name': c['name'], 'score': c.get('calculated', {}).get('total'),
                            'qualification': c.get('qualification'), 'flag': c.get('handoff', {}).get('qualification_flag', ''),
                            'choice': c.get('enrichment', {}).get('choice', 'Pending'),
                            'enrichment_status': ('Paused for commercial fit verification' if commercial_fit.status(c) != 'pass'
                                and c.get('enrichment', {}).get('status') in ('Queued automatically for Clay', 'Ready for Clay')
                                else c.get('enrichment', {}).get('status', '')),
                            'hubspot_contact_id': c.get('hubspot', {}).get('contact_id', ''),
                            **copy.deepcopy(c.get('handoff', {}))}
                           for c in p.state['candidates'].values() if c.get('handoff')],
            'eligibility': {c['id']: enrichment_eligible(c) for c in p.state['candidates'].values()}}
